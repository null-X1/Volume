package com.example.glassvolume

import android.app.NotificationManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    /** Bumped in onResume so the status lines re-check after you come back from Settings. */
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
                    BoxGradientRoot {
                    SettingsScreen(
                        tick = resumeTick,
                        serviceEnabled = ::isServiceEnabled,
                        dndGranted = ::isDndGranted,
                        onOpenAccessibility = {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        },
                        onOpenDnd = {
                            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                        },
                    )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false
        return enabled.split(':').any { it.startsWith("$packageName/") }
    }

    private fun isDndGranted(): Boolean =
        getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
}

@Composable
private fun BoxGradientRoot(content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(
                colors = listOf(Color(0xFF10162B), Color(0xFF293B68), Color(0xFF5A3678), Color(0xFF102A3A)),
            ),
        ),
    ) { content() }
}

@Composable
private fun SettingsScreen(
    tick: Int,
    serviceEnabled: () -> Boolean,
    dndGranted: () -> Boolean,
    onOpenAccessibility: () -> Unit,
    onOpenDnd: () -> Unit,
) {
    val ctx = LocalContext.current
    var cfg by remember { mutableStateOf(GlassPrefs.load(ctx)) }

    fun change(new: GlassConfig) {
        cfg = new
        GlassPrefs.save(ctx, new) // the running service picks this up immediately
    }

    /** Pops the real panel up so you see the change on the actual screen. */
    fun preview() {
        VolumePanelService.instance?.preview()
    }

    val enabled = remember(tick) { serviceEnabled() }
    val dnd = remember(tick) { dndGranted() }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 12.dp)
            .background(Color.White.copy(alpha = 0.075f), RoundedCornerShape(30.dp))
            .border(1.dp, Color.White.copy(alpha = 0.13f), RoundedCornerShape(30.dp))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
    ) {
        Text("Glass Volume", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        Text(
            if (enabled) "Service: on" else "Service: off. Turn it on in Accessibility settings.",
            style = MaterialTheme.typography.bodyLarge,
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onOpenAccessibility) { Text("Accessibility") }
            OutlinedButton(onClick = onOpenDnd) {
                Text(if (dnd) "Silent mode: allowed" else "Allow silent mode")
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { preview() }, enabled = enabled) { Text("Show the panel now") }
        Spacer(Modifier.height(14.dp))
        LiveGlassPreview(cfg)

        Spacer(Modifier.height(24.dp))
        Text("Glass", style = MaterialTheme.typography.titleMedium)
        SliderRow(
            label = "Blur strength",
            valueText = "${cfg.blurDp.roundToInt()} dp",
            value = cfg.blurDp,
            range = 0f..60f,
            onChange = { change(cfg.copy(blurDp = it)) },
            onFinished = ::preview,
        )
        SliderRow(
            label = "Tint darkness",
            valueText = "${(cfg.tint * 100).roundToInt()}%",
            value = cfg.tint,
            range = 0f..0.8f,
            onChange = { change(cfg.copy(tint = it)) },
            onFinished = ::preview,
        )
        SliderRow(
            label = "Glass opacity",
            valueText = "${(cfg.glass * 100).roundToInt()}%",
            value = cfg.glass,
            range = 0.3f..1f,
            onChange = { change(cfg.copy(glass = it)) },
            onFinished = ::preview,
        )
        SwitchRow(
            label = "Live blur refresh",
            subtitle = "Keeps updating the blur while the panel is up (approximate)",
            checked = cfg.liveBlur,
            onChange = { change(cfg.copy(liveBlur = it)) },
        )

        Spacer(Modifier.height(16.dp))
        Text("Position", style = MaterialTheme.typography.titleMedium)
        SwitchRow(
            label = "Panel on the left side",
            subtitle = null,
            checked = !cfg.rightSide,
            onChange = {
                change(cfg.copy(rightSide = !it))
                preview()
            },
        )
        SliderRow(
            label = "Height on screen",
            valueText = "${(cfg.topFraction * 100).roundToInt()}%",
            value = cfg.topFraction,
            range = 0.08f..0.7f,
            onChange = { change(cfg.copy(topFraction = it)) },
            onFinished = ::preview,
        )

        Spacer(Modifier.height(16.dp))
        Text("Behaviour", style = MaterialTheme.typography.titleMedium)
        SliderRow(
            label = "Hide after",
            valueText = "%.1f s".format(cfg.hideSeconds),
            value = cfg.hideSeconds,
            range = 1f..6f,
            onChange = { change(cfg.copy(hideSeconds = it)) },
            onFinished = ::preview,
        )
        SwitchRow(
            label = "Tap anywhere to dismiss",
            subtitle = "A touch outside the panel hides it; the app below still gets the touch",
            checked = cfg.dismissOnTouch,
            onChange = { change(cfg.copy(dismissOnTouch = it)) },
        )
        SliderRow(
            label = "Hold-a-button speed",
            valueText = "${cfg.holdStepsPerSecond.roundToInt()} steps/s",
            value = cfg.holdStepsPerSecond,
            range = 3f..20f,
            onChange = { change(cfg.copy(holdStepsPerSecond = it)) },
            onFinished = {},
        )
        SwitchRow(
            label = "Vibrate on mode button",
            subtitle = null,
            checked = cfg.haptics,
            onChange = { change(cfg.copy(haptics = it)) },
        )
        SwitchRow(
            label = "Camera apps keep the volume buttons",
            subtitle = "So the volume key still works as a shutter",
            checked = cfg.cameraPassthrough,
            onChange = { change(cfg.copy(cameraPassthrough = it)) },
        )

        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = { change(GlassConfig()) }) { Text("Reset to defaults") }
    }
}

@Composable
private fun LiveGlassPreview(cfg: GlassConfig) {
    val shape = RoundedCornerShape(26.dp)
    Column(
        Modifier.fillMaxWidth().background(
            Brush.linearGradient(listOf(Color(0xFF4E6AA8).copy(alpha = 0.42f), Color(0xFFB06BCC).copy(alpha = 0.32f), Color(0xFF48C8C8).copy(alpha = 0.22f))), shape,
        ).border(1.dp, Color.White.copy(alpha = 0.24f), shape).padding(16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Live glass preview", style = MaterialTheme.typography.titleSmall, color = Color.White)
            Text("${cfg.blurDp.roundToInt()} dp", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = .8f))
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f)) {
                Text("MEDIA", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .78f))
                Spacer(Modifier.height(8.dp))
                BoxGradientSlider(cfg.glass, cfg.tint)
            }
            Text("♫", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        }
        Text("Preview updates as you adjust settings", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = .72f))
    }
}

@Composable
private fun BoxGradientSlider(glass: Float, tint: Float) {
    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxWidth().height(18.dp).background(Color.Black.copy(alpha = .25f + tint * .35f), RoundedCornerShape(20.dp)).border(1.dp, Color.White.copy(alpha = .22f), RoundedCornerShape(20.dp)),
    ) {
        androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth(glass.coerceIn(0f, 1f)).height(18.dp).background(Brush.horizontalGradient(listOf(Color.White.copy(alpha = .45f), Color.White.copy(alpha = .9f))), RoundedCornerShape(20.dp)))
    }
}

@Composable
private fun SliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    onFinished: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(label)
            Text(valueText, style = MaterialTheme.typography.bodyMedium)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            onValueChangeFinished = onFinished,
        )
    }
}

@Composable
private fun SwitchRow(
    label: String,
    subtitle: String?,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(label)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
