# Glass Volume

Custom volume panel (Accessibility service + Jetpack Compose).

Setup: install, open the app, turn the service on under Accessibility, then tap
"Allow silent mode" so the mode button can switch to silent.

Settings screen: blur strength, tint darkness, glass opacity, live blur refresh, side,
height, hide delay, hold-a-button speed, haptics, camera passthrough.

How the blur works: the device has system window-blur turned off, so the panel blurs a
screenshot taken just before it appears. With "Live blur refresh" on, it re-grabs the
screen about 3 times a second, cuts out the rectangle the panel covers, fills it from the
pixels beside it and blurs that. If nothing outside the panel moved, it keeps the exact
snapshot.
