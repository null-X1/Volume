# Glass Volume

Custom volume panel (Accessibility service + Jetpack Compose).

Setup: install, open the app, turn the service on under Accessibility, then tap
"Allow silent mode" so the mode button can switch to silent.

Settings screen: blur strength, tint darkness, glass opacity, live blur refresh, side,
height, hide delay, hold-a-button speed, haptics, camera passthrough.

How the blur works: the device has system window-blur turned off, so the panel blurs a
screenshot taken just before it appears. With "Live blur refresh" on, it re-grabs the
screen about 3 times a second, cuts out the rectangle the panel covers, fills it from the
pixels beside it and blurs that. If nothing outside the panel moved, it keeps the exact
snapshot.


## v3.3
- Settings screen redesigned: liquid-glass floating cards over an animated gradient, floating action bar.
- Every setting change pops the real panel up so you see it immediately.
- Slider drag follows the finger 1:1 and settles on a spring; rubber-band stretch when dragging past the ends.
- Pressing a volume key again while the panel is up shrinks it to a thin line (touch it to bring the panel back).

## v3.4
- The overlay window and its Compose tree are built once and reused; hiding just makes it invisible.
- The last blurred backdrop is cached and reused when the panel comes back within a few seconds (no waiting for a new screenshot); refresh buffers are reused instead of re-allocated.
- Screenshot chord (power + volume): the volume press is undone and the panel removed instantly so it is not in the picture and cannot stay stuck. Screen-off and other-window events also clear the panel and stop a held-key repeat.

## v3.6
- Thin line now matches the reference: 8dp wide, 130dp tall, a little in from the edge, dark track with a white fill.
