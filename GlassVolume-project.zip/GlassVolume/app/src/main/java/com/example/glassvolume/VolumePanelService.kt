package com.example.glassvolume

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlin.math.roundToInt

class VolumePanelService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private val owner = OverlayOwner()

    private var view: ComposeView? = null
    private var params: WindowManager.LayoutParams? = null
    private var capturing = false
    private var state by mutableStateOf(PanelState())

    private val streams = listOf(
        AudioManager.STREAM_MUSIC,
        AudioManager.STREAM_RING,
        AudioManager.STREAM_NOTIFICATION,
        AudioManager.STREAM_ALARM,
    )

    private val hideRunnable = Runnable { hide() }
    private val detachRunnable = Runnable { detach() }

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        wm = getSystemService(WindowManager::class.java)
        audio = getSystemService(AudioManager::class.java)
        owner.start()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        detach()
        owner.stop()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- volume keys

    /** Consuming the key stops the stock volume panel from appearing. */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        val direction = when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> AudioManager.ADJUST_RAISE
            KeyEvent.KEYCODE_VOLUME_DOWN -> AudioManager.ADJUST_LOWER
            else -> return false
        }
        if (event.action == KeyEvent.ACTION_DOWN) {
            val stream = defaultStream()
            try {
                audio.adjustStreamVolume(stream, direction, 0) // flag 0 = no system UI
            } catch (_: SecurityException) {
                // e.g. Do Not Disturb blocking the change
            }
            state = state.copy(active = stream)
            showPanel()
        }
        return true
    }

    private fun defaultStream() = when (audio.mode) {
        AudioManager.MODE_IN_CALL,
        AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
        else -> AudioManager.STREAM_MUSIC
    }

    // ---------------------------------------------------------------- show / hide

    private fun showPanel() {
        handler.removeCallbacks(detachRunnable)
        refreshLevels()
        when {
            view != null -> state = state.copy(visible = true)
            capturing -> Unit
            else -> {
                capturing = true
                val bounds = wm.maximumWindowMetrics.bounds
                // Screenshot BEFORE the panel exists, so the panel isn't in the shot.
                captureBackdrop { shot ->
                    capturing = false
                    state = state.copy(
                        screenW = bounds.width(),
                        screenH = bounds.height(),
                        backdrop = shot,
                        expanded = false,
                        visible = true,
                    )
                    attach()
                    scheduleHide()
                }
            }
        }
        scheduleHide()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, if (state.expanded) 4000L else 2500L)
    }

    private fun hide() {
        if (view == null) return
        state = state.copy(visible = false)
        handler.postDelayed(detachRunnable, 220L) // let the exit animation finish
    }

    private fun attach() {
        if (view != null) return
        val lp = WindowManager.LayoutParams(
            0, 0,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START }
        params = lp
        applyLayout(expanded = false)

        val v = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setContent {
                VolumePanel(
                    state = state,
                    onLevel = ::onSetLevel,
                    onToggleExpand = ::onToggleExpand,
                    onCaptions = ::onCaptions,
                    onTouch = ::scheduleHide,
                )
            }
        }
        wm.addView(v, lp)
        view = v
    }

    private fun detach() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        params = null
        state = state.copy(visible = false, backdrop = null, expanded = false)
    }

    /** Window is sized to the panel so touches outside it pass through to the app below. */
    private fun applyLayout(expanded: Boolean) {
        val lp = params ?: return
        val d = resources.displayMetrics.density
        val w = ((if (expanded) PanelMetrics.EXPANDED_W else PanelMetrics.COMPACT_W) * d).roundToInt()
        val h = ((if (expanded) PanelMetrics.EXPANDED_H else PanelMetrics.COMPACT_H) * d).roundToInt()
        lp.width = w
        lp.height = h
        lp.x = state.screenW - (PanelMetrics.MARGIN_END * d).roundToInt() - w
        lp.y = (state.screenH * PanelMetrics.TOP_FRACTION).roundToInt()
    }

    // ---------------------------------------------------------------- UI callbacks

    private fun onSetLevel(stream: Int, fraction: Float) {
        val max = audio.getStreamMaxVolume(stream)
        try {
            audio.setStreamVolume(stream, (fraction * max).roundToInt().coerceIn(0, max), 0)
        } catch (_: SecurityException) {
        }
        state = state.copy(active = stream)
        refreshLevels()
        scheduleHide()
    }

    private fun onToggleExpand() {
        val expanded = !state.expanded
        state = state.copy(expanded = expanded)
        applyLayout(expanded)
        val v = view
        val lp = params
        if (v != null && lp != null) wm.updateViewLayout(v, lp)
        scheduleHide()
    }

    private fun onCaptions() {
        startActivity(
            Intent(Settings.ACTION_CAPTIONING_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        hide()
    }

    private fun refreshLevels() {
        state = state.copy(
            levels = streams.map {
                StreamLevel(it, audio.getStreamVolume(it), audio.getStreamMaxVolume(it))
            },
            active = state.active,
        )
    }

    // ---------------------------------------------------------------- backdrop

    /**
     * One-shot snapshot of whatever is on screen, shrunk 6x. The UI blurs it and
     * crops it to the panel, so the panel looks frosted over the real content.
     * Falls back to a flat translucent panel if the screenshot fails.
     */
    private fun captureBackdrop(done: (ImageBitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            done(null); return
        }
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val bitmap = runCatching {
                    val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                    val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hw?.recycle()
                    soft?.let {
                        val small = Bitmap.createScaledBitmap(
                            it,
                            (it.width / 6).coerceAtLeast(1),
                            (it.height / 6).coerceAtLeast(1),
                            true,
                        )
                        if (small !== it) it.recycle()
                        small.asImageBitmap()
                    }
                }.getOrNull()
                runCatching { result.hardwareBuffer.close() }
                done(bitmap)
            }

            override fun onFailure(errorCode: Int) = done(null)
        })
    }
}

/** Gives the overlay ComposeView the lifecycle owners it needs outside an Activity. */
private class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)

    override val viewModelStore = ViewModelStore()
    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry

    fun start() {
        controller.performAttach()
        controller.performRestore(null)
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun stop() {
        registry.currentState = Lifecycle.State.DESTROYED
        viewModelStore.clear()
    }
}
