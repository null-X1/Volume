package com.example.glassvolume

import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.roundToInt

class VolumePanelService : AccessibilityService() {

    companion object {
        /** The running service, so the settings screen can show a preview. */
        @Volatile
        var instance: VolumePanelService? = null

        private const val SHRINK = 6                 // screenshots are shrunk this much
        private const val HOLD_DELAY_MS = 380L       // hold a key this long before it repeats
        private const val HOLD_MAX_MS = 15_000L      // safety stop if a key-up is ever missed
        private const val LIVE_FIRST_DELAY_MS = 480L // let the slide-in finish before refreshing
        private const val LIVE_INTERVAL_MS = 550L    // the system allows a screenshot every ~333 ms
        private const val QUIET_MS = 800L            // no live refresh this soon after a touch / key
        private const val LIVE_DIFF_THRESHOLD = 3f   // mean per-channel change that counts as "moved"
    }

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private lateinit var vibrator: Vibrator
    private lateinit var notifications: NotificationManager
    private val handler = Handler(Looper.getMainLooper())
    private val owner = OverlayOwner()
    private val bg = Executors.newSingleThreadExecutor()

    private var view: PanelRoot? = null
    private var params: WindowManager.LayoutParams? = null
    private var capturing = false
    private var pendingBumpDir = 0
    private var currentPackage: String? = null
    private var state by mutableStateOf(PanelState())

    // key hold
    private var heldDirection = 0
    private var heldSince = 0L

    // live blur (the baseline frame is only ever touched on the bg thread)
    private var liveRunning = false
    private var prevFrame: IntArray? = null
    private var prevFrameW = 0
    private var prevFrameH = 0
    private var filledFrame: IntArray? = null // un-blurred frame (panel hole filled), bg thread only

    // audio caches / smoothness
    private val maxCache = android.util.SparseIntArray()
    private var lastInteraction = 0L

    private val streams = listOf(
        AudioManager.STREAM_MUSIC,
        AudioManager.STREAM_RING,
        AudioManager.STREAM_NOTIFICATION,
        AudioManager.STREAM_ALARM,
    )

    private val hideRunnable = Runnable { hide() }
    private val detachRunnable = Runnable { detach() }
    private val liveRunnable = Runnable { liveTick() }
    private val reblurRunnable = Runnable { reblur() }
    private val receiverRefresh = Runnable { if (view != null && state.visible) refreshLevels() }

    private val repeatRunnable = object : Runnable {
        override fun run() {
            val dir = heldDirection
            if (dir == 0) return
            if (SystemClock.uptimeMillis() - heldSince > HOLD_MAX_MS) {
                stopHold()
                return
            }
            stepVolume(dir)
            val interval = (1000f / state.config.holdStepsPerSecond.coerceAtLeast(1f)).toLong()
            handler.postDelayed(this, interval)
        }
    }

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        onConfigChanged()
    }

    /** Keeps the slider honest when the volume or mute state changes from somewhere else. */
    private val audioReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (view == null || !state.visible) return
            // our own changes already updated the state; only outside changes need a re-read
            if (SystemClock.uptimeMillis() - lastInteraction < 300L) return
            handler.removeCallbacks(receiverRefresh)
            handler.postDelayed(receiverRefresh, 100L)
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WindowManager::class.java)
        audio = getSystemService(AudioManager::class.java)
        notifications = getSystemService(NotificationManager::class.java)
        vibrator = getSystemService(VibratorManager::class.java).defaultVibrator
        state = state.copy(config = GlassPrefs.load(this))
        GlassPrefs.prefs(this).registerOnSharedPreferenceChangeListener(prefsListener)
        ContextCompat.registerReceiver(
            this,
            audioReceiver,
            IntentFilter().apply {
                addAction("android.media.VOLUME_CHANGED_ACTION")
                addAction("android.media.STREAM_MUTE_CHANGED_ACTION")
                addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        owner.start()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui" || pkg == "android") return
        currentPackage = pkg
    }

    override fun onInterrupt() = Unit

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // rotation or a fold change: the saved screen size is wrong now, so start over
        if (view != null) {
            stopHold()
            handler.removeCallbacksAndMessages(null)
            detach()
        }
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        runCatching { unregisterReceiver(audioReceiver) }
        GlassPrefs.prefs(this).unregisterOnSharedPreferenceChangeListener(prefsListener)
        detach()
        owner.stop()
        bg.shutdown()
        super.onDestroy()
    }

    /** Shows the panel on demand (used by the settings screen). */
    fun preview() {
        if (!::audio.isInitialized) return
        showPanel()
    }

    // ---------------------------------------------------------------- volume keys

    /** Consuming the key stops the stock volume panel from appearing. */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        val direction = when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> AudioManager.ADJUST_RAISE
            KeyEvent.KEYCODE_VOLUME_DOWN -> AudioManager.ADJUST_LOWER
            else -> return false
        }
        // While the phone is ringing the system should get the key (it silences the ringer).
        if (audio.mode == AudioManager.MODE_RINGTONE) return false
        // Camera apps often use the volume buttons as a shutter.
        if (state.config.cameraPassthrough &&
            currentPackage?.contains("camera", ignoreCase = true) == true
        ) return false

        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                // The system's own key-repeat is ignored. We run our own timer so holding a
                // key changes the volume at one constant, adjustable speed.
                if (event.repeatCount == 0) {
                    stepVolume(direction)
                    heldDirection = direction
                    heldSince = SystemClock.uptimeMillis()
                    handler.removeCallbacks(repeatRunnable)
                    handler.postDelayed(repeatRunnable, HOLD_DELAY_MS)
                }
            }
            KeyEvent.ACTION_UP -> if (heldDirection == direction) stopHold()
        }
        return true
    }

    private fun stopHold() {
        heldDirection = 0
        handler.removeCallbacks(repeatRunnable)
    }

    private fun defaultStream() = when (audio.mode) {
        AudioManager.MODE_IN_CALL,
        AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
        else -> AudioManager.STREAM_MUSIC
    }

    private fun stepVolume(direction: Int) {
        lastInteraction = SystemClock.uptimeMillis()
        val stream = defaultStream()
        val before = audio.getStreamVolume(stream)
        val max = maxVol(stream)
        val wasMuted = audio.isStreamMute(stream)
        try {
            audio.adjustStreamVolume(stream, direction, 0) // flag 0 = no system UI
        } catch (_: SecurityException) {
            // e.g. Do Not Disturb blocking the change
        }
        val after = audio.getStreamVolume(stream)
        if (state.active != stream) state = state.copy(active = stream)
        storeLevel(stream, after, audio.isStreamMute(stream))

        // Pushing past either end: rubber-band bump (every step while the key is held).
        val atLimit = after == before && !wasMuted &&
            ((direction == AudioManager.ADJUST_RAISE && after >= max) ||
                (direction == AudioManager.ADJUST_LOWER && after <= 0))
        if (atLimit) {
            val dir = if (direction == AudioManager.ADJUST_RAISE) 1 else -1
            if (view != null) bumpNow(dir) else pendingBumpDir = dir
        }
        showPanel()
    }

    private fun bumpNow(dir: Int) {
        state = state.copy(bump = state.bump + 1, bumpDir = dir)
    }

    private fun flushPendingBump() {
        val dir = pendingBumpDir
        if (dir == 0) return
        pendingBumpDir = 0
        // give the first frame a moment to compose so the pill sees the change
        handler.postDelayed({ if (view != null) bumpNow(dir) }, 160L)
    }

    // ---------------------------------------------------------------- show / hide

    private fun showPanel() {
        handler.removeCallbacks(detachRunnable)
        if (!state.visible || state.levels.isEmpty()) refreshLevels()
        when {
            view != null -> {
                state = state.copy(visible = true)
                startLive()
            }
            capturing -> Unit
            else -> {
                capturing = true
                val bounds = wm.maximumWindowMetrics.bounds
                // Screenshot BEFORE the panel exists, so the panel isn't in the shot.
                captureBackdrop(blurRadius()) { shot ->
                    capturing = false
                    state = state.copy(
                        screenW = bounds.width(),
                        screenH = bounds.height(),
                        backdrop = shot?.asImageBitmap(),
                        expanded = false,
                        visible = true,
                    )
                    attach()
                    flushPendingBump()
                    startLive()
                    scheduleHide()
                }
            }
        }
        scheduleHide()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        val base = (state.config.hideSeconds * 1000f).toLong()
        handler.postDelayed(hideRunnable, if (state.expanded) base + 1500L else base)
    }

    private fun hide() {
        if (view == null) return
        state = state.copy(visible = false)
        handler.postDelayed(detachRunnable, 280L) // let the slide-out finish
    }

    private fun attach() {
        if (view != null) return
        val lp = WindowManager.LayoutParams(
            0, 0,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START }
        params = lp
        applyLayout(expanded = false)

        val compose = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setContent {
                VolumePanel(
                    state = state,
                    onLevel = ::onSetLevel,
                    onToggleExpand = ::onToggleExpand,
                    onMode = ::onMode,
                    onTouch = ::scheduleHide,
                )
            }
        }
        // The window's root view has to carry the lifecycle owners too.
        val root = PanelRoot(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            addView(
                compose,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                ),
            )
        }
        wm.addView(root, lp)
        view = root
    }

    private fun detach() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        params = null
        pendingBumpDir = 0
        liveRunning = false
        state = state.copy(visible = false, backdrop = null, expanded = false)
    }

    /**
     * The window runs from the panel's inner edge (plus a little overscan) all the way to the
     * screen edge, so the panel can slide in from the edge. Touches outside the window still
     * pass through to the app below.
     */
    private fun applyLayout(expanded: Boolean) {
        val lp = params ?: return
        val cfg = state.config
        val d = resources.displayMetrics.density
        val panelW = if (expanded) PanelMetrics.EXPANDED_W else PanelMetrics.COMPACT_W
        val panelH = if (expanded) PanelMetrics.EXPANDED_H else PanelMetrics.COMPACT_H
        val w = ((panelW + PanelMetrics.OVERSCAN + PanelMetrics.MARGIN_END) * d).roundToInt()
        val h = ((panelH + 2 * PanelMetrics.OVERSCAN) * d).roundToInt()
        lp.width = w
        lp.height = h
        lp.x = if (cfg.rightSide) state.screenW - w else 0
        lp.y = ((state.screenH * cfg.topFraction).roundToInt() -
            (PanelMetrics.OVERSCAN * d).roundToInt())
            .coerceIn(0, (state.screenH - h).coerceAtLeast(0))
    }

    private fun onConfigChanged() {
        val old = state.config
        val cfg = GlassPrefs.load(this)
        state = state.copy(config = cfg)
        if (cfg.blurDp != old.blurDp && view != null) {
            handler.removeCallbacks(reblurRunnable)
            handler.postDelayed(reblurRunnable, 120L)
        }
        val v = view
        val lp = params
        if (v != null && lp != null) {
            applyLayout(state.expanded)
            wm.updateViewLayout(v, lp)
        }
    }

    // ---------------------------------------------------------------- touch outside

    /**
     * Root of the overlay window. With FLAG_WATCH_OUTSIDE_TOUCH the window gets one
     * ACTION_OUTSIDE for every touch that lands outside it, while that touch still goes on to
     * the app underneath. Touches on the window's own transparent padding count as outside too.
     */
    private inner class PanelRoot(context: Context) : FrameLayout(context) {
        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            if (state.config.dismissOnTouch) {
                val outside = ev.actionMasked == MotionEvent.ACTION_OUTSIDE ||
                    (ev.actionMasked == MotionEvent.ACTION_DOWN && !insidePanel(ev.x, ev.y))
                if (outside) {
                    handler.post { hide() }
                    return false
                }
            }
            return super.dispatchTouchEvent(ev)
        }
    }

    /** x / y are in the overlay window's own coordinates. */
    private fun insidePanel(x: Float, y: Float): Boolean {
        val lp = params ?: return false
        val d = resources.displayMetrics.density
        val over = PanelMetrics.OVERSCAN * d
        val margin = PanelMetrics.MARGIN_END * d
        val right = state.config.rightSide
        val left = if (right) over else margin
        val rightEdge = lp.width - (if (right) margin else over)
        return x >= left && x <= rightEdge && y >= over && y <= lp.height - over
    }

    // ---------------------------------------------------------------- UI callbacks

    private fun onSetLevel(stream: Int, fraction: Float) {
        lastInteraction = SystemClock.uptimeMillis()
        val max = maxVol(stream)
        val target = (fraction * max).roundToInt().coerceIn(0, max)
        val cur = state.levels.firstOrNull { it.stream == stream }
        // Dragging fires many events per step: only talk to the audio system when it matters.
        if (cur == null || cur.level != target || (cur.muted && target > 0)) {
            try {
                if (target > 0 && audio.isStreamMute(stream)) {
                    audio.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, 0)
                }
                audio.setStreamVolume(stream, target, 0)
            } catch (_: SecurityException) {
            }
            storeLevel(stream, audio.getStreamVolume(stream), audio.isStreamMute(stream))
        }
        if (state.active != stream) state = state.copy(active = stream)
        scheduleHide()
    }

    private fun onToggleExpand() {
        lastInteraction = SystemClock.uptimeMillis()
        val expanded = !state.expanded
        state = state.copy(expanded = expanded)
        applyLayout(expanded)
        val v = view
        val lp = params
        if (v != null && lp != null) wm.updateViewLayout(v, lp)
        scheduleHide()
    }

    /** Ring -> vibrate (phone buzzes) -> silent -> ring. */
    private fun onMode() {
        lastInteraction = SystemClock.uptimeMillis()
        val next = when (audio.ringerMode) {
            AudioManager.RINGER_MODE_NORMAL -> AudioManager.RINGER_MODE_VIBRATE
            AudioManager.RINGER_MODE_VIBRATE -> AudioManager.RINGER_MODE_SILENT
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        // Going into or out of silent needs Do Not Disturb access; vibrate <-> ring doesn't.
        if (next != AudioManager.RINGER_MODE_VIBRATE && !notifications.isNotificationPolicyAccessGranted) {
            askForDndAccess()
            return
        }
        try {
            audio.ringerMode = next
        } catch (_: SecurityException) {
            askForDndAccess()
            return
        }
        if (state.config.haptics) buzz(next)
        state = state.copy(ringerMode = audio.ringerMode, ringerTick = state.ringerTick + 1)
        scheduleHide()
    }

    private fun askForDndAccess() {
        startActivity(
            Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        hide()
    }

    private fun buzz(mode: Int) {
        val effect = when (mode) {
            AudioManager.RINGER_MODE_VIBRATE ->
                VibrationEffect.createOneShot(70L, VibrationEffect.DEFAULT_AMPLITUDE)
            AudioManager.RINGER_MODE_SILENT ->
                VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)
            else ->
                VibrationEffect.createPredefined(VibrationEffect.EFFECT_DOUBLE_CLICK)
        }
        runCatching { vibrator.vibrate(effect) }
    }

    private fun maxVol(stream: Int): Int {
        var m = maxCache.get(stream, -1)
        if (m < 0) {
            m = audio.getStreamMaxVolume(stream)
            maxCache.put(stream, m)
        }
        return m
    }

    /** Updates one stream in place: no extra audio calls, no new state when nothing changed. */
    private fun storeLevel(stream: Int, level: Int, muted: Boolean) {
        val cur = state.levels
        if (cur.isEmpty()) {
            refreshLevels()
            return
        }
        val next = cur.map { if (it.stream == stream) it.copy(level = level, muted = muted) else it }
        if (next != cur) state = state.copy(levels = next)
    }

    private fun refreshLevels() {
        val next = streams.map {
            StreamLevel(
                stream = it,
                level = audio.getStreamVolume(it),
                max = maxVol(it),
                muted = audio.isStreamMute(it),
            )
        }
        val mode = audio.ringerMode
        if (next != state.levels || mode != state.ringerMode) {
            state = state.copy(levels = next, ringerMode = mode)
        }
    }

    // ---------------------------------------------------------------- backdrop snapshot

    /** Shrunk screenshot as a software bitmap, or null if anything went wrong. Runs on bg. */
    private fun decodeSmall(result: ScreenshotResult): Bitmap? {
        val small = runCatching {
            val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
            val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
            hw?.recycle()
            soft?.let {
                val s = Bitmap.createScaledBitmap(
                    it,
                    (it.width / SHRINK).coerceAtLeast(1),
                    (it.height / SHRINK).coerceAtLeast(1),
                    true,
                )
                if (s !== it) it.recycle()
                s
            }
        }.getOrNull()
        runCatching { result.hardwareBuffer.close() }
        return small
    }

    /** Radius of the blur in shrunk-screenshot pixels. */
    private fun blurRadius(): Int =
        (state.config.blurDp * resources.displayMetrics.density / SHRINK).roundToInt()

    /**
     * One-shot snapshot taken before the panel exists. It is blurred here on the CPU, once, so
     * the UI only ever draws a ready-made bitmap (no per-frame blur while the slider moves).
     * Falls back to a flat translucent panel if the screenshot fails.
     */
    private fun captureBackdrop(radius: Int, done: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, bg, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val small = decodeSmall(result)
                var blurred: Bitmap? = null
                if (small != null) {
                    val w = small.width
                    val h = small.height
                    val px = IntArray(w * h)
                    small.getPixels(px, 0, w, 0, 0, w, h)
                    small.recycle()
                    prevFrame = px
                    prevFrameW = w
                    prevFrameH = h
                    filledFrame = px
                    blurred = blurredBitmap(px, w, h, radius)
                }
                handler.post { done(blurred) }
            }

            override fun onFailure(errorCode: Int) {
                handler.post { done(null) }
            }
        })
    }

    /** Re-blurs the last frame after the blur slider moved. */
    private fun reblur() {
        if (view == null) return
        val radius = blurRadius()
        runCatching {
            bg.execute {
                val px = filledFrame ?: return@execute
                val w = prevFrameW
                val h = prevFrameH
                if (px.size != w * h || w <= 0) return@execute
                val bmp = blurredBitmap(px, w, h, radius)
                handler.post { if (view != null) state = state.copy(backdrop = bmp.asImageBitmap()) }
            }
        }
    }

    private fun blurredBitmap(px: IntArray, w: Int, h: Int, radius: Int): Bitmap {
        val out = if (radius > 0) boxBlur(px.copyOf(), w, h, radius) else px
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Two box-blur passes (close to a gaussian). Works in place on `a`, returns it. */
    private fun boxBlur(a: IntArray, w: Int, h: Int, radius: Int): IntArray {
        val tmp = IntArray(w * h)
        val r = (radius * 0.75f).roundToInt().coerceAtLeast(1)
        repeat(2) {
            blurPass(a, tmp, w, h, r, true)
            blurPass(tmp, a, w, h, r, false)
        }
        return a
    }

    private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val step = if (horizontal) 1 else w
        val win = 2 * r + 1
        for (line in 0 until lines) {
            val base = if (horizontal) line * w else line
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val p = src[base + i.coerceIn(0, len - 1) * step]
                sr += p shr 16 and 0xFF
                sg += p shr 8 and 0xFF
                sb += p and 0xFF
            }
            for (i in 0 until len) {
                dst[base + i * step] =
                    (0xFF shl 24) or ((sr / win) shl 16) or ((sg / win) shl 8) or (sb / win)
                val add = src[base + (i + r + 1).coerceAtMost(len - 1) * step]
                val rem = src[base + (i - r).coerceAtLeast(0) * step]
                sr += (add shr 16 and 0xFF) - (rem shr 16 and 0xFF)
                sg += (add shr 8 and 0xFF) - (rem shr 8 and 0xFF)
                sb += (add and 0xFF) - (rem and 0xFF)
            }
        }
    }

    // ---------------------------------------------------------------- live blur (approximate)
    //
    // The device has system window-blur switched off, so a true live blur isn't available.
    // And a screenshot taken while the panel is up contains the panel itself. So the refresh
    // works like this: grab a new screenshot, throw away the rectangle the panel covers, fill
    // that hole from the pixels just beside it, and blur the result as usual. If nothing
    // outside the panel moved since the last frame, keep the exact snapshot we already have.

    private fun startLive() {
        if (!state.config.liveBlur || liveRunning || view == null) return
        liveRunning = true
        handler.postDelayed(liveRunnable, LIVE_FIRST_DELAY_MS)
    }

    private fun liveTick() {
        if (view == null || !state.visible || !state.config.liveBlur) {
            liveRunning = false
            return
        }
        // Never do screenshot work while a finger or key is busy with the slider.
        if (SystemClock.uptimeMillis() - lastInteraction < QUIET_MS) {
            scheduleNextLive()
            return
        }
        val rect = panelRectPx()
        val radius = blurRadius()
        val sw = state.screenW
        val sh = state.screenH
        if (rect == null || sw <= 0 || sh <= 0) {
            liveRunning = false
            return
        }
        takeScreenshot(Display.DEFAULT_DISPLAY, bg, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val small = decodeSmall(result)
                val fresh = small?.let { processLive(it, rect, sw, sh, radius) }
                handler.post {
                    if (fresh != null && view != null) {
                        state = state.copy(backdrop = fresh.asImageBitmap())
                    }
                    scheduleNextLive()
                }
            }

            override fun onFailure(errorCode: Int) {
                handler.post { scheduleNextLive() }
            }
        })
    }

    private fun scheduleNextLive() {
        if (view != null && state.visible && state.config.liveBlur) {
            handler.postDelayed(liveRunnable, LIVE_INTERVAL_MS)
        } else {
            liveRunning = false
        }
    }

    /** The area the panel can draw on, in full-resolution screen pixels: l, t, r, b. */
    private fun panelRectPx(): IntArray? {
        val lp = params ?: return null
        val d = resources.displayMetrics.density
        val over = PanelMetrics.OVERSCAN * d
        val margin = PanelMetrics.MARGIN_END * d
        val right = state.config.rightSide
        val left = if (right) lp.x + over else lp.x + margin
        val rightEdge = if (right) lp.x + lp.width - margin else lp.x + lp.width - over
        val top = lp.y + over
        val bottom = lp.y + lp.height - over
        val grow = 8f * d // the bump stretch can spill a little past the panel
        return intArrayOf(
            (left - grow).toInt(), (top - grow).toInt(),
            (rightEdge + grow).toInt(), (bottom + grow).toInt(),
        )
    }

    /** Runs on bg. Returns a fresh backdrop, or null when nothing outside the panel changed. */
    private fun processLive(small: Bitmap, rect: IntArray, sw: Int, sh: Int, radius: Int): Bitmap? {
        val w = small.width
        val h = small.height
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        small.recycle()

        val sx = w.toFloat() / sw
        val sy = h.toFloat() / sh
        val x0 = (rect[0] * sx).toInt().coerceIn(0, w - 1)
        val y0 = (rect[1] * sy).toInt().coerceIn(0, h - 1)
        val x1 = (rect[2] * sx).toInt().coerceIn(x0, w - 1)
        val y1 = (rect[3] * sy).toInt().coerceIn(y0, h - 1)

        val prev = prevFrame
        if (prev != null && prevFrameW == w && prevFrameH == h) {
            if (meanDiffOutside(prev, px, w, h, x0, y0, x1, y1) < LIVE_DIFF_THRESHOLD) return null
        }
        prevFrame = px.copyOf()
        prevFrameW = w
        prevFrameH = h

        fillHole(px, w, x0, y0, x1, y1)
        filledFrame = px
        return blurredBitmap(px, w, h, radius)
    }

    private fun meanDiffOutside(
        a: IntArray, b: IntArray, w: Int, h: Int, x0: Int, y0: Int, x1: Int, y1: Int,
    ): Float {
        var sum = 0L
        var n = 0
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                if (!(x in x0..x1 && y in y0..y1)) {
                    val pa = a[y * w + x]
                    val pb = b[y * w + x]
                    sum += abs((pa shr 16 and 0xFF) - (pb shr 16 and 0xFF)) +
                        abs((pa shr 8 and 0xFF) - (pb shr 8 and 0xFF)) +
                        abs((pa and 0xFF) - (pb and 0xFF))
                    n++
                }
                x += 2
            }
            y += 2
        }
        return if (n == 0) 0f else sum.toFloat() / (3f * n)
    }

    /** Replaces the rectangle row by row with a blend of the pixel left of it and right of it. */
    private fun fillHole(px: IntArray, w: Int, x0: Int, y0: Int, x1: Int, y1: Int) {
        val lx = x0 - 1
        val rx = x1 + 1
        val span = (x1 - x0 + 1).toFloat()
        for (y in y0..y1) {
            val row = y * w
            val left = when {
                lx >= 0 -> px[row + lx]
                rx < w -> px[row + rx]
                else -> 0xFF000000.toInt()
            }
            val right = if (rx < w) px[row + rx] else left
            for (x in x0..x1) {
                val t = (x - x0 + 1f) / (span + 1f)
                px[row + x] = blend(left, right, t)
            }
        }
    }

    private fun blend(a: Int, b: Int, t: Float): Int {
        val r = ((a shr 16 and 0xFF) * (1f - t) + (b shr 16 and 0xFF) * t).toInt()
        val g = ((a shr 8 and 0xFF) * (1f - t) + (b shr 8 and 0xFF) * t).toInt()
        val bl = ((a and 0xFF) * (1f - t) + (b and 0xFF) * t).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }
}

/** Gives the overlay ComposeView the lifecycle owners it needs outside an Activity. */
private class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)

    override val viewModelStore = ViewModelStore()
    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry

    fun start() {
        controller.performAttach()
        controller.performRestore(null)
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun stop() {
        registry.currentState = Lifecycle.State.DESTROYED
        viewModelStore.clear()
    }
}
