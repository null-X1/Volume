package com.example.glassvolume

import android.content.Context
import android.content.SharedPreferences

/** Everything the user can tune from the settings screen. */
data class GlassConfig(
    /** Blur strength of the glass, in dp (0 = no blur). */
    val blurDp: Float = 22f,
    /** Dark tint laid over the blur, 0..1. */
    val tint: Float = 0.28f,
    /** Opacity of the whole glass layer (blur + tint), 0.3..1. Lower = more see-through. */
    val glass: Float = 1f,
    val rightSide: Boolean = true,
    /** Panel top as a fraction of the screen height. */
    val topFraction: Float = 0.26f,
    val hideSeconds: Float = 2.5f,
    /** Volume steps per second while a volume key is held. */
    val holdStepsPerSecond: Float = 9f,
    /** Keep refreshing the blur while the panel is up (approximate live blur). */
    val liveBlur: Boolean = true,
    val haptics: Boolean = true,
    /** Let camera apps keep the volume buttons as a shutter. */
    val cameraPassthrough: Boolean = true,
    /** A touch anywhere outside the panel hides it (the touch still reaches the app below). */
    val dismissOnTouch: Boolean = true,
)

object GlassPrefs {
    private const val FILE = "glass_volume_prefs"

    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun load(ctx: Context): GlassConfig {
        val p = prefs(ctx)
        val d = GlassConfig()
        return GlassConfig(
            blurDp = p.getFloat("blurDp", d.blurDp),
            tint = p.getFloat("tint", d.tint),
            glass = p.getFloat("glass", d.glass),
            rightSide = p.getBoolean("rightSide", d.rightSide),
            topFraction = p.getFloat("topFraction", d.topFraction),
            hideSeconds = p.getFloat("hideSeconds", d.hideSeconds),
            holdStepsPerSecond = p.getFloat("holdStepsPerSecond", d.holdStepsPerSecond),
            liveBlur = p.getBoolean("liveBlur", d.liveBlur),
            haptics = p.getBoolean("haptics", d.haptics),
            cameraPassthrough = p.getBoolean("cameraPassthrough", d.cameraPassthrough),
            dismissOnTouch = p.getBoolean("dismissOnTouch", d.dismissOnTouch),
        )
    }

    fun save(ctx: Context, c: GlassConfig) {
        prefs(ctx).edit()
            .putFloat("blurDp", c.blurDp)
            .putFloat("tint", c.tint)
            .putFloat("glass", c.glass)
            .putBoolean("rightSide", c.rightSide)
            .putFloat("topFraction", c.topFraction)
            .putFloat("hideSeconds", c.hideSeconds)
            .putFloat("holdStepsPerSecond", c.holdStepsPerSecond)
            .putBoolean("liveBlur", c.liveBlur)
            .putBoolean("haptics", c.haptics)
            .putBoolean("cameraPassthrough", c.cameraPassthrough)
            .putBoolean("dismissOnTouch", c.dismissOnTouch)
            .apply()
    }
}
