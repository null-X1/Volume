package com.example.glassvolume

import android.app.NotificationManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    /** Bumped in onResume so the status lines re-check after you come back from Settings. */
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
                    SettingsScreen(
                        tick = resumeTick,
                        serviceEnabled = ::isServiceEnabled,
                        dndGranted = ::isDndGranted,
                        onOpenAccessibility = {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        },
                        onOpenDnd = {
                            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                        },
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
        // While this screen is in front, touching it must not dismiss the live preview.
        VolumePanelService.settingsOpen = true
    }

    override fun onPause() {
        VolumePanelService.settingsOpen = false
        super.onPause()
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false
        return enabled.split(':').any { it.startsWith("$packageName/") }
    }

    private fun isDndGranted(): Boolean =
        getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
}

// ----------------------------------------------------------------- palette

private val Cyan = Color(0xFF22D3EE)
private val Violet = Color(0xFF8B5CF6)
private val Pink = Color(0xFFE879F9)
private val Amber = Color(0xFFFB923C)
private val Good = Color(0xFF4ADE80)
private val Bad = Color(0xFFFF6B7A)

// ----------------------------------------------------------------- screen

@Composable
private fun SettingsScreen(
    tick: Int,
    serviceEnabled: () -> Boolean,
    dndGranted: () -> Boolean,
    onOpenAccessibility: () -> Unit,
    onOpenDnd: () -> Unit,
) {
    val ctx = LocalContext.current
    var cfg by remember { mutableStateOf(GlassPrefs.load(ctx)) }
    val enabled = remember(tick) { serviceEnabled() }
    val dnd = remember(tick) { dndGranted() }

    /** Pops the real panel up so every change is visible on the actual screen, right away. */
    fun preview() {
        VolumePanelService.instance?.preview()
    }

    fun change(new: GlassConfig, show: Boolean = true) {
        cfg = new
        GlassPrefs.save(ctx, new) // the running service picks this up immediately
        if (show) preview()
    }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 108.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Header(enabled)

            GlassCard(0) {
                CardTitle("Setup")
                Text(
                    if (enabled) "The service is running and the stock volume panel is replaced."
                    else "Turn Glass Volume on in Accessibility settings to replace the stock panel.",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassButton(
                        text = if (enabled) "Accessibility" else "Turn on",
                        onClick = onOpenAccessibility,
                        accent = !enabled,
                        modifier = Modifier.weight(1f),
                    )
                    GlassButton(
                        text = if (dnd) "Silent: allowed" else "Allow silent",
                        onClick = onOpenDnd,
                        accent = enabled && !dnd,
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            GlassCard(1) {
                CardTitle("Glass")
                SliderRow(
                    label = "Blur strength",
                    valueText = "${cfg.blurDp.roundToInt()} dp",
                    value = cfg.blurDp,
                    range = 0f..60f,
                    onChange = { change(cfg.copy(blurDp = it)) },
                )
                SliderRow(
                    label = "Tint darkness",
                    valueText = "${(cfg.tint * 100).roundToInt()}%",
                    value = cfg.tint,
                    range = 0f..0.8f,
                    onChange = { change(cfg.copy(tint = it)) },
                )
                SliderRow(
                    label = "Glass opacity",
                    valueText = "${(cfg.glass * 100).roundToInt()}%",
                    value = cfg.glass,
                    range = 0.3f..1f,
                    onChange = { change(cfg.copy(glass = it)) },
                )
                SwitchRow(
                    label = "Live blur refresh",
                    subtitle = "Keeps updating the blur while the panel is up (approximate)",
                    checked = cfg.liveBlur,
                    onChange = { change(cfg.copy(liveBlur = it)) },
                )
            }

            GlassCard(2) {
                CardTitle("Position")
                Segmented(
                    options = listOf("Left", "Right"),
                    selected = if (cfg.rightSide) 1 else 0,
                    onSelect = { change(cfg.copy(rightSide = it == 1)) },
                )
                Spacer(Modifier.height(6.dp))
                SliderRow(
                    label = "Height on screen",
                    valueText = "${(cfg.topFraction * 100).roundToInt()}%",
                    value = cfg.topFraction,
                    range = 0.08f..0.7f,
                    onChange = { change(cfg.copy(topFraction = it)) },
                )
            }

            GlassCard(3) {
                CardTitle("Behaviour")
                SwitchRow(
                    label = "Thin line on repeated presses",
                    subtitle = "Press a volume key again while the panel is up and it shrinks to a thin line, like iPhone",
                    checked = cfg.thinOnRepeat,
                    onChange = { change(cfg.copy(thinOnRepeat = it)) },
                )
                SliderRow(
                    label = "Hide after",
                    valueText = "%.1f s".format(cfg.hideSeconds),
                    value = cfg.hideSeconds,
                    range = 1f..6f,
                    onChange = { change(cfg.copy(hideSeconds = it)) },
                )
                SliderRow(
                    label = "Hold-a-button top speed",
                    valueText = "${cfg.holdStepsPerSecond.roundToInt()} steps/s",
                    value = cfg.holdStepsPerSecond,
                    range = 2f..14f,
                    onChange = { change(cfg.copy(holdStepsPerSecond = it), show = false) },
                )
                SwitchRow(
                    label = "Tap anywhere to dismiss",
                    subtitle = "A touch outside the panel hides it; the app below still gets the touch",
                    checked = cfg.dismissOnTouch,
                    onChange = { change(cfg.copy(dismissOnTouch = it)) },
                )
                SwitchRow(
                    label = "Vibrate on mode button",
                    subtitle = null,
                    checked = cfg.haptics,
                    onChange = { change(cfg.copy(haptics = it)) },
                )
                SwitchRow(
                    label = "Camera apps keep the volume buttons",
                    subtitle = "So the volume key still works as a shutter",
                    checked = cfg.cameraPassthrough,
                    onChange = { change(cfg.copy(cameraPassthrough = it), show = false) },
                )
            }

            GlassButton(
                text = "Reset to defaults",
                onClick = { change(GlassConfig()) },
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Every change pops the real panel up so you can see it immediately.",
                color = Color.White.copy(alpha = 0.55f),
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )
        }

        // floating action bar
        FloatingBar(
            enabled = enabled,
            onShow = { preview() },
            onThin = { VolumePanelService.instance?.previewThin() },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 18.dp, vertical = 14.dp),
        )
    }
}

// ----------------------------------------------------------------- background

@Composable
private fun AuroraBackground() {
    val t = rememberInfiniteTransition(label = "aurora")
    val p = t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(24000, easing = LinearEasing), RepeatMode.Reverse),
        label = "aurora",
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF111A5C), Color(0xFF45197A), Color(0xFF08566F)),
                )
            )
            .drawBehind {
                val w = size.width
                val h = size.height
                val q = p.value
                glow(Offset(w * (0.10f + 0.55f * q), h * (0.10f + 0.08f * q)), w * 0.95f, Cyan.copy(alpha = 0.50f))
                glow(Offset(w * (0.95f - 0.60f * q), h * (0.42f + 0.10f * q)), w * 0.85f, Pink.copy(alpha = 0.42f))
                glow(Offset(w * (0.20f + 0.45f * q), h * (0.88f - 0.12f * q)), w * 0.90f, Amber.copy(alpha = 0.34f))
                glow(Offset(w * (0.80f - 0.30f * q), h * (0.70f + 0.06f * q)), w * 0.70f, Violet.copy(alpha = 0.40f))
            }
    )
}

private fun DrawScope.glow(center: Offset, radius: Float, color: Color) {
    drawCircle(
        brush = Brush.radialGradient(listOf(color, Color.Transparent), center = center, radius = radius),
        radius = radius,
        center = center,
    )
}

// ----------------------------------------------------------------- pieces

@Composable
private fun Header(enabled: Boolean) {
    Column(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Glass Volume",
                color = Color.White,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            StatusChip(enabled)
        }
        Text(
            "Liquid glass volume panel",
            color = Color.White.copy(alpha = 0.65f),
            fontSize = 14.sp,
        )
    }
}

@Composable
private fun StatusChip(on: Boolean) {
    val shape = CircleShape
    val pulse = rememberInfiniteTransition(label = "dot")
    val a = pulse.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "dotA",
    )
    Row(
        Modifier
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color.White.copy(0.26f), Color.White.copy(0.08f))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(0.7f), Color.White.copy(0.1f))), shape)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(9.dp)
                .graphicsLayer { alpha = if (on) a.value else 1f }
                .background(if (on) Good else Bad, CircleShape)
        )
        Spacer(Modifier.width(7.dp))
        Text(if (on) "On" else "Off", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Frosted floating card: translucent gradient, bright rim, soft sheen on top, drop shadow. */
@Composable
private fun GlassCard(
    index: Int,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index * 70L)
        enter.animateTo(1f, spring(dampingRatio = 0.8f, stiffness = 200f))
    }
    val shape = RoundedCornerShape(30.dp)
    Column(
        modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = enter.value.coerceIn(0f, 1f)
                translationY = (1f - enter.value) * 40.dp.toPx()
            }
            .shadow(
                elevation = 22.dp,
                shape = shape,
                ambientColor = Color(0x33000000),
                spotColor = Color(0x66000000),
            )
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color.White.copy(0.26f), Color.White.copy(0.08f))))
            .border(
                1.2.dp,
                Brush.linearGradient(
                    listOf(Color.White.copy(0.80f), Color.White.copy(0.08f), Color.White.copy(0.38f)),
                ),
                shape,
            )
            .drawBehind {
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(0.20f), Color.Transparent),
                        endY = size.height * 0.35f,
                    )
                )
            }
            .padding(18.dp),
        content = content,
    )
}

@Composable
private fun CardTitle(text: String) {
    Text(
        text.uppercase(),
        color = Color.White.copy(alpha = 0.62f),
        fontSize = 12.sp,
        letterSpacing = 1.6.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 8.dp),
    )
}

@Composable
private fun SliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(label, color = Color.White, fontSize = 15.sp)
            Text(valueText, color = Color.White.copy(alpha = 0.72f), fontSize = 13.sp)
        }
        GlassSlider(value, range, onChange)
    }
}

/** Horizontal slider drawn by hand: the thumb sits exactly under the finger, no smoothing lag. */
@Composable
private fun GlassSlider(
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    var widthPx by remember { mutableIntStateOf(1) }
    var pressed by remember { mutableStateOf(false) }
    val grow = animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = spring<Float>(dampingRatio = 0.55f, stiffness = 500f),
        label = "thumb",
    )
    val latestChange by rememberUpdatedState(onChange)
    val latestRange by rememberUpdatedState(range)
    val latestValue by rememberUpdatedState(value)

    Box(
        modifier
            .fillMaxWidth()
            .height(38.dp)
            .onSizeChanged { widthPx = it.width.coerceAtLeast(1) }
            .pointerInput(Unit) {
                val pad = 14.dp.toPx()
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    pressed = true
                    fun set(x: Float) {
                        val r = latestRange
                        val f = ((x - pad) / (size.width - 2f * pad)).coerceIn(0f, 1f)
                        latestChange(r.start + f * (r.endInclusive - r.start))
                    }
                    set(down.position.x)
                    while (true) {
                        val ev = awaitPointerEvent()
                        val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!c.pressed) break
                        c.consume()
                        set(c.position.x)
                    }
                    pressed = false
                }
            }
            .drawBehind {
                val r0 = 14.dp.toPx()
                val trackH = 8.dp.toPx()
                val cy = size.height / 2f
                val rg = alphaGrow(grow.value)
                val rr = r0 * (1f + 0.22f * rg)
                val rg2 = latestRange
                val f = ((latestValue - rg2.start) / (rg2.endInclusive - rg2.start)).coerceIn(0f, 1f)
                val x = r0 + f * (size.width - 2f * r0)

                drawRoundRect(
                    color = Color.White.copy(alpha = 0.20f),
                    topLeft = Offset(0f, cy - trackH / 2f),
                    size = Size(size.width, trackH),
                    cornerRadius = CornerRadius(trackH / 2f),
                )
                drawRoundRect(
                    brush = Brush.horizontalGradient(listOf(Cyan, Violet), startX = 0f, endX = size.width),
                    topLeft = Offset(0f, cy - trackH / 2f),
                    size = Size(x, trackH),
                    cornerRadius = CornerRadius(trackH / 2f),
                )
                // thumb: soft shadow, glassy body, bright rim
                drawCircle(Color.Black.copy(alpha = 0.25f), radius = rr + 1.dp.toPx(), center = Offset(x, cy + 2.dp.toPx()))
                drawCircle(
                    brush = Brush.verticalGradient(
                        listOf(Color.White, Color(0xFFDDE4FF)),
                        startY = cy - rr,
                        endY = cy + rr,
                    ),
                    radius = rr,
                    center = Offset(x, cy),
                )
                drawCircle(Color.White.copy(alpha = 0.7f), radius = rr, center = Offset(x, cy), style = Stroke(1.dp.toPx()))
            }
    )
}

private fun alphaGrow(v: Float): Float = v.coerceIn(0f, 1.3f)

@Composable
private fun SwitchRow(
    label: String,
    subtitle: String?,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    val latest by rememberUpdatedState(onChange)
    val checkedNow by rememberUpdatedState(checked)
    Row(
        Modifier
            .fillMaxWidth()
            .pointerInput(Unit) { detectTapGestures { latest(!checkedNow) } }
            .padding(vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 14.dp)) {
            Text(label, color = Color.White, fontSize = 15.sp)
            if (subtitle != null) {
                Text(
                    subtitle,
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
        }
        GlassSwitch(checked)
    }
}

@Composable
private fun GlassSwitch(checked: Boolean) {
    val p = animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = spring<Float>(dampingRatio = 0.6f, stiffness = 500f),
        label = "switch",
    )
    Canvas(Modifier.size(width = 54.dp, height = 32.dp)) {
        val h = size.height
        val v = p.value
        drawRoundRect(Color.White.copy(alpha = 0.20f), cornerRadius = CornerRadius(h / 2f))
        drawRoundRect(
            brush = Brush.horizontalGradient(listOf(Cyan, Violet)),
            alpha = v.coerceIn(0f, 1f),
            cornerRadius = CornerRadius(h / 2f),
        )
        drawRoundRect(
            Color.White.copy(alpha = 0.35f),
            cornerRadius = CornerRadius(h / 2f),
            style = Stroke(1.dp.toPx()),
        )
        val r = h / 2f - 3.dp.toPx()
        val cx = h / 2f + v * (size.width - h)
        drawCircle(Color.Black.copy(alpha = 0.22f), radius = r + 0.5.dp.toPx(), center = Offset(cx, h / 2f + 1.5.dp.toPx()))
        drawCircle(
            brush = Brush.verticalGradient(
                listOf(Color.White, Color(0xFFE2E8FF)),
                startY = h / 2f - r,
                endY = h / 2f + r,
            ),
            radius = r,
            center = Offset(cx, h / 2f),
        )
    }
}

/** Two-way glass segmented control with a sliding highlight. */
@Composable
private fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val pos = animateFloatAsState(
        targetValue = selected.toFloat(),
        animationSpec = spring<Float>(dampingRatio = 0.7f, stiffness = 450f),
        label = "segment",
    )
    val latest by rememberUpdatedState(onSelect)
    Box(
        Modifier
            .fillMaxWidth()
            .height(46.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.14f))
            .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
            .drawBehind {
                val w = size.width / options.size
                val inset = 3.dp.toPx()
                drawRoundRect(
                    brush = Brush.linearGradient(listOf(Color.White.copy(0.42f), Color.White.copy(0.20f))),
                    topLeft = Offset(pos.value * w + inset, inset),
                    size = Size(w - 2f * inset, size.height - 2f * inset),
                    cornerRadius = CornerRadius(size.height / 2f),
                )
            }
    ) {
        Row(Modifier.fillMaxSize()) {
            options.forEachIndexed { i, label ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .pointerInput(i) { detectTapGestures { latest(i) } },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    accent: Boolean = false,
) {
    var pressed by remember { mutableStateOf(false) }
    val scale = animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        animationSpec = spring<Float>(dampingRatio = 0.5f, stiffness = 600f),
        label = "button",
    )
    val latest by rememberUpdatedState(onClick)
    val fill = if (accent) {
        Brush.horizontalGradient(listOf(Cyan.copy(alpha = 0.78f), Violet.copy(alpha = 0.78f)))
    } else {
        Brush.linearGradient(listOf(Color.White.copy(0.28f), Color.White.copy(0.10f)))
    }
    Box(
        modifier
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
                alpha = if (enabled) 1f else 0.45f
            }
            .clip(CircleShape)
            .background(fill)
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(0.75f), Color.White.copy(0.10f))),
                CircleShape,
            )
            .pointerInput(enabled) {
                detectTapGestures(
                    onPress = {
                        if (enabled) {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        }
                    },
                    onTap = { if (enabled) latest() },
                )
            }
            .padding(horizontal = 18.dp, vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** Floating pill with the two preview buttons; stays put while the cards scroll underneath. */
@Composable
private fun FloatingBar(
    enabled: Boolean,
    onShow: () -> Unit,
    onThin: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(36.dp)
    Row(
        modifier
            .fillMaxWidth()
            .shadow(24.dp, shape, ambientColor = Color(0x44000000), spotColor = Color(0x88000000))
            .clip(shape)
            .background(Color(0x66101030))
            .background(Brush.linearGradient(listOf(Color.White.copy(0.24f), Color.White.copy(0.08f))))
            .border(
                1.2.dp,
                Brush.linearGradient(listOf(Color.White.copy(0.8f), Color.White.copy(0.1f), Color.White.copy(0.4f))),
                shape,
            )
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        GlassButton("Show panel", onShow, Modifier.weight(1f), enabled = enabled, accent = true)
        GlassButton("Thin line", onThin, Modifier.weight(1f), enabled = enabled)
    }
}
