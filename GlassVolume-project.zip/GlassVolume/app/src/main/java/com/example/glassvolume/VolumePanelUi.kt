package com.example.glassvolume

import android.media.AudioManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

// ----------------------------------------------------------------- tuning knobs

/** Panel sizes in dp (taken from the proportions in your screenshots). */
object PanelMetrics {
    const val COMPACT_W = 56
    const val COMPACT_H = 252
    const val EXPANDED_W = 330
    const val EXPANDED_H = 270
    const val MARGIN_END = 21
    const val TOP_FRACTION = 0.26f // panel top as a fraction of screen height
}

private val BLUR_RADIUS = 22.dp        // more = blurrier
private const val TINT_ALPHA = 0.28f   // dark tint over the blur (0 = pure blur)
private val FALLBACK_BG = Color(0xE6404042) // used if the screenshot fails

// ----------------------------------------------------------------- state

data class StreamLevel(val stream: Int, val level: Int, val max: Int) {
    val fraction: Float get() = if (max == 0) 0f else level.toFloat() / max
}

data class PanelState(
    val visible: Boolean = false,
    val expanded: Boolean = false,
    val backdrop: ImageBitmap? = null,
    val screenW: Int = 0,
    val screenH: Int = 0,
    val levels: List<StreamLevel> = emptyList(),
    val active: Int = AudioManager.STREAM_MUSIC,
)

// ----------------------------------------------------------------- root

@Composable
fun VolumePanel(
    state: PanelState,
    onLevel: (stream: Int, fraction: Float) -> Unit,
    onToggleExpand: () -> Unit,
    onCaptions: () -> Unit,
    onTouch: () -> Unit,
) {
    val visibleState = remember { MutableTransitionState(false) }
    LaunchedEffect(state.visible) { visibleState.targetState = state.visible }

    AnimatedVisibility(
        visibleState = visibleState,
        modifier = Modifier.fillMaxSize(),
        enter = fadeIn(tween(150)) + scaleIn(tween(150), 0.92f, TransformOrigin(1f, 0f)),
        exit = fadeOut(tween(150)) + scaleOut(tween(150), 0.92f, TransformOrigin(1f, 0f)),
    ) {
        if (state.expanded) {
            ExpandedPanel(state, onLevel, onTouch)
        } else {
            CompactPanel(state, onLevel, onToggleExpand, onCaptions, onTouch)
        }
    }
}

@Composable
private fun CompactPanel(
    state: PanelState,
    onLevel: (Int, Float) -> Unit,
    onToggleExpand: () -> Unit,
    onCaptions: () -> Unit,
    onTouch: () -> Unit,
) {
    val current = state.levels.firstOrNull { it.stream == state.active }
        ?: state.levels.firstOrNull()

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassSurface(state, RoundedCornerShape(28.dp), Modifier.fillMaxWidth().weight(1f)) {
            if (current != null) {
                VolumePill(
                    stream = current.stream,
                    level = current.fraction,
                    onLevel = { onLevel(current.stream, it) },
                    onTouch = onTouch,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            // "..." expands to the 4-slider panel
            Icon(
                Icons.Rounded.MoreHoriz,
                contentDescription = "More",
                tint = Color.White.copy(alpha = 0.75f),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 12.dp)
                    .size(26.dp)
                    .clickable { onToggleExpand() },
            )
        }
        GlassSurface(
            state,
            RoundedCornerShape(22.dp),
            Modifier.fillMaxWidth().height(44.dp).clickable { onCaptions() },
        ) {
            Icon(
                Icons.Rounded.Subtitles,
                contentDescription = "Captions",
                tint = Color.White,
                modifier = Modifier.align(Alignment.Center).size(24.dp),
            )
        }
    }
}

@Composable
private fun ExpandedPanel(
    state: PanelState,
    onLevel: (Int, Float) -> Unit,
    onTouch: () -> Unit,
) {
    GlassSurface(state, RoundedCornerShape(36.dp), Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(top = 14.dp, bottom = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = labelFor(state.active),
                color = Color.White,
                fontSize = 17.sp,
                modifier = Modifier.height(28.dp),
            )
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                state.levels.forEach { lv ->
                    VolumePill(
                        stream = lv.stream,
                        level = lv.fraction,
                        onLevel = { onLevel(lv.stream, it) },
                        onTouch = onTouch,
                        modifier = Modifier.fillMaxHeight(),
                    )
                }
            }
        }
    }
}

// ----------------------------------------------------------------- glass background

/**
 * Frosted-glass surface: the screenshot taken just before the panel appeared is
 * shifted so the part behind THIS surface lines up with the real screen, then blurred
 * and tinted. Blur is a snapshot, not live, but it looks right while the panel is up.
 */
@Composable
private fun GlassSurface(
    state: PanelState,
    shape: Shape,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val view = LocalView.current
    val density = LocalDensity.current
    var topLeft by remember { mutableStateOf(IntOffset.Zero) }

    Box(
        modifier
            .onGloballyPositioned { coords ->
                val p = coords.positionInWindow()
                val win = IntArray(2)
                view.getLocationOnScreen(win)
                topLeft = IntOffset(win[0] + p.x.roundToInt(), win[1] + p.y.roundToInt())
            }
            .clip(shape)
            .let { if (state.backdrop == null) it.background(FALLBACK_BG) else it }
            .border(1.dp, Color.White.copy(alpha = 0.16f), shape)
    ) {
        state.backdrop?.let { bitmap ->
            Image(
                bitmap = bitmap,
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier
                    .wrapContentSize(Alignment.TopStart, unbounded = true)
                    .size(
                        with(density) { state.screenW.toDp() },
                        with(density) { state.screenH.toDp() },
                    )
                    .offset { IntOffset(-topLeft.x, -topLeft.y) }
                    .blur(BLUR_RADIUS, BlurredEdgeTreatment.Unbounded),
            )
            Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = TINT_ALPHA)))
        }
        content()
    }
}

// ----------------------------------------------------------------- slider pill

@Composable
private fun VolumePill(
    stream: Int,
    level: Float,
    onLevel: (Float) -> Unit,
    onTouch: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(28.dp)
    val minFillPx = with(LocalDensity.current) { 56.dp.toPx() } // fill never shrinks below the icon
    var heightPx by remember { mutableIntStateOf(1) }
    val latestOnLevel by rememberUpdatedState(onLevel)
    val latestOnTouch by rememberUpdatedState(onTouch)

    fun fractionAt(y: Float): Float {
        val usable = (heightPx - minFillPx).coerceAtLeast(1f)
        return ((heightPx - y - minFillPx) / usable).coerceIn(0f, 1f)
    }

    val fillRatio =
        ((minFillPx + (heightPx - minFillPx).coerceAtLeast(0f) * level) / heightPx).coerceIn(0f, 1f)

    Box(
        modifier
            .width(56.dp)
            .clip(shape)
            .background(Color.White.copy(alpha = 0.28f))
            .onSizeChanged { heightPx = it.height.coerceAtLeast(1) }
            .pointerInput(Unit) {
                detectTapGestures {
                    latestOnTouch()
                    latestOnLevel(fractionAt(it.y))
                }
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(onDragStart = { latestOnTouch() }) { change, _ ->
                    change.consume()
                    latestOnTouch()
                    latestOnLevel(fractionAt(change.position.y))
                }
            }
    ) {
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(fillRatio)
                .background(Color.White)
        )
        Icon(
            imageVector = iconFor(stream, muted = level == 0f),
            contentDescription = null,
            tint = Color(0xFF3C3C3E),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp)
                .size(24.dp),
        )
    }
}

private fun iconFor(stream: Int, muted: Boolean): ImageVector = when (stream) {
    AudioManager.STREAM_MUSIC ->
        if (muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp
    AudioManager.STREAM_RING -> Icons.Rounded.Notifications
    AudioManager.STREAM_NOTIFICATION -> Icons.Rounded.NotificationsActive
    AudioManager.STREAM_ALARM -> Icons.Rounded.Alarm
    else -> Icons.Rounded.VolumeUp
}

private fun labelFor(stream: Int) = when (stream) {
    AudioManager.STREAM_MUSIC -> "Media"
    AudioManager.STREAM_RING -> "Ring"
    AudioManager.STREAM_NOTIFICATION -> "Notification"
    AudioManager.STREAM_ALARM -> "Alarm"
    AudioManager.STREAM_VOICE_CALL -> "Call"
    else -> "Volume"
}
