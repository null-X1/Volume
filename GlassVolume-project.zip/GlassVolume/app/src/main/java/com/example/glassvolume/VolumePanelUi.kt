package com.example.glassvolume

import android.media.AudioManager
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ----------------------------------------------------------------- tuning knobs

/** Sizes in dp. The window = panel + OVERSCAN on three sides + MARGIN_END up to the screen edge. */
object PanelMetrics {
    const val COMPACT_W = 56
    const val COMPACT_H = 252
    const val EXPANDED_W = 330
    const val EXPANDED_H = 270
    const val MARGIN_END = 21
    const val OVERSCAN = 14        // room for the rubber-band stretch to grow into
    const val TOP_FRACTION = 0.26f // panel top as a fraction of screen height
}

private val BLUR_RADIUS = 22.dp        // more = blurrier
private const val TINT_ALPHA = 0.28f   // dark tint over the blur (0 = pure blur)
private val FALLBACK_BG = Color(0xE6404042) // used if the screenshot fails

// ----------------------------------------------------------------- state

data class StreamLevel(val stream: Int, val level: Int, val max: Int) {
    val fraction: Float get() = if (max == 0) 0f else level.toFloat() / max
}

data class PanelState(
    val visible: Boolean = false,
    val expanded: Boolean = false,
    val backdrop: ImageBitmap? = null,
    val screenW: Int = 0,
    val screenH: Int = 0,
    val levels: List<StreamLevel> = emptyList(),
    val active: Int = AudioManager.STREAM_MUSIC,
    /** Goes up by one each time a key press hits the top or bottom of the range. */
    val bump: Int = 0,
    /** +1 = pressed up at max, -1 = pressed down at min. */
    val bumpDir: Int = 1,
    val ringerMode: Int = AudioManager.RINGER_MODE_NORMAL,
    /** Goes up by one each time the ringer mode changes. */
    val ringerTick: Int = 0,
)

// ----------------------------------------------------------------- rubber-band bump

@Stable
class BumpAnim {
    val stretch = Animatable(0f)
    val pulse = Animatable(0f)
    var dir by mutableIntStateOf(1)
}

/**
 * Plays the "hit the limit" effect every time [bump] changes: a quick stretch that springs
 * back with a wobble, plus an expanding ring. A pill that wasn't composed when the bump
 * happened ignores it, and so does one that isn't [enabled].
 */
@Composable
private fun rememberBumpAnim(bump: Int, dir: Int, enabled: Boolean): BumpAnim {
    val anim = remember { BumpAnim() }
    var seen by remember { mutableIntStateOf(bump) }
    LaunchedEffect(bump) {
        if (bump != seen) {
            seen = bump
            if (enabled) {
                anim.dir = dir
                coroutineScope {
                    launch {
                        anim.stretch.snapTo(0f)
                        anim.stretch.animateTo(1f, tween(60, easing = FastOutSlowInEasing))
                        anim.stretch.animateTo(0f, spring(dampingRatio = 0.35f, stiffness = 380f))
                    }
                    launch {
                        anim.pulse.snapTo(0f)
                        anim.pulse.animateTo(1f, tween(480, easing = LinearOutSlowInEasing))
                    }
                }
            }
        }
    }
    return anim
}

/** Grows upward from the bottom when pushing past max, squashes when pushing past min. */
private fun Modifier.bumpTransform(b: BumpAnim): Modifier = graphicsLayer {
    val s = b.stretch.value
    val up = b.dir >= 0
    transformOrigin = TransformOrigin(0.5f, 1f)
    scaleX = 1f + (if (up) 0.10f else 0.07f) * s
    scaleY = 1f + (if (up) 0.07f else -0.06f) * s
}

// ----------------------------------------------------------------- root

@Composable
fun VolumePanel(
    state: PanelState,
    onLevel: (stream: Int, fraction: Float) -> Unit,
    onToggleExpand: () -> Unit,
    onMode: () -> Unit,
    onTouch: () -> Unit,
) {
    // 1 = parked off the right edge of the screen, 0 = in place.
    val slide = remember { Animatable(1f) }
    LaunchedEffect(state.visible) {
        if (state.visible) {
            slide.animateTo(0f, spring(dampingRatio = 0.7f, stiffness = 340f))
        } else {
            slide.animateTo(1f, tween(200, easing = FastOutLinearInEasing))
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val s = slide.value
                translationX = s * size.width
                alpha = (1f - s).coerceIn(0f, 1f)
            }
            .padding(
                start = PanelMetrics.OVERSCAN.dp,
                top = PanelMetrics.OVERSCAN.dp,
                bottom = PanelMetrics.OVERSCAN.dp,
                end = PanelMetrics.MARGIN_END.dp,
            )
    ) {
        AnimatedContent(
            targetState = state.expanded,
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.TopEnd,
            transitionSpec = {
                (fadeIn(tween(160)) +
                    scaleIn(spring(dampingRatio = 0.7f, stiffness = 380f), 0.3f, TransformOrigin(1f, 0f))) togetherWith
                    (fadeOut(tween(110)) + scaleOut(tween(160), 0.6f, TransformOrigin(1f, 0f)))
            },
            label = "panel",
        ) { isExpanded ->
            if (isExpanded) {
                ExpandedPanel(
                    state, onLevel, onTouch,
                    Modifier.size(PanelMetrics.EXPANDED_W.dp, PanelMetrics.EXPANDED_H.dp),
                )
            } else {
                CompactPanel(
                    state, onLevel, onToggleExpand, onMode, onTouch,
                    Modifier.size(PanelMetrics.COMPACT_W.dp, PanelMetrics.COMPACT_H.dp),
                )
            }
        }
    }
}

// ----------------------------------------------------------------- compact

@Composable
private fun CompactPanel(
    state: PanelState,
    onLevel: (Int, Float) -> Unit,
    onToggleExpand: () -> Unit,
    onMode: () -> Unit,
    onTouch: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val current = state.levels.firstOrNull { it.stream == state.active }
        ?: state.levels.firstOrNull()
    val bump = rememberBumpAnim(state.bump, state.bumpDir, enabled = true)

    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassSurface(
            state,
            RoundedCornerShape(28.dp),
            Modifier.fillMaxWidth().weight(1f).bumpTransform(bump),
        ) {
            if (current != null) {
                VolumePill(
                    stream = current.stream,
                    level = current.fraction,
                    bump = bump,
                    applyTransform = false,
                    enterIndex = 0,
                    onLevel = { onLevel(current.stream, it) },
                    onTouch = onTouch,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            // the three dots ripple, and tapping them opens the 4-slider panel
            MoreDots(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 8.dp)
                    .clickable { onToggleExpand() }
                    .padding(horizontal = 6.dp, vertical = 4.dp),
            )
        }
        ModeButton(state, onMode)
    }
}

@Composable
private fun MoreDots(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "dots")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing)),
        label = "dotPhase",
    )
    Canvas(modifier.size(width = 26.dp, height = 14.dp)) {
        val r = 2.5.dp.toPx()
        for (i in 0..2) {
            val angle = phase * 2f * PI.toFloat() - i * 0.9f
            val dy = sin(angle) * 2.6.dp.toPx()
            drawCircle(
                color = Color.White.copy(alpha = 0.85f),
                radius = r,
                center = Offset(size.width * (0.2f + 0.3f * i), size.height / 2f + dy),
            )
        }
    }
}

/** Cycles normal -> vibrate -> silent. Tints amber / red, icon swaps with a pop. */
@Composable
private fun ModeButton(state: PanelState, onMode: () -> Unit) {
    val mode = state.ringerMode
    val tint by animateColorAsState(
        targetValue = when (mode) {
            AudioManager.RINGER_MODE_VIBRATE -> Color(0xFFFFB020).copy(alpha = 0.9f)
            AudioManager.RINGER_MODE_SILENT -> SilentRed.copy(alpha = 0.9f)
            else -> Color.Transparent
        },
        animationSpec = tween(260),
        label = "modeTint",
    )
    var pressed by remember { mutableStateOf(false) }
    val press by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring<Float>(dampingRatio = 0.45f, stiffness = 520f),
        label = "modePress",
    )
    val amp = remember { Animatable(0f) }
    LaunchedEffect(state.ringerTick) {
        amp.snapTo(1f)
        amp.animateTo(0f, spring(dampingRatio = 0.2f, stiffness = 200f))
    }
    val latestOnMode by rememberUpdatedState(onMode)

    GlassSurface(
        state,
        RoundedCornerShape(22.dp),
        Modifier
            .fillMaxWidth()
            .height(44.dp)
            .graphicsLayer {
                scaleX = press
                scaleY = press
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { latestOnMode() },
                )
            },
    ) {
        Box(Modifier.matchParentSize().background(tint))
        AnimatedContent(
            targetState = mode,
            modifier = Modifier.align(Alignment.Center),
            transitionSpec = {
                (fadeIn(tween(120)) + scaleIn(spring(dampingRatio = 0.45f, stiffness = 420f), 0.3f)) togetherWith
                    (fadeOut(tween(90)) + scaleOut(tween(120), 0.3f))
            },
            label = "modeIcon",
        ) { m ->
            ModeIcon(m, amp.value)
        }
    }
}

// ----------------------------------------------------------------- expanded

@Composable
private fun ExpandedPanel(
    state: PanelState,
    onLevel: (Int, Float) -> Unit,
    onTouch: () -> Unit,
    modifier: Modifier = Modifier,
) {
    GlassSurface(state, RoundedCornerShape(36.dp), modifier) {
        Column(
            Modifier.fillMaxSize().padding(top = 14.dp, bottom = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.height(28.dp), contentAlignment = Alignment.Center) {
                Crossfade(targetState = state.active, label = "title") { s ->
                    Text(text = labelFor(s), color = Color.White, fontSize = 17.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                state.levels.forEachIndexed { index, lv ->
                    val bump = rememberBumpAnim(
                        state.bump, state.bumpDir, enabled = lv.stream == state.active,
                    )
                    VolumePill(
                        stream = lv.stream,
                        level = lv.fraction,
                        bump = bump,
                        applyTransform = true,
                        enterIndex = index,
                        onLevel = { onLevel(lv.stream, it) },
                        onTouch = onTouch,
                        modifier = Modifier.fillMaxHeight(),
                    )
                }
            }
        }
    }
}

// ----------------------------------------------------------------- glass background

/**
 * Frosted-glass surface: the screenshot taken just before the panel appeared is
 * shifted so the part behind THIS surface lines up with the real screen, then blurred
 * and tinted. It's a snapshot, not a live blur (see README).
 */
@Composable
private fun GlassSurface(
    state: PanelState,
    shape: Shape,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val view = LocalView.current
    val density = LocalDensity.current
    var topLeft by remember { mutableStateOf(IntOffset.Zero) }

    Box(
        modifier
            .onGloballyPositioned { coords ->
                val p = coords.positionInWindow()
                val win = IntArray(2)
                view.getLocationOnScreen(win)
                topLeft = IntOffset(win[0] + p.x.roundToInt(), win[1] + p.y.roundToInt())
            }
            .clip(shape)
            .let { if (state.backdrop == null) it.background(FALLBACK_BG) else it }
            .border(1.dp, Color.White.copy(alpha = 0.16f), shape)
    ) {
        state.backdrop?.let { bitmap ->
            Image(
                bitmap = bitmap,
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier
                    .wrapContentSize(Alignment.TopStart, unbounded = true)
                    .size(
                        with(density) { state.screenW.toDp() },
                        with(density) { state.screenH.toDp() },
                    )
                    .offset { IntOffset(-topLeft.x, -topLeft.y) }
                    .blur(BLUR_RADIUS, BlurredEdgeTreatment.Unbounded),
            )
            Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = TINT_ALPHA)))
        }
        content()
    }
}

// ----------------------------------------------------------------- slider pill

@Composable
private fun VolumePill(
    stream: Int,
    level: Float,
    bump: BumpAnim,
    applyTransform: Boolean,
    enterIndex: Int,
    onLevel: (Float) -> Unit,
    onTouch: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(28.dp)
    val minFillPx = with(LocalDensity.current) { 56.dp.toPx() } // fill never shrinks below the icon
    var heightPx by remember { mutableIntStateOf(1) }
    var dragging by remember { mutableStateOf(false) }
    val latestOnLevel by rememberUpdatedState(onLevel)
    val latestOnTouch by rememberUpdatedState(onTouch)

    // The fill springs to each new level: snappy while dragging, bouncy otherwise.
    val animLevel by animateFloatAsState(
        targetValue = level,
        animationSpec = if (dragging) {
            spring<Float>(dampingRatio = 1f, stiffness = Spring.StiffnessHigh)
        } else {
            spring<Float>(dampingRatio = 0.62f, stiffness = Spring.StiffnessMediumLow)
        },
        label = "level",
    )

    // Every level change gives the icon a fresh wiggle (impulses add up if you keep going).
    val amp = remember { Animatable(0f) }
    val step = (level * 100f).roundToInt()
    LaunchedEffect(step) {
        amp.snapTo((amp.value + 0.9f).coerceIn(-1.4f, 1.4f))
        amp.animateTo(0f, spring(dampingRatio = 0.22f, stiffness = 240f))
    }

    // Pills pop in one after another.
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(enterIndex * 45L)
        enter.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 320f))
    }

    fun fractionAt(y: Float): Float {
        val usable = (heightPx - minFillPx).coerceAtLeast(1f)
        return ((heightPx - y - minFillPx) / usable).coerceIn(0f, 1f)
    }

    val fillRatio = (
        (minFillPx + (heightPx - minFillPx).coerceAtLeast(0f) * animLevel.coerceIn(0f, 1f)) / heightPx
        ).coerceIn(0f, 1f)
    val accent = accentFor(stream)

    Box(
        modifier
            .width(56.dp)
            .graphicsLayer {
                val e = enter.value
                transformOrigin = TransformOrigin(0.5f, 1f)
                var sx = 1f
                var sy = 0.75f + 0.25f * e
                if (applyTransform) {
                    val s = bump.stretch.value
                    val up = bump.dir >= 0
                    sx += (if (up) 0.10f else 0.07f) * s
                    sy += (if (up) 0.07f else -0.06f) * s
                }
                scaleX = sx
                scaleY = sy
                alpha = e.coerceIn(0f, 1f)
            }
            .clip(shape)
            .background(Color.White.copy(alpha = 0.28f))
            .onSizeChanged { heightPx = it.height.coerceAtLeast(1) }
            .pointerInput(Unit) {
                detectTapGestures {
                    latestOnTouch()
                    latestOnLevel(fractionAt(it.y))
                }
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = {
                        dragging = true
                        latestOnTouch()
                    },
                    onDragEnd = { dragging = false },
                    onDragCancel = { dragging = false },
                    onVerticalDrag = { change, _ ->
                        change.consume()
                        latestOnTouch()
                        latestOnLevel(fractionAt(change.position.y))
                    },
                )
            }
    ) {
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(fillRatio)
                .background(Color.White)
        )
        // expanding ring behind the icon whenever the limit is hit
        Canvas(
            Modifier
                .align(Alignment.BottomCenter)
                .offset(y = 6.dp)
                .size(72.dp)
        ) {
            val p = bump.pulse.value
            if (p > 0f && p < 1f) {
                val r = 12.dp.toPx() + (38.dp.toPx() - 12.dp.toPx()) * p
                drawCircle(
                    color = accent.copy(alpha = (1f - p) * 0.6f),
                    radius = r,
                    style = Stroke(width = 3.dp.toPx()),
                )
            }
        }
        StreamIcon(
            stream = stream,
            level = level,
            kick = amp.value,
            expand = sin(bump.pulse.value * PI.toFloat()),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp),
        )
    }
}

private fun labelFor(stream: Int) = when (stream) {
    AudioManager.STREAM_MUSIC -> "Media"
    AudioManager.STREAM_RING -> "Ring"
    AudioManager.STREAM_NOTIFICATION -> "Notification"
    AudioManager.STREAM_ALARM -> "Alarm"
    AudioManager.STREAM_VOICE_CALL -> "Call"
    else -> "Volume"
}
