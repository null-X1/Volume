package com.example.glassvolume

import android.media.AudioManager
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ----------------------------------------------------------------- layout constants

/** Sizes in dp. The window = panel + OVERSCAN on the inner side + MARGIN_END out to the screen edge. */
object PanelMetrics {
    const val COMPACT_W = 56
    const val COMPACT_H = 252
    const val EXPANDED_W = 330
    const val EXPANDED_H = 270
    const val MARGIN_END = 21
    const val OVERSCAN = 14        // room for the rubber-band stretch to grow into
    const val THIN_W = 8           // the thin line itself
    const val THIN_H = 130         // ...and how tall it is
    const val THIN_WIN_W = 22      // inner width of the window while it is a thin line
}

private val FALLBACK_BG = Color(0xE6404042) // used until / unless a screenshot is available

// ----------------------------------------------------------------- state

@Immutable
data class StreamLevel(
    val stream: Int,
    val level: Int,
    val max: Int,
    val muted: Boolean = false,
) {
    /** What the slider shows. A muted stream shows empty even if its stored level is high. */
    val fraction: Float get() = if (max == 0 || muted) 0f else level.toFloat() / max
}

@Immutable
data class PanelState(
    val visible: Boolean = false,
    /** The panel is composed at all. False while it is hidden, so nothing animates in the dark. */
    val alive: Boolean = false,
    val expanded: Boolean = false,
    val backdrop: ImageBitmap? = null,
    val screenW: Int = 0,
    val screenH: Int = 0,
    val levels: List<StreamLevel> = emptyList(),
    val active: Int = AudioManager.STREAM_MUSIC,
    /** Goes up by one each time a key press hits the top or bottom of the range. */
    val bump: Int = 0,
    /** +1 = pressed up at max, -1 = pressed down at min. */
    val bumpDir: Int = 1,
    val ringerMode: Int = AudioManager.RINGER_MODE_NORMAL,
    /** Goes up by one each time the ringer mode changes. */
    val ringerTick: Int = 0,
    /** Repeated key presses shrink the compact panel into a thin line. */
    val thin: Boolean = false,
    val config: GlassConfig = GlassConfig(),
)

// ----------------------------------------------------------------- rubber-band bump

@Stable
class BumpAnim {
    val stretch = Animatable(0f)
    val pulse = Animatable(0f)
    var dir by mutableIntStateOf(1)
}

/**
 * Plays the "hit the limit" effect every time [bump] changes: a quick stretch that springs
 * back with a wobble, plus an expanding ring. A pill that wasn't composed when the bump
 * happened ignores it, and so does one that isn't [enabled].
 */
@Composable
private fun rememberBumpAnim(bump: Int, dir: Int, enabled: Boolean): BumpAnim {
    val anim = remember { BumpAnim() }
    var seen by remember { mutableIntStateOf(bump) }
    LaunchedEffect(bump) {
        if (bump != seen) {
            seen = bump
            if (enabled) {
                anim.dir = dir
                coroutineScope {
                    launch {
                        anim.stretch.snapTo(0f)
                        anim.stretch.animateTo(1f, tween(60, easing = FastOutSlowInEasing))
                        anim.stretch.animateTo(0f, spring(dampingRatio = 0.35f, stiffness = 380f))
                    }
                    launch {
                        anim.pulse.snapTo(0f)
                        anim.pulse.animateTo(1f, tween(480, easing = LinearOutSlowInEasing))
                    }
                }
            }
        }
    }
    return anim
}

/** Grows upward from the bottom when pushing past max, squashes when pushing past min. */
private fun Modifier.bumpTransform(b: BumpAnim): Modifier = graphicsLayer {
    val s = b.stretch.value
    val up = b.dir >= 0
    transformOrigin = TransformOrigin(0.5f, 1f)
    scaleX = 1f + (if (up) 0.10f else 0.07f) * s
    scaleY = 1f + (if (up) 0.07f else -0.06f) * s
}

/**
 * Size glides from the full panel down to the thin line (a little wider while pressed).
 * The parent hands over loose constraints, so the full size is just their maximum.
 */
private fun Modifier.thinSize(thin: State<Float>, grow: State<Float>): Modifier =
    layout { measurable, constraints ->
        val fullW = constraints.maxWidth
        val fullH = constraints.maxHeight
        val slimW = (PanelMetrics.THIN_W + 6f * grow.value).dp.roundToPx()
        val slimH = PanelMetrics.THIN_H.dp.roundToPx().coerceAtMost(fullH)
        val t = thin.value.coerceIn(0f, 1f)
        val w = (fullW + (slimW - fullW) * t).roundToInt().coerceIn(1, fullW.coerceAtLeast(1))
        val h = (fullH + (slimH - fullH) * t).roundToInt().coerceIn(1, fullH.coerceAtLeast(1))
        val p = measurable.measure(Constraints.fixed(w, h))
        layout(w, h) { p.placeRelative(0, 0) }
    }

/** Height glides from [full] down to nothing, for the ringer button that the thin line hides. */
private fun Modifier.thinCollapse(thin: State<Float>, full: Dp): Modifier =
    layout { measurable, constraints ->
        val h = (full.roundToPx() * (1f - thin.value.coerceIn(0f, 1f))).roundToInt()
        val w = constraints.maxWidth.coerceAtLeast(0)
        val p = measurable.measure(Constraints.fixed(w, h))
        layout(w, h) { p.placeRelative(0, 0) }
    }

// ----------------------------------------------------------------- root

@Composable
fun VolumePanel(
    state: PanelState,
    onLevel: (stream: Int, fraction: Float) -> Unit,
    onToggleExpand: () -> Unit,
    onMode: () -> Unit,
    onTouch: () -> Unit,
    onThinTap: () -> Unit,
) {
    val right = state.config.rightSide
    val side = if (right) 1f else -1f
    val originX = if (right) 1f else 0f

    // 0 = normal compact panel, 1 = thin line
    val thin = animateFloatAsState(
        targetValue = if (state.thin && !state.expanded) 1f else 0f,
        animationSpec = spring<Float>(dampingRatio = 0.78f, stiffness = 300f),
        label = "thin",
    )

    // 1 = parked off the screen edge, 0 = in place.
    val slide = remember { Animatable(1f) }
    LaunchedEffect(state.visible) {
        if (state.visible) {
            slide.animateTo(0f, spring(dampingRatio = 0.62f, stiffness = 300f))
        } else {
            slide.animateTo(1f, tween(220, easing = FastOutLinearInEasing))
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val s = slide.value
                val k = (1f - s).coerceIn(0f, 1.2f)
                transformOrigin = TransformOrigin(originX, 0.35f)
                cameraDistance = 14f * density
                translationX = s * size.width * side
                rotationY = 38f * s.coerceAtLeast(0f) * side
                scaleX = 0.82f + 0.18f * k
                scaleY = 0.82f + 0.18f * k
                alpha = (1f - s).coerceIn(0f, 1f)
            }
            .padding(
                start = (if (right) PanelMetrics.OVERSCAN else PanelMetrics.MARGIN_END).dp,
                top = PanelMetrics.OVERSCAN.dp,
                bottom = PanelMetrics.OVERSCAN.dp,
                end = (if (right) PanelMetrics.MARGIN_END else PanelMetrics.OVERSCAN).dp,
            )
    ) {
        AnimatedContent(
            targetState = state.expanded,
            modifier = Modifier.fillMaxSize(),
            contentAlignment = if (right) Alignment.TopEnd else Alignment.TopStart,
            transitionSpec = {
                (fadeIn(tween(160)) +
                    scaleIn(spring(dampingRatio = 0.7f, stiffness = 380f), 0.3f, TransformOrigin(originX, 0f))) togetherWith
                    (fadeOut(tween(110)) + scaleOut(tween(160), 0.6f, TransformOrigin(originX, 0f)))
            },
            label = "panel",
        ) { isExpanded ->
            if (isExpanded) {
                ExpandedPanel(
                    state, onLevel, onTouch,
                    Modifier.size(PanelMetrics.EXPANDED_W.dp, PanelMetrics.EXPANDED_H.dp),
                )
            } else {
                CompactPanel(
                    state, onLevel, onToggleExpand, onMode, onTouch, thin, onThinTap,
                    Modifier.size(PanelMetrics.COMPACT_W.dp, PanelMetrics.COMPACT_H.dp),
                )
            }
        }
    }
}

// ----------------------------------------------------------------- compact

@Composable
private fun CompactPanel(
    state: PanelState,
    onLevel: (Int, Float) -> Unit,
    onToggleExpand: () -> Unit,
    onMode: () -> Unit,
    onTouch: () -> Unit,
    thin: State<Float>,
    onThinTap: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val current = state.levels.firstOrNull { it.stream == state.active }
        ?: state.levels.firstOrNull()
    val bump = rememberBumpAnim(state.bump, state.bumpDir, enabled = true)
    val right = state.config.rightSide
    val side = if (right) 1f else -1f

    // the thin line fattens a little while a finger is on it
    var held by remember { mutableStateOf(false) }
    val grow = animateFloatAsState(
        targetValue = if (held) 1f else 0f,
        animationSpec = spring<Float>(dampingRatio = 0.55f, stiffness = 480f),
        label = "thinGrow",
    )

    Column(
        modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalAlignment = if (right) Alignment.End else Alignment.Start,
    ) {
        Box(
            Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = if (right) Alignment.TopEnd else Alignment.TopStart,
        ) {
        GlassSurface(
            state,
            RoundedCornerShape(28.dp),
            Modifier
                .thinSize(thin, grow)
                .graphicsLayer {
                    // the thin line sits a little in from the screen edge
                    translationX = side * thin.value * (PanelMetrics.MARGIN_END - 19).dp.toPx()
                }
                .bumpTransform(bump),
        ) {
            if (current != null) {
                VolumePill(
                    stream = current.stream,
                    level = current.fraction,
                    bump = bump,
                    applyTransform = false,
                    enterIndex = 0,
                    onLevel = { onLevel(current.stream, it) },
                    onTouch = onTouch,
                    modifier = Modifier.fillMaxSize(),
                    thin = thin,
                    onThinTap = onThinTap,
                    onPressChange = { held = it },
                )
            }
            // the three dots ripple, and tapping them opens the 4-slider panel
            MoreDots(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 8.dp)
                    .graphicsLayer { alpha = (1f - 1.6f * thin.value).coerceIn(0f, 1f) }
                    .clickable(enabled = !state.thin) { onToggleExpand() }
                    .padding(horizontal = 6.dp, vertical = 4.dp),
            )
        }
        }
        ModeButton(state, onMode, thin)
    }
}

@Composable
private fun MoreDots(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "dots")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing)),
        label = "dotPhase",
    )
    Canvas(modifier.size(width = 26.dp, height = 14.dp)) {
        val r = 2.5.dp.toPx()
        for (i in 0..2) {
            val angle = phase * 2f * PI.toFloat() - i * 0.9f
            val dy = sin(angle) * 2.6.dp.toPx()
            drawCircle(
                color = Color.White.copy(alpha = 0.85f),
                radius = r,
                center = Offset(size.width * (0.2f + 0.3f * i), size.height / 2f + dy),
            )
        }
    }
}

/** Cycles normal -> vibrate -> silent. Tints amber / red, icon swaps with a pop. */
@Composable
private fun ModeButton(state: PanelState, onMode: () -> Unit, thin: State<Float>) {
    val mode = state.ringerMode
    val tint by animateColorAsState(
        targetValue = when (mode) {
            AudioManager.RINGER_MODE_VIBRATE -> Color(0xFFFFB020).copy(alpha = 0.9f)
            AudioManager.RINGER_MODE_SILENT -> SilentRed.copy(alpha = 0.9f)
            else -> Color.Transparent
        },
        animationSpec = tween(260),
        label = "modeTint",
    )
    var pressed by remember { mutableStateOf(false) }
    val press by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring<Float>(dampingRatio = 0.45f, stiffness = 520f),
        label = "modePress",
    )
    val amp = remember { Animatable(0f) }
    LaunchedEffect(state.ringerTick) {
        amp.snapTo(1f)
        amp.animateTo(0f, spring(dampingRatio = 0.2f, stiffness = 200f))
    }
    val latestOnMode by rememberUpdatedState(onMode)
    val rise = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(140)
        rise.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 300f))
    }

    GlassSurface(
        state,
        RoundedCornerShape(22.dp),
        Modifier
            .fillMaxWidth()
            .thinCollapse(thin, 44.dp)
            .graphicsLayer {
                translationY = (1f - rise.value) * 36.dp.toPx()
                alpha = rise.value.coerceIn(0f, 1f) * (1f - 1.6f * thin.value).coerceIn(0f, 1f)
                scaleX = press
                scaleY = press
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { latestOnMode() },
                )
            },
    ) {
        Box(Modifier.matchParentSize().background(tint))
        AnimatedContent(
            targetState = mode,
            modifier = Modifier.align(Alignment.Center),
            transitionSpec = {
                (fadeIn(tween(120)) + scaleIn(spring(dampingRatio = 0.45f, stiffness = 420f), 0.3f)) togetherWith
                    (fadeOut(tween(90)) + scaleOut(tween(120), 0.3f))
            },
            label = "modeIcon",
        ) { m ->
            ModeIcon(m, amp.value)
        }
    }
}

// ----------------------------------------------------------------- expanded

@Composable
private fun ExpandedPanel(
    state: PanelState,
    onLevel: (Int, Float) -> Unit,
    onTouch: () -> Unit,
    modifier: Modifier = Modifier,
) {
    GlassSurface(state, RoundedCornerShape(36.dp), modifier) {
        Column(
            Modifier.fillMaxSize().padding(top = 14.dp, bottom = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.height(28.dp), contentAlignment = Alignment.Center) {
                Crossfade(targetState = state.active, label = "title") { s ->
                    Text(text = labelFor(s), color = Color.White, fontSize = 17.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                state.levels.forEachIndexed { index, lv ->
                    val bump = rememberBumpAnim(
                        state.bump, state.bumpDir, enabled = lv.stream == state.active,
                    )
                    VolumePill(
                        stream = lv.stream,
                        level = lv.fraction,
                        bump = bump,
                        applyTransform = true,
                        enterIndex = index,
                        onLevel = { onLevel(lv.stream, it) },
                        onTouch = onTouch,
                        modifier = Modifier.fillMaxHeight(),
                    )
                }
            }
        }
    }
}

// ----------------------------------------------------------------- glass background

/**
 * Frosted-glass surface. The service hands over a screenshot that is already blurred (on the
 * CPU, once per frame it captures), so drawing here is just copying the part of it that lies
 * behind this surface. No per-frame GPU blur, which is what made sliding choppy.
 */
@Composable
private fun GlassSurface(
    state: PanelState,
    shape: Shape,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val view = LocalView.current
    val cfg = state.config
    var topLeft by remember { mutableStateOf(IntOffset.Zero) }

    Box(
        modifier
            .onGloballyPositioned { coords ->
                val p = coords.positionInWindow()
                val win = IntArray(2)
                view.getLocationOnScreen(win)
                topLeft = IntOffset(win[0] + p.x.roundToInt(), win[1] + p.y.roundToInt())
            }
            .clip(shape)
            .border(1.dp, Color.White.copy(alpha = 0.16f), shape)
    ) {
        Box(
            Modifier
                .matchParentSize()
                .graphicsLayer { alpha = cfg.glass }
        ) {
            Crossfade(
                targetState = state.backdrop,
                modifier = Modifier.fillMaxSize(),
                animationSpec = tween(260),
                label = "backdrop",
            ) { bitmap ->
                if (bitmap == null) {
                    Box(Modifier.fillMaxSize().background(FALLBACK_BG))
                } else {
                    Canvas(Modifier.fillMaxSize()) {
                        val sx = bitmap.width.toFloat() / state.screenW.coerceAtLeast(1)
                        val sy = bitmap.height.toFloat() / state.screenH.coerceAtLeast(1)
                        val x = (topLeft.x * sx).roundToInt().coerceIn(0, bitmap.width - 1)
                        val y = (topLeft.y * sy).roundToInt().coerceIn(0, bitmap.height - 1)
                        val w = (size.width * sx).roundToInt().coerceIn(1, bitmap.width - x)
                        val h = (size.height * sy).roundToInt().coerceIn(1, bitmap.height - y)
                        drawImage(
                            image = bitmap,
                            srcOffset = IntOffset(x, y),
                            srcSize = IntSize(w, h),
                            dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt()),
                            filterQuality = FilterQuality.Medium,
                        )
                    }
                }
            }
            if (state.backdrop != null) {
                Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = cfg.tint)))
            }
        }
        content()
    }
}

// ----------------------------------------------------------------- slider pill

/**
 * One vertical slider.
 *  - While a finger drags, the fill sits exactly under the finger (no smoothing lag). The real
 *    volume moves in whole steps behind it. Past either end the pill stretches like rubber.
 *  - On release the fill glides on a spring from where the finger was to the exact step.
 *  - Level changes from the keys (or anywhere else) animate on a spring too, and a new change
 *    simply re-aims the running animation, so held keys stay fluid.
 *  - Tapping jumps to the tapped position (or, on the thin line, brings the full panel back).
 *  - The fill is truly empty at 0 / muted; the icon turns dark when it sits on the white fill.
 *
 * Everything that changes every frame is read in the draw / graphicsLayer phase, so the pill
 * is not recomposed or re-laid-out while it moves.
 */
@Composable
private fun VolumePill(
    stream: Int,
    level: Float,
    bump: BumpAnim,
    applyTransform: Boolean,
    enterIndex: Int,
    onLevel: (Float) -> Unit,
    onTouch: () -> Unit,
    modifier: Modifier = Modifier,
    thin: State<Float>? = null,
    onThinTap: (() -> Unit)? = null,
    onPressChange: (Boolean) -> Unit = {},
) {
    val shape = RoundedCornerShape(28.dp)
    val density = LocalDensity.current
    var heightPx by remember { mutableIntStateOf(1) }
    var pressed by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    val dragValue = remember { mutableFloatStateOf(0f) }
    val dragPull = remember { mutableFloatStateOf(0f) }
    val shown = remember { Animatable(level) }
    val pull = remember { Animatable(0f) }
    // true between the finger lifting and the settle animation taking over (no one-frame jump)
    var releasePending by remember { mutableStateOf(false) }
    val latestOnLevel by rememberUpdatedState(onLevel)
    val latestOnTouch by rememberUpdatedState(onTouch)
    val latestOnThinTap by rememberUpdatedState(onThinTap)
    val latestOnPress by rememberUpdatedState(onPressChange)

    fun thinNow(): Float = thin?.value ?: 0f
    fun shownFraction(): Float =
        (if (dragging || releasePending) dragValue.floatValue else shown.value).coerceIn(0f, 1f)

    // Finger lifted: start the settle from exactly where the finger was; the stretch springs back.
    LaunchedEffect(dragging) {
        if (!dragging && releasePending) {
            shown.snapTo(dragValue.floatValue)
            pull.snapTo(dragPull.floatValue)
            releasePending = false
            launch { pull.animateTo(0f, spring(dampingRatio = 0.4f, stiffness = 360f)) }
        }
    }
    // Follow the real level whenever the finger is not on the pill.
    LaunchedEffect(level, dragging, releasePending) {
        if (!dragging && !releasePending) {
            shown.animateTo(level, spring(dampingRatio = 1f, stiffness = 260f))
        }
    }

    val grabState = animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = spring<Float>(dampingRatio = 0.55f, stiffness = 420f),
        label = "grab",
    )

    // Every level change gives the icon a fresh wiggle (impulses add up if you keep going).
    val amp = remember { Animatable(0f) }
    val step = (level * 100f).roundToInt()
    LaunchedEffect(step) {
        amp.snapTo((amp.value + 0.6f).coerceIn(-1f, 1f))
        amp.animateTo(0f, spring(dampingRatio = 0.22f, stiffness = 240f))
    }

    // Pills pop in one after another, and the fill rises with them.
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(enterIndex * 45L)
        enter.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 320f))
    }

    fun fractionAt(y: Float): Float = (1f - y / heightPx).coerceIn(0f, 1f)

    // How much of the icon the fill covers, in tenths, so it only changes while the fill
    // crosses the icon (and the pill isn't recomposed the rest of the time).
    val iconBottomPx = with(density) { 16.dp.toPx() }
    val iconSizePx = with(density) { 28.dp.toPx() }
    val coverage = remember {
        derivedStateOf {
            val f = shownFraction() * enter.value.coerceIn(0f, 1f)
            (((f * heightPx - iconBottomPx) / iconSizePx).coerceIn(0f, 1f) * 10f).roundToInt() / 10f
        }
    }
    val accent = accentFor(stream)

    Box(
        modifier
            .width(56.dp)
            .graphicsLayer {
                val e = enter.value
                val g = grabState.value
                transformOrigin = TransformOrigin(0.5f, 1f)
                var sx = 1f + 0.08f * g
                var sy = 0.75f + 0.25f * e + 0.02f * g
                val pv = if (dragging || releasePending) dragPull.floatValue else pull.value
                sy += pv * 0.30f
                sx -= abs(pv) * 0.08f
                if (applyTransform) {
                    val s = bump.stretch.value
                    val up = bump.dir >= 0
                    sx += (if (up) 0.10f else 0.07f) * s
                    sy += (if (up) 0.07f else -0.06f) * s
                }
                scaleX = sx
                scaleY = sy
                alpha = e.coerceIn(0f, 1f)
            }
            .clip(shape)
            .drawBehind {
                val f = shownFraction() * enter.value.coerceIn(0f, 1f)
                drawRect(Color.White.copy(alpha = 0.28f - 0.12f * thinNow() + 0.10f * grabState.value))
                drawRect(
                    color = Color.White,
                    topLeft = Offset(0f, size.height * (1f - f)),
                    size = Size(size.width, size.height * f),
                )
            }
            .onSizeChanged { heightPx = it.height.coerceAtLeast(1) }
            .pointerInput(Unit) {
                val slop = viewConfiguration.touchSlop
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    latestOnTouch()
                    pressed = true
                    latestOnPress(true)
                    val startY = down.position.y
                    val startFraction = shown.value.coerceIn(0f, 1f) // what is on screen right now
                    var moved = false
                    var lastY = startY
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        lastY = change.position.y
                        if (!change.pressed) break
                        val dy = startY - lastY
                        if (!moved && abs(dy) > slop) {
                            moved = true
                            dragValue.floatValue = startFraction
                            dragPull.floatValue = 0f
                            dragging = true
                        }
                        if (moved) {
                            change.consume()
                            latestOnTouch()
                            val raw = startFraction + dy / heightPx
                            val f = raw.coerceIn(0f, 1f)
                            dragValue.floatValue = f
                            dragPull.floatValue = (raw - f).coerceIn(-0.45f, 0.45f)
                            latestOnLevel(f)
                        }
                    }
                    if (moved) {
                        releasePending = true
                    } else {
                        latestOnTouch()
                        val tapThin = latestOnThinTap
                        if (tapThin != null && thinNow() > 0.5f) tapThin()
                        else latestOnLevel(fractionAt(lastY))
                    }
                    pressed = false
                    latestOnPress(false)
                    dragging = false
                }
            }
    ) {
        // expanding ring behind the icon whenever the limit is hit
        Canvas(
            Modifier
                .align(Alignment.BottomCenter)
                .offset(y = 6.dp)
                .size(72.dp)
        ) {
            val p = bump.pulse.value
            if (p > 0f && p < 1f) {
                val r = 12.dp.toPx() + (38.dp.toPx() - 12.dp.toPx()) * p
                drawCircle(
                    color = accent.copy(alpha = (1f - p) * 0.6f),
                    radius = r,
                    style = Stroke(width = 3.dp.toPx()),
                )
            }
        }
        PillIcon(
            stream = stream,
            level = level,
            amp = amp,
            bump = bump,
            coverage = coverage,
            thin = thin,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp),
        )
    }
}

/** Reads the per-frame animation values itself, so only this small piece recomposes. */
@Composable
private fun PillIcon(
    stream: Int,
    level: Float,
    amp: Animatable<Float, AnimationVector1D>,
    bump: BumpAnim,
    coverage: State<Float>,
    thin: State<Float>?,
    modifier: Modifier = Modifier,
) {
    StreamIcon(
        stream = stream,
        level = level,
        kick = amp.value,
        expand = sin(bump.pulse.value * PI.toFloat()),
        ink = lerp(Color.White, InkColor, coverage.value),
        modifier = modifier.graphicsLayer {
            alpha = (1f - 1.6f * (thin?.value ?: 0f)).coerceIn(0f, 1f)
        },
    )
}

private fun labelFor(stream: Int) = when (stream) {
    AudioManager.STREAM_MUSIC -> "Media"
    AudioManager.STREAM_RING -> "Ring"
    AudioManager.STREAM_NOTIFICATION -> "Notification"
    AudioManager.STREAM_ALARM -> "Alarm"
    AudioManager.STREAM_VOICE_CALL -> "Call"
    else -> "Volume"
}
