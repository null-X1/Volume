package com.example.glassvolume

import android.media.AudioManager
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.dp
import kotlin.math.abs

/*
 * Hand-drawn icons on a 24x24 grid. Every icon takes `kick`, a decaying spring value
 * (starts around 1, swings through negative, settles on 0) that the caller restarts
 * whenever something changes. That one number drives the swing / pop / shake.
 */

val InkColor = Color(0xFF3A3A3C)
val SilentRed = Color(0xFFFF4D5E)

fun accentFor(stream: Int): Color = when (stream) {
    AudioManager.STREAM_RING -> Color(0xFFFF9500)
    AudioManager.STREAM_NOTIFICATION -> Color(0xFFFF2D55)
    AudioManager.STREAM_ALARM -> Color(0xFF34C759)
    AudioManager.STREAM_VOICE_CALL -> Color(0xFF34C759)
    else -> Color(0xFF2F80ED)
}

// ------------------------------------------------------------------ stream icons

@Composable
fun StreamIcon(
    stream: Int,
    level: Float,
    kick: Float,
    expand: Float,
    modifier: Modifier = Modifier,
) {
    val accent = accentFor(stream)
    when (stream) {
        AudioManager.STREAM_RING -> BellIcon(kick, accent, false, modifier)
        AudioManager.STREAM_NOTIFICATION -> BellIcon(kick, accent, true, modifier)
        AudioManager.STREAM_ALARM -> AlarmIcon(kick, accent, modifier)
        else -> SpeakerIcon(level, kick, expand, accent, modifier)
    }
}

/** Speaker whose sound waves pop in and out with the level, and swell when `expand` > 0. */
@Composable
private fun SpeakerIcon(
    level: Float,
    kick: Float,
    expand: Float,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    val w1 by animateFloatAsState(
        targetValue = if (level > 0f) 1f else 0f,
        animationSpec = spring<Float>(dampingRatio = 0.5f, stiffness = 500f),
        label = "wave1",
    )
    val w2 by animateFloatAsState(
        targetValue = if (level > 0.34f) 1f else 0f,
        animationSpec = spring<Float>(dampingRatio = 0.5f, stiffness = 500f),
        label = "wave2",
    )
    val w3 by animateFloatAsState(
        targetValue = if (level > 0.67f) 1f else 0f,
        animationSpec = spring<Float>(dampingRatio = 0.5f, stiffness = 500f),
        label = "wave3",
    )
    val muted by animateFloatAsState(
        targetValue = if (level <= 0f) 1f else 0f,
        animationSpec = spring<Float>(dampingRatio = 0.55f, stiffness = 500f),
        label = "muted",
    )

    Canvas(modifier.size(28.dp)) {
        val u = size.minDimension / 24f
        scale(1f + 0.2f * kick, pivot = center) {
            val body = Path().apply {
                moveTo(3f * u, 9.2f * u)
                lineTo(7f * u, 9.2f * u)
                lineTo(12f * u, 5f * u)
                lineTo(12f * u, 19f * u)
                lineTo(7f * u, 14.8f * u)
                lineTo(3f * u, 14.8f * u)
                close()
            }
            drawPath(body, InkColor)
            drawPath(body, InkColor, style = Stroke(width = 1.5f * u, join = StrokeJoin.Round))

            val radii = floatArrayOf(4.2f, 7.4f, 10.4f)
            val waves = floatArrayOf(w1, w2, w3)
            for (i in 0..2) {
                val a = waves[i].coerceIn(0f, 1f)
                if (a > 0.01f) {
                    val r = radii[i] * (0.6f + 0.4f * waves[i]) * (1f + 0.25f * expand)
                    drawArc(
                        color = accent.copy(alpha = a),
                        startAngle = -42f,
                        sweepAngle = 84f,
                        useCenter = false,
                        topLeft = Offset((12f - r) * u, (12f - r) * u),
                        size = Size(2f * r * u, 2f * r * u),
                        style = Stroke(width = 2.1f * u, cap = StrokeCap.Round),
                    )
                }
            }

            val x = muted.coerceIn(0f, 1f)
            if (x > 0.01f) {
                val d = 6f * x
                drawLine(
                    SilentRed, Offset(15f * u, 9f * u), Offset((15f + d) * u, (9f + d) * u),
                    strokeWidth = 2.2f * u, cap = StrokeCap.Round,
                )
                drawLine(
                    SilentRed, Offset(21f * u, 9f * u), Offset((21f - d) * u, (9f + d) * u),
                    strokeWidth = 2.2f * u, cap = StrokeCap.Round,
                )
            }
        }
    }
}

/** Bell that swings from its top, with the clapper lagging behind. Optional notification dot. */
@Composable
private fun BellIcon(
    kick: Float,
    accent: Color,
    withDot: Boolean,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier.size(28.dp)) {
        val u = size.minDimension / 24f
        rotate(22f * kick, pivot = Offset(12f * u, 3f * u)) {
            drawBell(u, InkColor, -1.8f * kick)
            if (withDot) {
                val r = (2.7f + 0.7f * abs(kick)) * u
                drawCircle(Color.White, radius = r + 1.2f * u, center = Offset(18.6f * u, 5.2f * u))
                drawCircle(accent, radius = r, center = Offset(18.6f * u, 5.2f * u))
            }
        }
    }
}

/** Alarm clock: the whole clock shakes and the minute hand spins a little. */
@Composable
private fun AlarmIcon(kick: Float, accent: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(28.dp)) {
        val u = size.minDimension / 24f
        val c = Offset(12f * u, 13.4f * u)
        rotate(14f * kick, pivot = c) {
            drawCircle(accent, radius = 3.1f * u, center = Offset(5.2f * u, 5.6f * u))
            drawCircle(accent, radius = 3.1f * u, center = Offset(18.8f * u, 5.6f * u))
            drawCircle(InkColor, radius = 8f * u, center = c)
            drawLine(
                Color.White, c, Offset(15.2f * u, 15.2f * u),
                strokeWidth = 1.9f * u, cap = StrokeCap.Round,
            )
            rotate(45f * kick, pivot = c) {
                drawLine(
                    Color.White, c, Offset(12f * u, 8.6f * u),
                    strokeWidth = 1.9f * u, cap = StrokeCap.Round,
                )
            }
        }
    }
}

// ------------------------------------------------------------------ ringer-mode icons

@Composable
fun ModeIcon(mode: Int, kick: Float, modifier: Modifier = Modifier) {
    when (mode) {
        AudioManager.RINGER_MODE_VIBRATE -> VibrateGlyph(kick, modifier)
        AudioManager.RINGER_MODE_SILENT -> SilentGlyph(kick, modifier)
        else -> Canvas(modifier.size(26.dp)) {
            val u = size.minDimension / 24f
            rotate(20f * kick, pivot = Offset(12f * u, 3f * u)) {
                drawBell(u, Color.White, -1.8f * kick)
            }
        }
    }
}

/** Phone with buzzing lines on both sides. */
@Composable
private fun VibrateGlyph(kick: Float, modifier: Modifier = Modifier) {
    Canvas(modifier.size(26.dp)) {
        val u = size.minDimension / 24f
        val ink = Color.White
        rotate(12f * kick, pivot = center) {
            drawRoundRect(
                color = ink,
                topLeft = Offset(8f * u, 3.5f * u),
                size = Size(8f * u, 17f * u),
                cornerRadius = CornerRadius(2.2f * u),
                style = Stroke(width = 1.9f * u),
            )
            drawLine(
                ink, Offset(10.8f * u, 6.2f * u), Offset(13.2f * u, 6.2f * u),
                strokeWidth = 1.5f * u, cap = StrokeCap.Round,
            )
        }
        val a = (0.55f + 0.45f * abs(kick)).coerceIn(0f, 1f)
        val shift = 1.2f * kick
        val wave = ink.copy(alpha = a)
        drawLine(wave, Offset((4.6f - shift) * u, 8f * u), Offset((4.6f - shift) * u, 16f * u),
            strokeWidth = 1.9f * u, cap = StrokeCap.Round)
        drawLine(wave, Offset((2f - shift) * u, 10f * u), Offset((2f - shift) * u, 14f * u),
            strokeWidth = 1.9f * u, cap = StrokeCap.Round)
        drawLine(wave, Offset((19.4f + shift) * u, 8f * u), Offset((19.4f + shift) * u, 16f * u),
            strokeWidth = 1.9f * u, cap = StrokeCap.Round)
        drawLine(wave, Offset((22f + shift) * u, 10f * u), Offset((22f + shift) * u, 14f * u),
            strokeWidth = 1.9f * u, cap = StrokeCap.Round)
    }
}

/** Bell with a slash that draws itself in. */
@Composable
private fun SilentGlyph(kick: Float, modifier: Modifier = Modifier) {
    val slash = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        slash.animateTo(1f, tween(300, easing = FastOutSlowInEasing))
    }
    Canvas(modifier.size(26.dp)) {
        val u = size.minDimension / 24f
        rotate(-10f + 16f * kick, pivot = Offset(12f * u, 3f * u)) {
            drawBell(u, Color.White.copy(alpha = 0.92f), 0f)
        }
        val p = slash.value.coerceIn(0f, 1f)
        val start = Offset(4.5f * u, 4.5f * u)
        val end = Offset((4.5f + 15f * p) * u, (4.5f + 15f * p) * u)
        drawLine(SilentRed, start, end, strokeWidth = 4.8f * u, cap = StrokeCap.Round)
        drawLine(Color.White, start, end, strokeWidth = 2.2f * u, cap = StrokeCap.Round)
    }
}

// ------------------------------------------------------------------ shared drawing

private fun DrawScope.drawBell(u: Float, color: Color, clapperShift: Float) {
    val bell = Path().apply {
        moveTo(12f * u, 3f * u)
        cubicTo(8.7f * u, 3f * u, 6f * u, 5.7f * u, 6f * u, 9f * u)
        lineTo(6f * u, 13.4f * u)
        lineTo(4f * u, 16f * u)
        lineTo(4f * u, 17.2f * u)
        lineTo(20f * u, 17.2f * u)
        lineTo(20f * u, 16f * u)
        lineTo(18f * u, 13.4f * u)
        lineTo(18f * u, 9f * u)
        cubicTo(18f * u, 5.7f * u, 15.3f * u, 3f * u, 12f * u, 3f * u)
        close()
    }
    drawPath(bell, color)
    drawPath(bell, color, style = Stroke(width = 1.4f * u, join = StrokeJoin.Round))
    drawCircle(color, radius = 2f * u, center = Offset((12f + clapperShift) * u, 20.2f * u))
}
