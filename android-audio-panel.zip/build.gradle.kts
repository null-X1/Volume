// Top-level build file.
// Applied to all sub-projects: plugins are declared here and applied per-module.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.compose.compiler) apply false
}
