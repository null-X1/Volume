# ---------------------------------------------------------------------------
# Audio Panel - R8 / ProGuard rules
#
# The app talks to the platform through public Android APIs only (AudioManager,
# AudioEffect, WindowManager, VibrationEffect). No reflection and no hidden
# framework hooks are used, so only a small set of keeps is required.
# ---------------------------------------------------------------------------

# Keep the entry points referenced from the manifest / system.
-keep class com.noteedge.audiopanel.MainActivity { *; }
-keep class com.noteedge.audiopanel.overlay.OverlayPanelService { *; }

# Compose / Kotlin metadata: keep the generated Compose runtime plumbing intact.
-dontwarn org.jetbrains.annotations.**
-keepclassmembers class androidx.compose.runtime.** { *; }

# AudioEffect subclasses are instantiated through the platform playback
# framework; keep their public surface so control queries keep working.
-keep class android.media.audiofx.** { *; }
-keepclassmembers class * extends android.media.audiofx.AudioEffect {
    public <init>(...);
    public boolean hasControl();
}

# Keep annotations used by Compose's tooling checks.
-keepattributes RuntimeVisibleAnnotations,AnnotationDefault,InnerClasses,Signature
