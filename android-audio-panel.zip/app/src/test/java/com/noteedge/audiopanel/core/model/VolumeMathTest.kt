package com.noteedge.audiopanel.core.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VolumeMathTest {

    @Test
    fun fractionMapsRangeEnds() {
        assertEquals(0f, VolumeMath.fraction(0, 0, 15), 0.0001f)
        assertEquals(1f, VolumeMath.fraction(15, 0, 15), 0.0001f)
    }

    @Test
    fun fractionRebasesStreamsThatStartAboveZero() {
        // Voice call bottoms out at index 1 on many devices; 0% must still mean "off".
        assertEquals(0f, VolumeMath.fraction(1, 1, 7), 0.0001f)
        assertEquals(1f, VolumeMath.fraction(7, 1, 7), 0.0001f)
    }

    @Test
    fun fractionClampsOutOfRangeInput() {
        assertEquals(1f, VolumeMath.fraction(99, 0, 10), 0.0001f)
        assertEquals(0f, VolumeMath.fraction(-5, 0, 10), 0.0001f)
    }

    @Test
    fun indexForRoundTripsEveryStep() {
        for (index in 0..15) {
            val fraction = VolumeMath.fraction(index, 0, 15)
            assertEquals(index, VolumeMath.indexFor(fraction, 0, 15))
        }
    }

    @Test
    fun indexForClampsAndSurvivesDegenerateRange() {
        assertEquals(0, VolumeMath.indexFor(-1f, 0, 10))
        assertEquals(10, VolumeMath.indexFor(4f, 0, 10))
        assertEquals(5, VolumeMath.indexFor(0.7f, 5, 5))
    }

    @Test
    fun snapLandsOnDetentGrid() {
        assertEquals(0.5f, VolumeMath.snap(0.48f, 11), 0.0001f)
        assertEquals(0f, VolumeMath.snap(0.02f, 11), 0.0001f)
        assertEquals(1f, VolumeMath.snap(0.98f, 11), 0.0001f)
    }

    @Test
    fun snapWithoutDetentsOnlyClamps() {
        assertEquals(0.37f, VolumeMath.snap(0.37f, 1), 0.0001f)
        assertEquals(1f, VolumeMath.snap(3f, 0), 0.0001f)
    }

    @Test
    fun detentIndexCountsCrossedSteps() {
        assertEquals(0, VolumeMath.detentIndex(0f, 11))
        assertEquals(5, VolumeMath.detentIndex(0.53f, 11))
        assertEquals(10, VolumeMath.detentIndex(1f, 11))
        assertEquals(0, VolumeMath.detentIndex(0.9f, 1))
    }

    @Test
    fun percentRoundsToWholeNumbers() {
        assertEquals(0, VolumeMath.percent(0f))
        assertEquals(33, VolumeMath.percent(0.333f))
        assertEquals(100, VolumeMath.percent(2f))
    }

    @Test
    fun audibilityUsesEpsilon() {
        assertTrue(VolumeMath.isAudible(0.4f))
        assertFalse(VolumeMath.isAudible(0f))
        assertFalse(VolumeMath.isAudible(0.004f))
    }

    @Test
    fun approximatelyEqualUsesTolerance() {
        assertTrue(VolumeMath.approximatelyEqual(0.500f, 0.502f))
        assertFalse(VolumeMath.approximatelyEqual(0.500f, 0.560f))
    }
}
