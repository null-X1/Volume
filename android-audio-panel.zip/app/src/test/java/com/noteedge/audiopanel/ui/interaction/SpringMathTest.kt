package com.noteedge.audiopanel.ui.interaction

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpringMathTest {

    @Test
    fun settleStiffnessGrowsWithFeelAndStaysInRange() {
        val calm = SpringMath.settleStiffness(0f)
        val lively = SpringMath.settleStiffness(1f)
        assertEquals(SpringMath.MIN_STIFFNESS, calm, 0.01f)
        assertEquals(SpringMath.MAX_STIFFNESS, lively, 0.01f)
        assertTrue(calm < lively)
    }

    @Test
    fun dampingFallsAsTheFeelGetsLivelier() {
        assertTrue(SpringMath.settleDamping(0f) > SpringMath.settleDamping(1f))
        assertEquals(SpringMath.CALM_DAMPING, SpringMath.settleDamping(0f), 0.0001f)
        assertEquals(SpringMath.LIVELY_DAMPING, SpringMath.settleDamping(1f), 0.0001f)
    }

    @Test
    fun pressAndFlingSpringsAreStifferThanSettle() {
        assertTrue(SpringMath.pressStiffness(0.5f) > SpringMath.settleStiffness(0.5f))
        assertTrue(SpringMath.flingStiffness(0.5f) > SpringMath.pressStiffness(0.5f))
    }

    @Test
    fun inertiaIsZeroWithoutAVelocityOrATrack() {
        assertEquals(0f, SpringMath.inertiaFraction(0f, 1000f, 0.09f), 0.0001f)
        assertEquals(0f, SpringMath.inertiaFraction(3000f, 0f, 0.09f), 0.0001f)
        assertEquals(0f, SpringMath.inertiaFraction(3000f, 1f, 0.09f), 0.0001f)
    }

    @Test
    fun inertiaFollowsTheDirectionOfTheSwipe() {
        val forward = SpringMath.inertiaFraction(2000f, 1000f, 0.09f)
        val backward = SpringMath.inertiaFraction(-2000f, 1000f, 0.09f)
        assertTrue(forward > 0f)
        assertEquals(-forward, backward, 0.0001f)
    }

    @Test
    fun inertiaIsCappedSoAFlickNeverFlingsThePanelAway() {
        val big = SpringMath.inertiaFraction(100_000f, 1000f, 0.09f)
        assertEquals(0.09f, big, 0.0001f)
        assertEquals(-0.09f, SpringMath.inertiaFraction(-100_000f, 1000f, 0.09f), 0.0001f)
    }

    @Test
    fun microTravelGrowsPerTapThenCaps() {
        assertEquals(0f, SpringMath.microTravelForTapStreak(0), 0.0001f)
        assertTrue(SpringMath.microTravelForTapStreak(1) < SpringMath.microTravelForTapStreak(2))
        assertEquals(0.06f, SpringMath.microTravelForTapStreak(40), 0.0001f)
    }

    @Test
    fun hapticBoostEscalatesWithTheTapStreak() {
        assertEquals(0f, SpringMath.tapBoostForStreak(0), 0.0001f)
        assertTrue(SpringMath.tapBoostForStreak(2) > SpringMath.tapBoostForStreak(1))
        assertEquals(0.45f, SpringMath.tapBoostForStreak(99), 0.0001f)
    }

    @Test
    fun microDecaySettlesQuicklyAndStaysShort() {
        assertEquals(180, SpringMath.microDecayMillis(0))
        assertTrue(SpringMath.microDecayMillis(3) > SpringMath.microDecayMillis(0))
        assertEquals(320, SpringMath.microDecayMillis(500))
    }

    @Test
    fun clampAndLerpBehave() {
        assertEquals(0f, SpringMath.clamp01(-3f), 0.0001f)
        assertEquals(1f, SpringMath.clamp01(9f), 0.0001f)
        assertEquals(0.5f, SpringMath.clamp01(0.5f), 0.0001f)
        assertEquals(2.5f, SpringMath.lerp(1f, 4f, 0.5f), 0.0001f)
    }
}
