package com.noteedge.audiopanel.core.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PresetResolverTest {

    @Test
    fun everyPresetCoversEveryStreamWithValidFractions() {
        AudioPreset.entries.forEach { preset ->
            val mix = PresetResolver.mixOf(preset)
            assertEquals(
                "preset $preset must define the whole mixer",
                AudioStreamKind.displayOrder.size,
                mix.targets.size,
            )
            mix.targets.forEach { (kind, fraction) ->
                assertTrue("$preset/$kind out of range", fraction in 0f..1f)
            }
        }
    }

    @Test
    fun silentNeverSilencesTheAlarm() {
        val alarm = PresetResolver.mixOf(AudioPreset.SILENT).targets.getValue(AudioStreamKind.ALARM)
        assertTrue("alarm must survive a silent preset", alarm >= 0.5f)
    }

    @Test
    fun nightIsQuieterThanLoudForMedia() {
        val night = PresetResolver.mixOf(AudioPreset.NIGHT).targets.getValue(AudioStreamKind.MEDIA)
        val loud = PresetResolver.mixOf(AudioPreset.LOUD).targets.getValue(AudioStreamKind.MEDIA)
        assertTrue(night < loud)
    }

    @Test
    fun matchRecognisesEveryPresetExactly() {
        AudioPreset.entries.forEach { preset ->
            val current = PresetResolver.mixOf(preset).targets
            assertEquals(preset, PresetResolver.match(current))
        }
    }

    @Test
    fun matchRejectsAMixThatDriftedAway() {
        val current = PresetResolver.mixOf(AudioPreset.LOUD).targets.toMutableMap()
        current[AudioStreamKind.MEDIA] = 0.20f
        assertNull(PresetResolver.match(current))
    }

    @Test
    fun matchWorksWithAPartialSnapshot() {
        val current = mapOf(AudioStreamKind.MEDIA to 0.60f)
        assertEquals(AudioPreset.BALANCED, PresetResolver.match(current))
    }

    @Test
    fun matchReturnsNullForAnEmptyMix() {
        assertNull(PresetResolver.match(emptyMap()))
    }

    @Test
    fun toleranceIsConfigurable() {
        val current = PresetResolver.mixOf(AudioPreset.BALANCED).targets.toMutableMap()
        current[AudioStreamKind.SYSTEM] = 0.60f          // 0.10 away from the preset value
        assertNull(PresetResolver.match(current, tolerance = 0.01f))
        assertEquals(AudioPreset.BALANCED, PresetResolver.match(current, tolerance = 0.12f))
    }
}
