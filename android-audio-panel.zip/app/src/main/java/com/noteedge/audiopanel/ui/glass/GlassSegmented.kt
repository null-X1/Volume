package com.noteedge.audiopanel.ui.glass

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noteedge.audiopanel.core.system.Haptics
import com.noteedge.audiopanel.ui.interaction.SpringMath
import com.noteedge.audiopanel.ui.interaction.rememberPhysicalFeedback
import com.noteedge.audiopanel.ui.theme.PanelPalette
import kotlin.math.abs
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

/**
 * A segmented control that behaves like a physical sliding switch.
 *
 * The light pill tracks the finger across the segments, the labels cross-fade with
 * proximity, and releasing either snaps to the nearest segment or, on a flick, throws
 * past it and settles. Crossing a boundary is announced with a tick.
 */
@Composable
fun GlassSegmented(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    accent: Color = PanelPalette.Accent,
) {
    if (options.isEmpty()) return

    val tuning = LocalGlassTuning.current
    val haptics = LocalHaptics.current
    val physical = rememberPhysicalFeedback()
    val scope = rememberCoroutineScope()
    val currentOnSelect by rememberUpdatedState(onSelect)

    var indicator by remember { mutableFloatStateOf(selectedIndex.coerceIn(0, options.lastIndex).toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    var settleJob by remember { mutableStateOf<Job?>(null) }
    var segmentWidthPx by remember { mutableFloatStateOf(0f) }
    var lastDetent by remember { mutableFloatStateOf(indicator) }

    LaunchedEffect(selectedIndex, dragging) {
        if (!dragging) {
            val target = selectedIndex.coerceIn(0, options.lastIndex).toFloat()
            if (abs(indicator - target) > 0.001f) {
                settleJob?.cancel()
                animate(
                    initialValue = indicator,
                    targetValue = target,
                    animationSpec = spring(
                        stiffness = SpringMath.settleStiffness(tuning.springFeel),
                        dampingRatio = SpringMath.settleDamping(tuning.springFeel),
                    ),
                ) { animated, _ -> indicator = animated }
            }
        }
    }

    GlassSurface(
        modifier = modifier.fillMaxWidth().height(48.dp),
        shape = RoundedCornerShape(18.dp),
        deformation = { physical.press },
        contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .graphicsLayer {
                    scaleX = physical.scale
                    scaleY = physical.scale
                }
                .onGloballyPositioned { coordinates ->
                    segmentWidthPx = coordinates.size.width / options.size.toFloat()
                }
                .pointerInput(options.size, tuning.springFeel) {
                    val width = size.width.toFloat().coerceAtLeast(1f)
                    val segment = width / options.size.toFloat()
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        settleJob?.cancel()
                        dragging = true
                        physical.onDown(down.uptimeMillis)

                        val tracker = VelocityTracker()
                        tracker.addPosition(down.uptimeMillis, down.position)

                        fun fractionFor(x: Float): Float =
                            ((x / width) * (options.size - 1)).coerceIn(0f, options.lastIndex.toFloat())

                        indicator = fractionFor(down.position.x)

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break

                            if (change.positionChanged()) {
                                tracker.addPosition(change.uptimeMillis, change.position)
                                val target = fractionFor(change.position.x)
                                indicator = target
                                if (abs(target - lastDetent) > 0.5f) {
                                    lastDetent = kotlin.math.round(target)
                                    haptics?.play(Haptics.Feel.Tick)
                                }
                                change.consume()
                            }

                            if (change.changedToUpIgnoreConsumed()) {
                                val velocity = tracker.calculateVelocity().x
                                val settled = indicator
                                val flicked = when {
                                    velocity > segment * 1.6f -> settled + 1f
                                    velocity < -segment * 1.6f -> settled - 1f
                                    else -> settled
                                }
                                val target = kotlin.math.round(flicked)
                                    .coerceIn(0f, options.lastIndex.toFloat())

                                dragging = false
                                physical.onRelease(velocity, width, wasTap = true)
                                settleJob = scope.launch {
                                    animate(
                                        initialValue = indicator,
                                        targetValue = target,
                                        initialVelocity = velocity / segment,
                                        animationSpec = spring(
                                            stiffness = SpringMath.settleStiffness(tuning.springFeel),
                                            dampingRatio = SpringMath.settleDamping(tuning.springFeel),
                                        ),
                                    ) { animated, _ -> indicator = animated }
                                    currentOnSelect(target.toInt())
                                }
                                break
                            }
                        }
                        dragging = false
                    }
                },
        ) {
            // moving pill
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(with(androidx.compose.ui.platform.LocalDensity.current) { segmentWidthPx.toDp() })
                    .graphicsLayer {
                        translationX = indicator * segmentWidthPx
                        scaleY = 1f - 0.08f * physical.press
                    }
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.White.copy(alpha = 0.24f),
                                Color.White.copy(alpha = 0.10f),
                            ),
                        ),
                    ),
            )

            Row(Modifier.fillMaxWidth().fillMaxHeight()) {
                options.forEachIndexed { index, option ->
                    Box(
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        contentAlignment = Alignment.Center,
                    ) {
                        val proximity: () -> Float = {
                            (1f - abs(indicator - index)).coerceIn(0f, 1f)
                        }
                        Text(
                            text = option,
                            color = PanelPalette.TextSecondary,
                            fontSize = 13.sp,
                            maxLines = 1,
                            modifier = Modifier.graphicsLayer { alpha = 1f - proximity() },
                        )
                        Text(
                            text = option,
                            color = PanelPalette.TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            modifier = Modifier.graphicsLayer { alpha = proximity() },
                        )
                    }
                }
            }
        }
    }
}
