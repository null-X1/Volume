package com.noteedge.audiopanel.ui.interaction

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import com.noteedge.audiopanel.core.system.Haptics
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * The shared "physical body" behind every interactive element.
 *
 * Nothing in this app animates from an `onClick`. Instead each control owns one of
 * these, feeds it the raw pointer stream, and reads the resulting physical quantities
 * (`press`, `micro`, `glow`, `stretch`) from inside draw/layer lambdas - which means a
 * finger in motion never triggers a recomposition, it only changes what gets drawn.
 *
 *   finger down   -> compression ramps in on a tight spring
 *   finger moves  -> `stretch` follows the finger's velocity (drag drags the body)
 *   repeated taps -> `micro` accumulates, so the third tap moves more than the first
 *   long press    -> `hold` ramps in for a stronger, "gripped" state
 *   finger up     -> everything returns on a spring, with inertia from the release speed
 */
@Stable
class PhysicalFeedback internal constructor(
    private val scope: CoroutineScope,
    private val haptics: Haptics?,
    private val feel: () -> Float,
) {

    private val pressChannel = Channel(scope, 0f)
    private val holdChannel = Channel(scope, 0f)
    private val microChannel = Channel(scope, 0f)
    private val glowChannel = Channel(scope, 0f)
    private val stretchChannel = Channel(scope, 0f)

    private var lastReleaseAt = 0L
    private var streak = 0

    /** 0..1 compression while a finger is down. */
    val press: Float get() = pressChannel.value

    /** 0..1 grip that ramps in while a long press is held. */
    val hold: Float get() = holdChannel.value

    /** Signed micro-motion from repeated taps / flicks, in track fractions. */
    val micro: Float get() = microChannel.value

    /** 0..1 extra specular energy, brightens the glass while touched. */
    val glow: Float get() = glowChannel.value

    /** -1..1 drag energy derived from pointer velocity. */
    val stretch: Float get() = stretchChannel.value

    val tapStreak: Int get() = streak

    /** Body scale: a pressed control shrinks slightly and a gripped one swells back. */
    val scale: Float get() = 1f - 0.030f * press + 0.018f * hold

    /** Thumb scale: presses are subtle, a long press makes the control feel grabbed. */
    val knobScale: Float get() = 1f + 0.10f * press + 0.16f * hold

    fun onDown(atMillis: Long = now()) {
        if (atMillis - lastReleaseAt in 1..TAP_STREAK_WINDOW_MS) streak += 1 else streak = 0
        pressChannel.glideTo(1f, spring(stiffness = SpringMath.pressStiffness(feel()), dampingRatio = SpringMath.pressDamping(feel())))
        glowChannel.glideTo(0.75f, spring())
        microChannel.glideTo(
            SpringMath.microTravelForTapStreak(streak),
            spring(stiffness = 900f, dampingRatio = 0.6f),
        )
        haptics?.play(Haptics.Feel.Tick, boost = SpringMath.tapBoostForStreak(streak))
    }

    fun onMove(velocityPxPerSecond: Float, trackWidthPx: Float) {
        val normalized = if (trackWidthPx <= 1f) 0f else (velocityPxPerSecond / trackWidthPx).coerceIn(-2.2f, 2.2f)
        stretchChannel.glideTo(normalized.coerceIn(-1f, 1f), spring(stiffness = 1400f, dampingRatio = 0.85f))
        glowChannel.glideTo(
            (0.75f + 0.25f * abs(normalized)).coerceIn(0f, 1f),
            spring(stiffness = 1400f, dampingRatio = 0.9f),
        )
    }

    fun onLongPress() {
        holdChannel.glideTo(1f, spring(stiffness = 420f, dampingRatio = 0.62f))
        haptics?.play(Haptics.Feel.Firm, boost = 0.1f)
    }

    fun onLongPressEnd() {
        holdChannel.glideTo(0f, spring(stiffness = 600f, dampingRatio = 0.8f))
    }

    /** Called on release. [wasTap] adds the softer "click" feedback of a quick tap. */
    fun onRelease(releaseVelocityPx: Float = 0f, trackWidthPx: Float = 0f, wasTap: Boolean = false, atMillis: Long = now()) {
        lastReleaseAt = atMillis
        val spec = settleSpec()
        pressChannel.glideTo(0f, spec)
        holdChannel.glideTo(0f, spec)
        glowChannel.glideTo(0f, spec)
        microChannel.glideTo(0f, spec)
        val inertia = if (trackWidthPx > 1f) {
            SpringMath.inertiaFraction(releaseVelocityPx, trackWidthPx, maxTravel = 0.35f)
        } else {
            0f
        }
        stretchChannel.glideTo(inertia.coerceIn(-1f, 1f), spring(stiffness = 260f, dampingRatio = 0.45f))
        if (wasTap) {
            haptics?.play(Haptics.Feel.Soft, boost = SpringMath.tapBoostForStreak(streak) * 0.6f)
        }
    }

    fun onCancel() {
        val spec = settleSpec()
        pressChannel.glideTo(0f, spec)
        holdChannel.glideTo(0f, spec)
        glowChannel.glideTo(0f, spec)
        microChannel.glideTo(0f, spec)
        stretchChannel.glideTo(0f, spec)
        streak = 0
    }

    private fun settleSpec(): AnimationSpec<Float> =
        spring(stiffness = SpringMath.settleStiffness(feel()), dampingRatio = SpringMath.settleDamping(feel()))

    private companion object {
        const val TAP_STREAK_WINDOW_MS = 620L
        fun now(): Long = android.os.SystemClock.uptimeMillis()
    }
}

/** One spring-driven scalar with a cancel-safe driver. */
private class Channel(private val scope: CoroutineScope, initial: Float) {

    private val animatable = Animatable(initial)
    private var job: Job? = null

    val value: Float get() = animatable.value

    fun glideTo(target: Float, spec: AnimationSpec<Float>) {
        job?.cancel()
        job = scope.launch {
            try {
                animatable.animateTo(target, spec)
            } catch (_: CancellationException) {
                // A new gesture took over; the next glideTo will re-target.
            }
        }
    }
}

/**
 * Remembers a [PhysicalFeedback] wired to the current feel settings and haptics.
 * Safe to call from any composable - it only needs a composition scope.
 */
@Composable
fun rememberPhysicalFeedback(overrideFeel: Float? = null): PhysicalFeedback {
    val scope = rememberCoroutineScope()
    val tuning = com.noteedge.audiopanel.ui.glass.LocalGlassTuning.current
    val haptics = com.noteedge.audiopanel.ui.glass.LocalHaptics.current
    val feelState = rememberUpdatedState(overrideFeel ?: tuning.springFeel)
    return remember(scope, haptics, overrideFeel) {
        PhysicalFeedback(scope, haptics) { feelState.value }
    }
}
