package com.noteedge.audiopanel.core.system

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display
import com.noteedge.audiopanel.core.model.DeviceProfile

/** Reads the host device once per panel visit; used for diagnostics and tuning hints. */
class DeviceProfileProvider(private val context: Context) {

    fun current(): DeviceProfile {
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display: Display? = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
        val currentRate = runCatching { display?.mode?.refreshRate ?: 0f }.getOrDefault(0f)
        val maxRate = runCatching {
            display?.supportedModes?.maxOfOrNull { it.refreshRate } ?: currentRate
        }.getOrDefault(currentRate)

        val manufacturer = Build.MANUFACTURER.orEmpty()
        val brand = Build.BRAND.orEmpty()
        val model = Build.MODEL.orEmpty()
        val haystack = listOf(Build.DISPLAY, Build.VERSION.INCREMENTAL, Build.FINGERPRINT)
            .joinToString(" ")
            .lowercase()

        return DeviceProfile(
            manufacturer = manufacturer,
            brand = brand,
            model = model,
            device = Build.DEVICE.orEmpty(),
            androidRelease = Build.VERSION.RELEASE.orEmpty(),
            sdkInt = Build.VERSION.SDK_INT,
            buildFingerprintTag = Build.DISPLAY.orEmpty(),
            skin = detectSkin(haystack, manufacturer, brand),
            isTargetDevice = isTargetDevice(manufacturer, brand, model),
            refreshRate = if (currentRate > 0f) currentRate else 60f,
            maxRefreshRate = if (maxRate > 0f) maxRate else 60f,
            supportsMoreThan60Hz = maxRate > 61f,
            renderEffectBlur = BlurSupport.renderEffectBlurSupported,
            crossWindowBlur = BlurSupport.crossWindowBlurEnabled(context),
        )
    }

    private fun detectSkin(haystack: String, manufacturer: String, brand: String): String? {
        val version = XOS_PATTERN.find(haystack)?.groupValues?.getOrNull(1)
        return when {
            version != null -> "XOS $version"
            haystack.contains("xos") -> "XOS"
            manufacturer.contains("infinix", ignoreCase = true) ||
                brand.contains("infinix", ignoreCase = true) -> "XOS (Infinix)"
            else -> null
        }
    }

    private fun isTargetDevice(manufacturer: String, brand: String, model: String): Boolean {
        val modelLower = model.lowercase()
        if (modelLower.contains("x6887")) return true
        val isInfinix = manufacturer.contains("infinix", ignoreCase = true) ||
            brand.contains("infinix", ignoreCase = true)
        return isInfinix && modelLower.contains("note") && modelLower.contains("edge")
    }

    private companion object {
        /** Matches "XOS 16.3", "XOS_16.3", "XOS16.3.1" and friends inside build strings. */
        val XOS_PATTERN = Regex("xos[ _-]?(\\d+(?:\\.\\d+)*)", RegexOption.IGNORE_CASE)
    }
}
