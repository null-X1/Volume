package com.noteedge.audiopanel.ui.panel

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.BlurOn
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noteedge.audiopanel.R
import com.noteedge.audiopanel.core.audio.AudioRouteMonitor
import com.noteedge.audiopanel.core.model.DeviceProfile
import com.noteedge.audiopanel.core.model.GlassTuning
import com.noteedge.audiopanel.ui.components.GlassDivider
import com.noteedge.audiopanel.ui.components.SectionCard
import com.noteedge.audiopanel.ui.components.StatRow
import com.noteedge.audiopanel.ui.components.StatusPill
import com.noteedge.audiopanel.ui.glass.GlassButton
import com.noteedge.audiopanel.ui.glass.GlassSwitch
import com.noteedge.audiopanel.ui.theme.PanelPalette
import com.noteedge.audiopanel.util.Formatters

/**
 * Device facts and the system permissions this app depends on. Nothing is requested
 * silently: every row either reports a state or opens the matching system screen.
 */
@Composable
internal fun SystemSection(
    device: DeviceProfile,
    route: AudioRouteMonitor.RouteInfo?,
    tuning: GlassTuning,
    permissions: PermissionSnapshot,
    overlayRunning: Boolean,
    onToggleOverlay: (Boolean) -> Unit,
    onOpenOverlaySettings: () -> Unit,
    onOpenBattery: () -> Unit,
    onOpenDnd: () -> Unit,
    onOpenAppSettings: () -> Unit,
    onRefresh: () -> Unit,
) {
    SectionCard(
        title = stringResource(R.string.section_system),
        subtitle = "What the panel is allowed to do on this ROM",
        icon = Icons.Rounded.Android,
    ) {
        StatRow(label = stringResource(R.string.field_device), value = device.displayName)
        StatRow(label = stringResource(R.string.field_model), value = device.model)
        StatRow(
            label = stringResource(R.string.field_android),
            value = "${device.androidRelease} (API ${device.sdkInt})",
        )
        StatRow(label = stringResource(R.string.field_skin), value = device.skin ?: "Stock")
        StatRow(
            label = stringResource(R.string.field_display),
            value = "${Formatters.hz(device.refreshRate)} / ${Formatters.hz(device.maxRefreshRate)} max",
        )
        StatRow(
            label = stringResource(R.string.field_route),
            value = route?.label ?: stringResource(R.string.value_unknown),
        )
        StatRow(
            label = stringResource(R.string.field_blur),
            value = when {
                device.crossWindowBlur && device.renderEffectBlur -> "Compositor + render effect"
                device.renderEffectBlur -> "Render effect only"
                else -> stringResource(R.string.label_unavailable)
            },
        )

        Spacer(Modifier.height(12.dp))
        GlassDivider()
        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.section_overlay),
                    color = PanelPalette.TextPrimary,
                    fontSize = 13.sp,
                )
                Spacer(Modifier.width(8.dp))
                when {
                    !permissions.overlay -> StatusPill(
                        text = stringResource(R.string.permission_required),
                        color = PanelPalette.Warm,
                    )

                    overlayRunning -> StatusPill(text = "Running", color = PanelPalette.Success)
                    else -> StatusPill(text = stringResource(R.string.label_off), color = PanelPalette.TextTertiary)
                }
            }
            GlassSwitch(
                checked = overlayRunning,
                onCheckedChange = onToggleOverlay,
                enabled = permissions.overlay,
            )
        }

        Text(
            text = "The floating panel draws its own window above other apps. It has no " +
                "access to their content - the window is only an overlay and a volume controller.",
            color = PanelPalette.TextTertiary,
            fontSize = 11.sp,
            lineHeight = 14.sp,
            modifier = Modifier.size(48.dp),
        )

        Spacer(Modifier.height(10.dp))

        if (!permissions.overlay) {
            GlassButton(
                label = stringResource(R.string.permission_overlay),
                icon = Icons.Rounded.Layers,
                onClick = onOpenOverlaySettings,
                emphasised = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
        }
        if (!permissions.batteryUnrestricted) {
            GlassButton(
                label = stringResource(R.string.permission_battery),
                icon = Icons.Rounded.Lock,
                onClick = onOpenBattery,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
        }
        if (!permissions.dndAccess) {
            GlassButton(
                label = stringResource(R.string.permission_dnd),
                icon = Icons.Rounded.Info,
                onClick = onOpenDnd,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            GlassButton(
                label = "Refresh",
                icon = Icons.Rounded.BlurOn,
                onClick = onRefresh,
                modifier = Modifier.weight(1f),
            )
            GlassButton(
                label = "App info",
                onClick = onOpenAppSettings,
                modifier = Modifier.weight(1f),
            )
        }

        Spacer(Modifier.height(12.dp))
        Text(
            text = "Panel tuning lives on this device only. No account, no network, no analytics.",
            color = PanelPalette.TextTertiary,
            fontSize = 11.sp,
            lineHeight = 14.sp,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = "Haptics ${if (tuning.hapticsEnabled) Formatters.percent(tuning.hapticStrength) else "off"}",
            color = PanelPalette.TextTertiary,
            fontSize = 11.sp,
        )
    }
}
