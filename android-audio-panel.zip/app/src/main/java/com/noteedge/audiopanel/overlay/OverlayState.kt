package com.noteedge.audiopanel.overlay

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Whether the floating panel window is currently attached. Shared so the activity can
 * reflect the real state of the service instead of guessing from the stored preference.
 */
object OverlayState {

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    internal fun setRunning(running: Boolean) {
        _running.value = running
    }
}
