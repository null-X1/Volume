package com.noteedge.audiopanel.core.audio

import android.content.ContentResolver
import android.database.ContentObserver
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.annotation.AnyThread
import com.noteedge.audiopanel.core.model.AudioPreset
import com.noteedge.audiopanel.core.model.AudioStreamKind
import com.noteedge.audiopanel.core.model.PresetResolver
import com.noteedge.audiopanel.core.model.StreamVolume
import com.noteedge.audiopanel.core.model.VolumeMath
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Single source of truth for stream volumes.
 *
 * Volume changes coming from the hardware keys, from other apps or from the system UI
 * arrive through a [ContentObserver] on the Settings.System volume entries, so the
 * panel always mirrors reality without polling in the background.
 */
class VolumeRepository(
    private val audioSystem: AudioSystem,
    private val scope: CoroutineScope,
) {

    data class PresetOutcome(
        val preset: AudioPreset,
        val applied: Boolean,
        val ringerModeApplied: Boolean = true,
        val needsDndAccess: Boolean = false,
    )

    private val _streams = MutableStateFlow<Map<AudioStreamKind, StreamVolume>>(emptyMap())
    val streams: StateFlow<Map<AudioStreamKind, StreamVolume>> = _streams.asStateFlow()

    private val _lastPreset = MutableStateFlow<AudioPreset?>(null)
    val lastPreset: StateFlow<AudioPreset?> = _lastPreset.asStateFlow()

    /** Emits whenever the platform pushed a change we did not originate ourselves. */
    private val _externalChanges = MutableSharedFlow<Unit>(
        extraBufferCapacity = 4,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    val externalChanges = _externalChanges

    private var observer: ContentObserver? = null
    private var syncJob: Job? = null

    /** Index values captured before "mute all", so the action is reversible. */
    private val muteBackup = LinkedHashMap<AudioStreamKind, Int>()

    /** Writes are coalesced to at most one per stream every 32 ms while dragging. */
    private val lastWriteAt = HashMap<AudioStreamKind, Long>()

    fun start(resolver: ContentResolver) {
        sync()
        if (observer != null) return
        val contentObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                scheduleSync(external = true)
            }
        }
        AudioStreamKind.displayOrder.forEach { kind ->
            val uri = android.provider.Settings.System.getUriFor(kind.settingName) ?: return@forEach
            runCatching { resolver.registerContentObserver(uri, false, contentObserver) }
        }
        observer = contentObserver
    }

    fun stop(resolver: ContentResolver) {
        observer?.let { runCatching { resolver.unregisterContentObserver(it) } }
        observer = null
        syncJob?.cancel()
    }

    @AnyThread
    fun sync() {
        _streams.value = audioSystem.snapshotAll(AudioStreamKind.displayOrder)
    }

    private fun scheduleSync(external: Boolean) {
        if (external) _externalChanges.tryEmit(Unit)
        syncJob?.cancel()
        syncJob = scope.launch {
            delay(SYNC_DEBOUNCE_MS)
            sync()
        }
    }

    /**
     * Applies a drag value. The UI keeps its own local value while the finger is down,
     * so this only has to be "close enough" - [commit] finishes the gesture exactly.
     */
    fun setFraction(kind: AudioStreamKind, fraction: Float, force: Boolean = false) {
        val now = SystemClock.uptimeMillis()
        val last = lastWriteAt[kind] ?: 0L
        if (!force && now - last < WRITE_THROTTLE_MS) return
        lastWriteAt[kind] = now
        audioSystem.setFraction(kind, fraction)
        applyOptimistic(kind, fraction)
    }

    /** Called when the finger lifts: writes the exact final value and re-reads the truth. */
    fun commit(kind: AudioStreamKind, fraction: Float) {
        lastWriteAt[kind] = SystemClock.uptimeMillis()
        audioSystem.setFraction(kind, fraction)
        scope.launch {
            delay(60)
            sync()
        }
    }

    fun nudge(kind: AudioStreamKind, delta: Int) {
        audioSystem.nudge(kind, delta)
        scope.launch {
            delay(40)
            sync()
        }
    }

    fun toggleMute(kind: AudioStreamKind) {
        val current = _streams.value[kind] ?: return
        if (current.isMuted) {
            val restore = muteBackup.remove(kind) ?: defaultUnmuteIndex(current)
            audioSystem.setFraction(kind, VolumeMath.fraction(restore, current.minIndex, current.maxIndex))
        } else {
            muteBackup[kind] = current.index
            audioSystem.setFraction(kind, 0f)
        }
        scope.launch {
            delay(40)
            sync()
        }
    }

    fun muteAll() {
        muteBackup.clear()
        AudioStreamKind.mutableByPanel.forEach { kind ->
            _streams.value[kind]?.takeIf { !it.isMuted }?.let { muteBackup[kind] = it.index }
        }
        AudioStreamKind.mutableByPanel.forEach { audioSystem.setFraction(it, 0f) }
        scope.launch {
            delay(60)
            sync()
        }
    }

    fun restoreAll() {
        var restoredAny = false
        AudioStreamKind.mutableByPanel.forEach { kind ->
            val index = muteBackup[kind] ?: return@forEach
            val max = _streams.value[kind]?.maxIndex ?: return@forEach
            val min = _streams.value[kind]?.minIndex ?: 0
            audioSystem.setFraction(kind, VolumeMath.fraction(index, min, max))
            restoredAny = true
        }
        if (!restoredAny) {
            PresetResolver.mixOf(AudioPreset.BALANCED).targets.forEach { (kind, fraction) ->
                audioSystem.setFraction(kind, fraction)
            }
        }
        muteBackup.clear()
        scope.launch {
            delay(60)
            sync()
        }
    }

    val isMuteAllActive: Boolean get() = muteBackup.isNotEmpty()

    /**
     * Applies a preset. Ringer mode changes need Do-Not-Disturb access on modern Android;
     * when it is missing the volume targets are still applied and the caller is told to
     * ask the user for the extra permission.
     */
    suspend fun applyPreset(preset: AudioPreset, dndAccessGranted: Boolean): PresetOutcome {
        val mix = PresetResolver.mixOf(preset)
        mix.targets.forEach { (kind, fraction) -> audioSystem.setFraction(kind, fraction) }

        var ringerApplied = true
        var needsDnd = false
        val mode = mix.ringerMode
        if (mode != null && mode != AudioManager.RINGER_MODE_NORMAL) {
            if (!dndAccessGranted) {
                needsDnd = true
                ringerApplied = false
            } else {
                ringerApplied = audioSystem.setRingerMode(mode)
                needsDnd = !ringerApplied
            }
        } else if (mode == AudioManager.RINGER_MODE_NORMAL) {
            audioSystem.setRingerMode(AudioManager.RINGER_MODE_NORMAL)
        }
        delay(80)
        sync()
        _lastPreset.value = preset
        return PresetOutcome(preset = preset, applied = true, ringerModeApplied = ringerApplied, needsDndAccess = needsDnd)
    }

    /** Detects whether the current mix matches a known preset, for the chip highlight. */
    fun matchPreset(): AudioPreset? {
        val snapshot = _streams.value
        if (snapshot.isEmpty()) return null
        return AudioPreset.entries.firstOrNull { preset ->
            val mix = PresetResolver.mixOf(preset)
            mix.targets.all { (kind, target) ->
                val stream = snapshot[kind] ?: return@all false
                VolumeMath.approximatelyEqual(stream.fraction, target, 0.06f)
            }
        }
    }

    private fun applyOptimistic(kind: AudioStreamKind, fraction: Float) {
        val current = _streams.value[kind] ?: return
        val index = VolumeMath.indexFor(fraction, current.minIndex, current.maxIndex)
        _streams.value = _streams.value + (kind to current.copy(index = index))
    }

    private fun defaultUnmuteIndex(volume: StreamVolume): Int =
        VolumeMath.indexFor(0.6f, volume.minIndex, volume.maxIndex)

    private companion object {
        const val SYNC_DEBOUNCE_MS = 70L
        const val WRITE_THROTTLE_MS = 32L
    }
}
