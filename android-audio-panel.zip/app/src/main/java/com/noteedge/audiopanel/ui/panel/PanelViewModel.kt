package com.noteedge.audiopanel.ui.panel

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.noteedge.audiopanel.core.audio.AudioEffectsController
import com.noteedge.audiopanel.core.audio.AudioRouteMonitor
import com.noteedge.audiopanel.core.audio.VolumeRepository
import com.noteedge.audiopanel.core.model.AudioPreset
import com.noteedge.audiopanel.core.model.AudioStreamKind
import com.noteedge.audiopanel.core.model.DeviceProfile
import com.noteedge.audiopanel.core.model.GlassTuning
import com.noteedge.audiopanel.core.model.OverlaySettings
import com.noteedge.audiopanel.core.model.StreamVolume
import com.noteedge.audiopanel.core.settings.SettingsRepository
import com.noteedge.audiopanel.core.system.DeviceProfileProvider
import com.noteedge.audiopanel.core.system.Haptics
import com.noteedge.audiopanel.core.system.PermissionGateway
import com.noteedge.audiopanel.di.AppContainer
import com.noteedge.audiopanel.overlay.OverlayPanelService
import com.noteedge.audiopanel.overlay.OverlayState
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Snapshot of the special permissions the panel can ask for. */
data class PermissionSnapshot(
    val overlay: Boolean = false,
    val notifications: Boolean = true,
    val batteryUnrestricted: Boolean = false,
    val dndAccess: Boolean = false,
)

/**
 * Holds all panel state. Everything is a StateFlow owned by the repositories; this class
 * only translates intent into repository calls and collects the results.
 */
class PanelViewModel(
    private val appContext: Context,
    private val volumeRepository: VolumeRepository,
    private val settings: SettingsRepository,
    private val effects: AudioEffectsController,
    private val routeMonitor: AudioRouteMonitor,
    private val deviceProfileProvider: DeviceProfileProvider,
    private val permissions: PermissionGateway,
    val haptics: Haptics,
) : ViewModel() {

    val streams: StateFlow<Map<AudioStreamKind, StreamVolume>> = volumeRepository.streams
    val tuning: StateFlow<GlassTuning> = settings.tuning
    val overlaySettings: StateFlow<OverlaySettings> = settings.overlay
    val effectsState: StateFlow<AudioEffectsController.EffectsState> = effects.state
    val route: StateFlow<AudioRouteMonitor.RouteInfo?> = routeMonitor.route
    val lastPreset: StateFlow<AudioPreset?> = volumeRepository.lastPreset
    val overlayRunning: StateFlow<Boolean> = OverlayState.running

    private val _device = MutableStateFlow(deviceProfileProvider.current())
    val device: StateFlow<DeviceProfile> = _device.asStateFlow()

    private val _permissions = MutableStateFlow(readPermissions())
    val permissionSnapshot: StateFlow<PermissionSnapshot> = _permissions.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        effects.ensureAttached()
        routeMonitor.refresh()
        viewModelScope.launch {
            volumeRepository.externalChanges.collect {
                // Keep haptics/tuning in sync when the user changes volume with the keys.
                refreshDeviceProfile()
            }
        }
    }

    fun refresh() {
        volumeRepository.sync()
        routeMonitor.refresh()
        refreshDeviceProfile()
        _permissions.value = readPermissions()
    }

    fun refreshDeviceProfile() {
        _device.value = deviceProfileProvider.current()
    }

    fun onStreamDrag(kind: AudioStreamKind, fraction: Float) {
        volumeRepository.setFraction(kind, fraction)
    }

    fun onStreamCommit(kind: AudioStreamKind, fraction: Float) {
        volumeRepository.commit(kind, fraction)
        haptics.play(Haptics.Feel.Tick)
    }

    fun toggleMute(kind: AudioStreamKind) {
        volumeRepository.toggleMute(kind)
        haptics.play(Haptics.Feel.Soft)
    }

    fun muteAll() {
        volumeRepository.muteAll()
        haptics.play(Haptics.Feel.Firm)
    }

    fun restoreAll() {
        volumeRepository.restoreAll()
        haptics.play(Haptics.Feel.Soft)
    }

    val muteAllActive: Boolean get() = volumeRepository.isMuteAllActive

    /** Which preset the live mix matches, if any. */
    fun matchPreset(): AudioPreset? = volumeRepository.matchPreset()

    fun applyPreset(preset: AudioPreset) {
        viewModelScope.launch {
            val outcome = volumeRepository.applyPreset(preset, permissions.dndAccessGranted())
            when {
                outcome.applied && !outcome.needsDndAccess -> _messages.tryEmit("Preset applied")
                outcome.applied && outcome.needsDndAccess ->
                    _messages.tryEmit("Volume set. Allow Do-Not-Disturb access for silent modes.")
                else -> _messages.tryEmit("Preset could not be applied on this output")
            }
            haptics.play(Haptics.Feel.Firm)
        }
    }

    // ---- glass tuning ------------------------------------------------------

    fun updateTuning(transform: (GlassTuning) -> GlassTuning) {
        settings.updateTuning(transform)
        val updated = settings.tuning.value
        haptics.enabled = updated.hapticsEnabled
        haptics.intensity = updated.hapticStrength
    }

    fun resetTuning() {
        settings.resetTuning()
        val updated = settings.tuning.value
        haptics.enabled = updated.hapticsEnabled
        haptics.intensity = updated.hapticStrength
    }

    fun updateOverlay(transform: (OverlaySettings) -> OverlaySettings) {
        settings.updateOverlay(transform)
    }

    fun setOverlayRunning(running: Boolean) {
        settings.updateOverlay { it.copy(enabled = running) }
        val intent = Intent(appContext, OverlayPanelService::class.java)
        if (running) {
            appContext.startForegroundService(intent)
        } else {
            appContext.stopService(intent)
        }
        haptics.play(if (running) Haptics.Feel.Firm else Haptics.Feel.Soft)
    }

    // ---- audio effects ----------------------------------------------------

    fun setEffectsEnabled(enabled: Boolean) {
        effects.ensureAttached()
        effects.setEnabled(enabled)
    }

    fun setBand(fraction: Float, band: Short) {
        effects.ensureAttached()
        effects.setBand(fraction, band)
    }

    fun setBass(fraction: Float) {
        effects.ensureAttached()
        effects.setBass(fraction)
    }

    fun setVirtualizer(fraction: Float) {
        effects.ensureAttached()
        effects.setVirtualizer(fraction)
    }

    fun resetEffects() {
        effects.ensureAttached()
        effects.reset()
    }

    // ---- permissions ------------------------------------------------------

    private fun readPermissions(): PermissionSnapshot = PermissionSnapshot(
        overlay = permissions.canDrawOverlays(),
        notifications = permissions.hasNotificationPermission(),
        batteryUnrestricted = permissions.isIgnoringBatteryOptimizations(),
        dndAccess = permissions.dndAccessGranted(),
    )

    fun overlaySettingsIntent(): Intent = permissions.overlaySettingsIntent()
    fun batteryIntent(): Intent = permissions.batteryOptimizationIntent()
    fun dndIntent(): Intent = permissions.dndSettingsIntent()
    fun appSettingsIntent(): Intent = permissions.appSettingsIntent()

    override fun onCleared() {
        super.onCleared()
        haptics.stop()
    }

    companion object {
        fun factory(container: AppContainer, appContext: Context): ViewModelProvider.Factory =
            viewModelFactory {
                initializer {
                    PanelViewModel(
                        appContext = appContext,
                        volumeRepository = container.volumeRepository,
                        settings = container.settings,
                        effects = container.effects,
                        routeMonitor = container.routeMonitor,
                        deviceProfileProvider = container.deviceProfile,
                        permissions = container.permissions,
                        haptics = container.haptics,
                    )
                }
            }
    }
}
