package com.noteedge.audiopanel.core.model

import android.media.AudioManager
import androidx.annotation.StringRes
import com.noteedge.audiopanel.R

/**
 * The audio streams the panel exposes.
 *
 * Every stream below is part of the public [AudioManager] surface, which keeps the
 * app completely free of hidden framework APIs and works identically on stock
 * Android 16 and on XOS 16.3.
 */
enum class AudioStreamKind(
    val streamType: Int,
    @StringRes val labelRes: Int,
    /** Name of the Settings.System entry that mirrors this stream's volume. */
    val settingName: String,
    /** Media-style streams keep playing when the ringer goes silent. */
    val isLongPlaying: Boolean = false,
) {
    MEDIA(AudioManager.STREAM_MUSIC, R.string.stream_media, "volume_music", isLongPlaying = true),
    CALL(AudioManager.STREAM_VOICE_CALL, R.string.stream_call, "volume_voice"),
    RING(AudioManager.STREAM_RING, R.string.stream_ring, "volume_ring"),
    NOTIFICATION(AudioManager.STREAM_NOTIFICATION, R.string.stream_notification, "volume_notification"),
    ALARM(AudioManager.STREAM_ALARM, R.string.stream_alarm, "volume_alarm"),
    SYSTEM(AudioManager.STREAM_SYSTEM, R.string.stream_system, "volume_system"),
    ;

    companion object {
        /** Order used by the UI, most used stream first. */
        val displayOrder: List<AudioStreamKind> = listOf(MEDIA, RING, NOTIFICATION, ALARM, CALL, SYSTEM)

        /** Streams that a "mute everything" action should touch. */
        val mutableByPanel: List<AudioStreamKind> = displayOrder.filter { it != ALARM }

        fun fromStreamType(streamType: Int): AudioStreamKind? =
            entries.firstOrNull { it.streamType == streamType }
    }
}
