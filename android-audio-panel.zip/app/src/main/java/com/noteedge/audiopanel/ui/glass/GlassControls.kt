package com.noteedge.audiopanel.ui.glass

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noteedge.audiopanel.core.system.Haptics
import com.noteedge.audiopanel.ui.interaction.PhysicalFeedback
import com.noteedge.audiopanel.ui.interaction.SpringMath
import com.noteedge.audiopanel.ui.interaction.rememberPhysicalFeedback
import com.noteedge.audiopanel.ui.theme.PanelPalette
import kotlin.math.abs
import kotlin.math.hypot
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Shared press handling for solid controls.
 *
 * Taps are only reported when the finger both stayed close to the touch point and
 * lifted inside the control, and a long press raises the control's grip state instead
 * of firing a click - the same vocabulary a physical button has.
 */
private fun Modifier.pressable(
    physical: PhysicalFeedback,
    enabled: Boolean,
    longPressMillis: Long = 520L,
    onLongPress: (() -> Unit)? = null,
    onTap: () -> Unit,
): Modifier = this.pointerInput(enabled, longPressMillis) {
    if (!enabled) return@pointerInput
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        physical.onDown(down.uptimeMillis)

        var travel = 0f
        var lastX = down.position.x
        var lastY = down.position.y
        var longFired = false
        var cancelled = false

        while (true) {
            val event = awaitPointerEvent()
            val change = event.changes.firstOrNull { it.id == down.id } ?: break

            if (!longFired && onLongPress != null &&
                change.uptimeMillis - down.uptimeMillis >= longPressMillis
            ) {
                longFired = true
                physical.onLongPress()
                onLongPress()
            }

            if (change.positionChanged()) {
                travel += hypot(change.position.x - lastX, change.position.y - lastY)
                lastX = change.position.x
                lastY = change.position.y
                change.consume()
            }

            if (change.changedToUpIgnoreConsumed()) {
                val inside = change.position.x in 0f..size.width.toFloat() &&
                    change.position.y in 0f..size.height.toFloat()
                val wasTap = travel <= TAP_SLOP_PX
                if (longFired) physical.onLongPressEnd()
                physical.onRelease(0f, 0f, wasTap = wasTap && inside && !longFired)
                if (inside && !longFired && wasTap) onTap()
                break
            }

            if (!change.pressed) {
                cancelled = true
                break
            }
        }

        if (cancelled) physical.onCancel()
    }
}

/** Circular glass button - the panel's everyday action control. */
@Composable
fun GlassIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accent: Color = PanelPalette.Accent,
    buttonSize: Dp = 46.dp,
    shape: Shape = CircleShape,
    enabled: Boolean = true,
    onLongPress: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val physical = rememberPhysicalFeedback()
    GlassSurface(
        modifier = modifier
            .size(buttonSize)
            .pressable(physical, enabled, onLongPress = onLongPress, onTap = onClick),
        shape = shape,
        deformation = { physical.press },
        tint = accent,
    ) {
        Box(
            modifier = Modifier
                .size(buttonSize)
                .graphicsLayer {
                    scaleX = physical.scale
                    scaleY = physical.scale
                },
            contentAlignment = Alignment.Center,
            content = content,
        )
    }
}

/** Wide pill button with an optional icon; compresses on touch, knocks on release. */
@Composable
fun GlassButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    accent: Color = PanelPalette.Accent,
    enabled: Boolean = true,
    emphasised: Boolean = false,
) {
    val physical = rememberPhysicalFeedback()
    GlassSurface(
        modifier = modifier
            .height(46.dp)
            .pressable(physical, enabled, onTap = onClick),
        shape = RoundedCornerShape(16.dp),
        deformation = { physical.press },
        tint = if (emphasised) accent else null,
        contentPadding = PaddingValues(horizontal = 16.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .graphicsLayer {
                    scaleX = physical.scale
                    scaleY = physical.scale
                },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (emphasised) PanelPalette.TextPrimary else accent,
                    modifier = Modifier.size(18.dp),
                )
            }
            if (icon != null) {
                Box(Modifier.width(8.dp))
            }
            Text(
                text = label,
                color = if (emphasised) PanelPalette.TextPrimary else PanelPalette.TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
            )
        }
    }
}

/**
 * Selectable pill. Repeated taps nudge the chip a little further each time - the
 * cumulative micro-motion that makes a control feel like it has mass.
 */
@Composable
fun GlassChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    accent: Color = PanelPalette.Accent,
) {
    val physical = rememberPhysicalFeedback()
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier = modifier
            .height(38.dp)
            .graphicsLayer {
                translationX = physical.micro * 46f
                scaleX = physical.scale
                scaleY = physical.scale
            }
            .clip(shape)
            .background(
                if (selected) {
                    Brush.horizontalGradient(
                        listOf(accent.copy(alpha = 0.30f), accent.copy(alpha = 0.14f)),
                    )
                } else {
                    Brush.horizontalGradient(
                        listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.05f)),
                    )
                },
            )
            .rim(accent = if (selected) accent else Color.White, strength = if (selected) 0.55f else 0.22f)
            .pressable(physical, enabled = true, onTap = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (selected) accent else PanelPalette.TextSecondary,
                    modifier = Modifier.size(16.dp),
                )
                Box(Modifier.width(6.dp))
            }
            Text(
                text = label,
                color = if (selected) PanelPalette.TextPrimary else PanelPalette.TextSecondary,
                fontSize = 13.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
            )
        }
    }
}

/**
 * Glass switch whose knob can be dragged, not just tapped.
 *
 * Pressing it squashes the knob, dragging carries it with the finger, flicking throws
 * it, and the ends of the travel are announced with a firm haptic. A plain tap still
 * works for people who expect a switch to behave like a switch.
 */
@Composable
fun GlassSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    accent: Color = PanelPalette.Accent,
    enabled: Boolean = true,
) {
    val physical = rememberPhysicalFeedback()
    val haptics = LocalHaptics.current
    val scope = rememberCoroutineScope()
    val currentOnChange by rememberUpdatedState(onCheckedChange)
    val tuning = LocalGlassTuning.current

    var knob by remember { mutableFloatStateOf(if (checked) 1f else 0f) }
    var dragging by remember { mutableStateOf(false) }
    var settleJob by remember { mutableStateOf<Job?>(null) }
    val density = androidx.compose.ui.platform.LocalDensity.current
    val knobTravelPx = remember(density) { with(density) { (SWITCH_WIDTH - KNOB_SIZE - KNOB_INSET - KNOB_INSET).toPx() } }

    LaunchedEffect(checked, dragging) {
        if (!dragging) {
            val target = if (checked) 1f else 0f
            if (abs(knob - target) > 0.001f) {
                settleJob?.cancel()
                animate(
                    initialValue = knob,
                    targetValue = target,
                    animationSpec = spring(
                        stiffness = SpringMath.settleStiffness(tuning.springFeel),
                        dampingRatio = SpringMath.settleDamping(tuning.springFeel),
                    ),
                ) { animated, _ -> knob = animated }
            }
        }
    }

    Box(
        modifier = modifier
            .size(width = SWITCH_WIDTH, height = SWITCH_HEIGHT)
            .graphicsLayer {
                scaleX = physical.scale
                scaleY = physical.scale
            }
            .clip(CircleShape)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.10f),
                        Color.White.copy(alpha = 0.06f),
                    ),
                ),
            )
            .drawWithCache {
                val trackBrush = Brush.horizontalGradient(
                    listOf(accent.copy(alpha = 0.45f), accent.copy(alpha = 0.22f)),
                )
                onDrawBehind {
                    val fill = knob.coerceIn(0f, 1f)
                    if (fill > 0.01f) {
                        drawRoundRect(
                            brush = trackBrush,
                            size = Size(size.width * (0.35f + 0.65f * fill), size.height),
                            cornerRadius = CornerRadius(size.height / 2f),
                            alpha = 0.9f * fill,
                        )
                    }
                }
            }
            .pointerInput(enabled, tuning.springFeel) {
                if (!enabled) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val width = size.width.toFloat().coerceAtLeast(1f)
                    settleJob?.cancel()
                    dragging = true
                    physical.onDown(down.uptimeMillis)

                    val tracker = VelocityTracker()
                    tracker.addPosition(down.uptimeMillis, down.position)
                    var travel = 0f
                    var lastX = down.position.x

                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break

                        if (change.positionChanged()) {
                            tracker.addPosition(change.uptimeMillis, change.position)
                            travel += abs(change.position.x - lastX)
                            lastX = change.position.x
                            knob = (change.position.x / width).coerceIn(0f, 1f)
                            physical.onMove(0f, width)
                            change.consume()
                        }

                        if (change.changedToUpIgnoreConsumed()) {
                            val velocity = tracker.calculateVelocity().x
                            val wasTap = travel < width * 0.06f
                            val target = when {
                                wasTap -> if (knob > 0.5f) 0f else 1f      // tap = flip
                                velocity > width * 1.2f -> 1f
                                velocity < -width * 1.2f -> 0f
                                knob > 0.5f -> 1f
                                else -> 0f
                            }
                            dragging = false
                            physical.onRelease(velocity, width, wasTap)
                            haptics?.play(if (target > 0.5f) Haptics.Feel.Firm else Haptics.Feel.Soft)
                            settleJob = scope.launch {
                                animate(
                                    initialValue = knob,
                                    targetValue = target,
                                    initialVelocity = velocity / width,
                                    animationSpec = spring(
                                        stiffness = SpringMath.flingStiffness(tuning.springFeel),
                                        dampingRatio = SpringMath.flingDamping(tuning.springFeel),
                                    ),
                                ) { animated, _ -> knob = animated }
                                currentOnChange(target > 0.5f)
                            }
                            break
                        }
                    }
                    dragging = false
                }
            },
    ) {
        // knob - placed in the layout phase, so dragging never recomposes
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = KNOB_INSET)
                .offset {
                    androidx.compose.ui.unit.IntOffset(
                        x = (knobTravelPx * knob.coerceIn(0f, 1f)).toInt(),
                        y = 0,
                    )
                }
                .graphicsLayer {
                    val knobScale = 1f + 0.12f * physical.press + 0.10f * physical.hold
                    scaleX = knobScale
                    scaleY = knobScale
                }
                .size(KNOB_SIZE)
                .clip(CircleShape)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.White, Color.White.copy(alpha = 0.82f)),
                    ),
                )
                .rim(accent = Color.White, strength = 0.5f),
        )
    }
}

/** Hairline rim light used by the lighter-weight glass controls. */
internal fun Modifier.rim(accent: Color, strength: Float): Modifier = this.drawWithCache {
    val strokePx = 1.dp.toPx()
    val brush = Brush.linearGradient(
        colors = listOf(
            accent.copy(alpha = 0.55f * strength),
            Color.White.copy(alpha = 0.05f),
            accent.copy(alpha = 0.20f * strength),
        ),
        start = Offset.Zero,
        end = Offset(size.width, size.height),
    )
    onDrawBehind {
        drawRoundRect(
            brush = brush,
            topLeft = Offset(strokePx / 2f, strokePx / 2f),
            size = Size((size.width - strokePx).coerceAtLeast(1f), (size.height - strokePx).coerceAtLeast(1f)),
            cornerRadius = CornerRadius(size.minDimension / 2f, size.minDimension / 2f),
            style = Stroke(strokePx),
        )
    }
}

private const val TAP_SLOP_PX = 26f

private val SWITCH_WIDTH = 58.dp
private val SWITCH_HEIGHT = 34.dp
private val KNOB_SIZE = 28.dp
private val KNOB_INSET = 3.dp
