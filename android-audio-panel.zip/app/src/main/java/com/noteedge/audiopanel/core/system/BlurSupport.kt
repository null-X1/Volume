package com.noteedge.audiopanel.core.system

import android.content.Context
import android.os.Build
import android.view.WindowManager

/**
 * What kind of *real* blur this device can do.
 *
 * - [renderEffectBlurSupported]: in-app backdrop blur drawn with RenderEffect (Android 12+).
 * - [crossWindowBlurEnabled]: the compositor allows blurring content behind our own
 *   window (required for the floating panel to blur other apps).
 *
 * When neither is available the panel falls back to pure glass shading - translucent,
 * tinted and highlighted - which still looks intentional rather than broken.
 */
object BlurSupport {

    val renderEffectBlurSupported: Boolean
        get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    fun crossWindowBlurEnabled(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        return runCatching {
            val windowManager = context.applicationContext
                .getSystemService(Context.WINDOW_SERVICE) as WindowManager
            windowManager.isCrossWindowBlurEnabled
        }.getOrDefault(false)
    }
}
