package com.noteedge.audiopanel.ui.glass

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.noteedge.audiopanel.core.model.GlassTuning
import kotlin.math.roundToInt

/**
 * The glass slab.
 *
 * Four layers, from back to front:
 *
 *  1. the backdrop scene, re-drawn under this surface and blurred (Android 12+),
 *  2. a tinted, slightly gradient fill,
 *  3. relief - inner shadow, rim light, specular sheen and grain,
 *  4. the caller's content.
 *
 * Everything that changes while a finger is down is read through [deformation] inside
 * layer/draw lambdas, so a drag updates pixels without ever recomposing.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    tuning: GlassTuning = LocalGlassTuning.current,
    shape: Shape = RoundedCornerShape(tuning.cornerRadius.dp),
    deformation: () -> Float = { 0f },
    tint: Color? = null,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    content: @Composable BoxScope.() -> Unit,
) {
    val backdrop = LocalBackdrop.current
    val frameSize = LocalBackdropFrame.current
    val blurSupported = LocalBackdropBlurSupported.current
    val density = LocalDensity.current

    val useRealBlur = blurSupported && tuning.blurEnabled && tuning.blurRadius > 0.5f
    val shadowPx = with(density) { tuning.depth.dp.toPx() }

    var offsetInRoot by remember { mutableStateOf(IntOffset.Zero) }

    Box(
        modifier = modifier
            .onGloballyPositioned { coordinates ->
                val position = coordinates.positionInRoot()
                offsetInRoot = IntOffset(position.x.roundToInt(), position.y.roundToInt())
            }
            .graphicsLayer {
                val press = deformation().coerceIn(0f, 1f)
                this.shape = shape
                clip = true
                shadowElevation = shadowPx * (1f - 0.30f * press)
                ambientShadowColor = Color.Black.copy(alpha = 0.55f)
                spotShadowColor = Color.Black.copy(alpha = 0.65f)
                scaleX = 1f - 0.010f * press
                scaleY = 1f - 0.010f * press
                translationY = -1.6f * press
            },
    ) {
        if (useRealBlur && backdrop != null && frameSize.width > 0 && frameSize.height > 0) {
            Box(Modifier.matchParentSize().clip(shape)) {
                backdrop(
                    Modifier
                        .backdropFrame(frameSize = frameSize, offset = offsetInRoot)
                        .blur(radius = tuning.blurRadius.dp, edgeTreatment = BlurredEdgeTreatment.Rectangle),
                )
            }
        }

        Box(Modifier.matchParentSize().background(glassFill(tuning, tint)))

        Box(
            Modifier
                .matchParentSize()
                .glassRelief(tuning = tuning, cornerRadiusDp = tuning.cornerRadius, deformation = deformation),
        )

        Box(Modifier.padding(contentPadding), content = content)
    }
}

/** Tint + gradient that makes the slab read as a single piece of material. */
private fun glassFill(tuning: GlassTuning, tint: Color?): Brush {
    val base = tint ?: Color.hsv(
        hue = tuning.tintHue * 360f,
        saturation = tuning.saturation.coerceIn(0f, 1f),
        value = 1f,
        alpha = 1f,
    )
    val topAlpha = (tuning.opacity * (1f + 0.38f * tuning.tintStrength)).coerceIn(0f, 1f)
    val bottomAlpha = (tuning.opacity * 0.70f).coerceIn(0f, 1f)
    return Brush.linearGradient(
        colors = listOf(
            base.copy(alpha = topAlpha),
            base.copy(alpha = bottomAlpha),
        ),
    )
}

/** Inner shadow, rim light, moving sheen and grain. */
private fun Modifier.glassRelief(
    tuning: GlassTuning,
    cornerRadiusDp: Float,
    deformation: () -> Float,
): Modifier = this.drawWithCache {
    val cornerPx = cornerRadiusDp.dp.toPx().coerceAtMost(size.minDimension / 2f)
    val strokePx = 1.3.dp.toPx()
    val inset = strokePx / 2f
    val rimPath = Path().apply {
        addRoundRect(
            RoundRect(
                rect = Rect(
                    offset = Offset(inset, inset),
                    size = Size((size.width - strokePx).coerceAtLeast(1f), (size.height - strokePx).coerceAtLeast(1f)),
                ),
                radiusX = cornerPx,
                radiusY = cornerPx,
            ),
        )
    }
    val rimBrush = Brush.linearGradient(
        colors = listOf(
            Color.White.withAlpha(0.46f * tuning.highlight),
            Color.White.withAlpha(0.04f),
            Color.White.withAlpha(0.18f * tuning.highlight),
        ),
        start = Offset(0f, 0f),
        end = Offset(size.width, size.height),
    )
    val innerShadow = Brush.verticalGradient(
        colors = listOf(Color.Black.withAlpha(0.24f), Color.Transparent),
        endY = size.height * 0.55f,
    )
    val grainBrush = ShaderBrush(ImageShader(NoiseTexture.image(), TileMode.Repeated, TileMode.Repeated))
    val grainAlpha = tuning.grain
    val sheenBrush = Brush.linearGradient(
        colors = listOf(Color.White.withAlpha(0.10f), Color.Transparent),
        start = Offset(size.width * 0.06f, 0f),
        end = Offset(size.width * 0.55f, size.height * 0.6f),
    )

    onDrawBehind {
        val press = deformation().coerceIn(0f, 1f)

        // 1. inner shadow gives the slab thickness
        drawRect(brush = innerShadow)

        // 2. rim light - the single most "glass" cue there is
        drawPath(
            path = rimPath,
            brush = rimBrush,
            alpha = (0.72f + 0.28f * press).coerceAtMost(1f),
            style = Stroke(width = strokePx),
        )

        // 3. specular sheen, brighter while the surface is being pressed
        drawRect(brush = sheenBrush, alpha = 0.7f + 0.6f * press)

        // 4. grain
        if (grainAlpha > 0.001f) {
            drawRect(brush = grainBrush, alpha = grainAlpha)
        }
    }
}

/**
 * Lays the backdrop out at full scene size but places it so that the visible window
 * lines up with this surface's position on screen. This is what allows a small card to
 * show "the scene behind it" without copying any bitmaps.
 */
private fun Modifier.backdropFrame(frameSize: IntSize, offset: IntOffset): Modifier = this.layout { measurable, constraints ->
    val width = if (constraints.hasBoundedWidth) constraints.maxWidth else frameSize.width
    val height = if (constraints.hasBoundedHeight) constraints.maxHeight else frameSize.height
    val placeable = measurable.measure(
        Constraints.fixed(frameSize.width.coerceAtLeast(1), frameSize.height.coerceAtLeast(1)),
    )
    layout(width, height) {
        placeable.place(-offset.x, -offset.y)
    }
}

internal fun Color.withAlpha(alpha: Float): Color = copy(alpha = alpha.coerceIn(0f, 1f))
