package com.noteedge.audiopanel

import android.app.Application
import com.noteedge.audiopanel.di.AppContainer

class AudioPanelApplication : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.startAmbientServices()
    }

    override fun onTerminate() {
        container.stopAmbientServices()
        super.onTerminate()
    }
}
