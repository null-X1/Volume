package com.noteedge.audiopanel.ui.glass

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.ImageShader
import com.noteedge.audiopanel.ui.theme.PanelPalette

/**
 * The scene the glass sits on top of.
 *
 * Deliberately static: XOS animates its own wallpapers, and a control panel that burns
 * frames in the background would be a battery tax for nothing. The only motion here is
 * driven by the user - [energy] shifts the blooms while a control is being touched.
 */
fun Modifier.ambientBackdrop(energy: () -> Float): Modifier = this.drawWithCache {
    val grain = ShaderBrush(ImageShader(NoiseTexture.image(), TileMode.Repeated, TileMode.Repeated))
    onDrawBehind {
        val e = energy().coerceIn(0f, 1f)
        val drift = e * size.minDimension * 0.04f

        // Cool bloom, upper left - the "window" light source.
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(PanelPalette.Accent.copy(alpha = 0.22f), Color.Transparent),
                center = Offset(size.width * 0.22f + drift, size.height * 0.14f + drift * 0.5f),
                radius = size.minDimension * 0.85f,
            ),
        )

        // Violet bloom, lower right - gives the glass something warm to pick up.
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(PanelPalette.Violet.copy(alpha = 0.20f), Color.Transparent),
                center = Offset(size.width * 0.86f - drift * 0.6f, size.height * 0.78f - drift * 0.4f),
                radius = size.minDimension * 0.75f,
            ),
        )

        // Deep base vignette so text always has contrast, no matter the wallpaper.
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.Transparent,
                    PanelPalette.Background.copy(alpha = 0.55f),
                    PanelPalette.Background.copy(alpha = 0.85f),
                ),
            ),
        )

        // Fine grain: the detail that makes flat gradients read as a real surface.
        drawRect(brush = grain, alpha = 0.035f)
    }
}

/** Composable wrapper so the backdrop can be provided as a plain lambda. */
@androidx.compose.runtime.Composable
fun AmbientBackdrop(modifier: Modifier = Modifier, energy: () -> Float = { 0f }) {
    androidx.compose.foundation.layout.Box(modifier = modifier.ambientBackdrop(energy))
}
