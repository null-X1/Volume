package com.noteedge.audiopanel.ui.panel

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noteedge.audiopanel.R
import com.noteedge.audiopanel.core.model.GlassTuning
import com.noteedge.audiopanel.ui.components.GlassDivider
import com.noteedge.audiopanel.ui.components.SectionCard
import com.noteedge.audiopanel.ui.components.StatusPill
import com.noteedge.audiopanel.ui.glass.GlassButton
import com.noteedge.audiopanel.ui.glass.GlassSlider
import com.noteedge.audiopanel.ui.glass.GlassSwitch
import com.noteedge.audiopanel.ui.theme.PanelPalette
import com.noteedge.audiopanel.util.Formatters

/** Maps a real value range onto the slider's 0..1 fraction. */
private fun fractionOf(value: Float, range: ClosedFloatingPointRange<Float>): Float {
    val span = (range.endInclusive - range.start).coerceAtLeast(0.0001f)
    return ((value - range.start) / span).coerceIn(0f, 1f)
}

private fun valueOf(fraction: Float, range: ClosedFloatingPointRange<Float>): Float =
    range.start + (range.endInclusive - range.start) * fraction.coerceIn(0f, 1f)

@Composable
private fun TuningSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValue: (Float) -> Unit,
    accent: Color = PanelPalette.Accent,
    formatter: (Float) -> String = { Formatters.percent(it) },
) {
    GlassSlider(
        fraction = fractionOf(value, range),
        onFractionChange = { onValue(valueOf(it, range)) },
        onCommit = { onValue(valueOf(it, range)) },
        label = label,
        accent = accent,
        valueText = { fraction -> formatter(valueOf(fraction, range)) },
    )
}

/** Everything that shapes the glass. Every change is visible immediately. */
@Composable
internal fun AppearanceSection(
    tuning: GlassTuning,
    blurSupported: Boolean,
    crossWindowBlur: Boolean,
    onTuning: ((GlassTuning) -> GlassTuning) -> Unit,
    onReset: () -> Unit,
) {
    SectionCard(
        title = stringResource(R.string.section_appearance),
        subtitle = "Tune the material, not just the colour",
        icon = Icons.Rounded.Palette,
        accent = PanelPalette.Warm,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = stringResource(R.string.tuning_blur),
                color = PanelPalette.TextPrimary,
                fontSize = 13.sp,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusPill(
                    text = if (blurSupported && tuning.blurEnabled) {
                        stringResource(R.string.label_on)
                    } else {
                        stringResource(R.string.label_off)
                    },
                    color = if (blurSupported) PanelPalette.Success else PanelPalette.Warm,
                )
                Spacer(Modifier.width(10.dp))
                GlassSwitch(
                    checked = tuning.blurEnabled && blurSupported,
                    onCheckedChange = { enabled -> onTuning { it.copy(blurEnabled = enabled) } },
                    enabled = blurSupported,
                )
            }
        }
        if (!blurSupported) {
            Text(
                text = "Real backdrop blur needs Android 12 or newer. Below that the panel " +
                    "falls back to tinted glass with the same highlights.",
                color = PanelPalette.TextTertiary,
                fontSize = 11.sp,
                lineHeight = 14.sp,
                modifier = Modifier.size(34.dp),
            )
        }

        Spacer(Modifier.height(8.dp))

        TuningSlider(
            label = stringResource(R.string.tuning_blur),
            value = tuning.blurRadius,
            range = GlassTuning.MIN_BLUR..GlassTuning.MAX_BLUR,
            onValue = { value -> onTuning { it.copy(blurRadius = value) } },
            formatter = { "${it.toInt()} dp" },
        )
        TuningSlider(
            label = stringResource(R.string.tuning_opacity),
            value = tuning.opacity,
            range = GlassTuning.MIN_OPACITY..GlassTuning.MAX_OPACITY,
            onValue = { value -> onTuning { it.copy(opacity = value) } },
        )
        TuningSlider(
            label = stringResource(R.string.tuning_tint),
            value = tuning.tintHue,
            range = 0f..1f,
            onValue = { value -> onTuning { it.copy(tintHue = value) } },
            accent = Color.hsv(tuning.tintHue * 360f, 0.75f, 1f),
            formatter = { "${(it * 360f).toInt()} deg" },
        )
        TuningSlider(
            label = stringResource(R.string.tuning_tint_strength),
            value = tuning.tintStrength,
            range = 0f..1f,
            onValue = { value -> onTuning { it.copy(tintStrength = value) } },
        )
        TuningSlider(
            label = stringResource(R.string.tuning_saturation),
            value = tuning.saturation,
            range = 0f..1.4f,
            onValue = { value -> onTuning { it.copy(saturation = value) } },
            formatter = { Formatters.signed(it) },
        )
        TuningSlider(
            label = stringResource(R.string.tuning_corner),
            value = tuning.cornerRadius,
            range = GlassTuning.MIN_CORNER..GlassTuning.MAX_CORNER,
            onValue = { value -> onTuning { it.copy(cornerRadius = value) } },
            formatter = { "${it.toInt()} dp" },
        )
        TuningSlider(
            label = stringResource(R.string.tuning_depth),
            value = tuning.depth,
            range = GlassTuning.MIN_DEPTH..GlassTuning.MAX_DEPTH,
            onValue = { value -> onTuning { it.copy(depth = value) } },
            formatter = { "${it.toInt()} dp" },
        )
        TuningSlider(
            label = stringResource(R.string.tuning_highlight),
            value = tuning.highlight,
            range = 0f..1f,
            onValue = { value -> onTuning { it.copy(highlight = value) } },
        )
        TuningSlider(
            label = stringResource(R.string.tuning_noise),
            value = tuning.grain,
            range = 0f..0.12f,
            onValue = { value -> onTuning { it.copy(grain = value) } },
            formatter = { Formatters.percent(it / 0.12f) },
        )

        Spacer(Modifier.height(12.dp))
        GlassDivider()
        Spacer(Modifier.height(12.dp))

        Text(
            text = stringResource(R.string.tuning_window_blur),
            color = PanelPalette.TextPrimary,
            fontSize = 13.sp,
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = if (crossWindowBlur) {
                    "System compositor blur is available for the floating window"
                } else {
                    "System compositor blur is disabled by this device/ROM"
                },
                color = PanelPalette.TextTertiary,
                fontSize = 11.sp,
                lineHeight = 14.sp,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(10.dp))
            GlassSwitch(
                checked = tuning.windowBlur && crossWindowBlur,
                onCheckedChange = { enabled -> onTuning { it.copy(windowBlur = enabled) } },
                enabled = crossWindowBlur,
            )
        }

        Spacer(Modifier.height(14.dp))
        GlassButton(
            label = stringResource(R.string.tuning_reset),
            icon = Icons.Rounded.RestartAlt,
            onClick = onReset,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/** Motion and feedback settings - the "feel" half of the material. */
@Composable
internal fun FeelSection(
    tuning: GlassTuning,
    highRefreshSupported: Boolean,
    onTuning: ((GlassTuning) -> GlassTuning) -> Unit,
) {
    SectionCard(
        title = "Feel",
        subtitle = "Springs, haptics and panel refresh",
        icon = Icons.Rounded.Speed,
        accent = PanelPalette.Success,
    ) {
        TuningSlider(
            label = stringResource(R.string.tuning_spring),
            value = tuning.springFeel,
            range = 0f..1f,
            onValue = { value -> onTuning { it.copy(springFeel = value) } },
            accent = PanelPalette.Success,
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Icon(
                    imageVector = Icons.Rounded.Vibration,
                    contentDescription = null,
                    tint = PanelPalette.Success,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.tuning_haptics),
                    color = PanelPalette.TextPrimary,
                    fontSize = 13.sp,
                )
            }
            GlassSwitch(
                checked = tuning.hapticsEnabled,
                onCheckedChange = { enabled -> onTuning { it.copy(hapticsEnabled = enabled) } },
            )
        }

        TuningSlider(
            label = stringResource(R.string.tuning_haptic_strength),
            value = tuning.hapticStrength,
            range = 0f..1f,
            onValue = { value -> onTuning { it.copy(hapticStrength = value) } },
        )

        Spacer(Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.tuning_high_refresh),
                    color = PanelPalette.TextPrimary,
                    fontSize = 13.sp,
                )
                Text(
                    text = if (highRefreshSupported) {
                        "Ask the panel for its fastest mode while the glass is on screen"
                    } else {
                        "This display only reports a single refresh mode"
                    },
                    color = PanelPalette.TextTertiary,
                    fontSize = 11.sp,
                    lineHeight = 14.sp,
                )
            }
            GlassSwitch(
                checked = tuning.highRefreshRate && highRefreshSupported,
                onCheckedChange = { enabled -> onTuning { it.copy(highRefreshRate = enabled) } },
                enabled = highRefreshSupported,
            )
        }
    }
}
