package com.noteedge.audiopanel.core.audio

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Equalizer, bass boost and stereo widening through the public
 * [android.media.audiofx] API.
 *
 * The framework is deliberately defensive here: an effect may be unsupported, may be
 * held by another app (a music player with its own session effect), or may simply be
 * refused by the OEM audio HAL. None of those cases may crash the panel, so everything
 * is probed and reported as an explicit state instead.
 */
class AudioEffectsController(
    private val context: Context,
    private val scope: CoroutineScope,
) {

    data class Band(
        val index: Short,
        val centerHz: Int,
        val levelUnit: Float,
    )

    data class EffectsState(
        val engineAvailable: Boolean = false,
        val enabled: Boolean = false,
        val bands: List<Band> = emptyList(),
        val levelValues: List<Float> = emptyList(),
        val levelRangeDb: Pair<Float, Float> = -15f to 15f,
        val bassSupported: Boolean = false,
        val bassValue: Float = 0f,
        val virtualizerSupported: Boolean = false,
        val virtualizerValue: Float = 0f,
        val statusMessage: String? = null,
    )

    private val _state = MutableStateFlow(EffectsState())
    val state: StateFlow<EffectsState> = _state.asStateFlow()

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var attached = false

    /** Lazily builds the effects chain against the global output mix (session 0). */
    fun ensureAttached(): Boolean {
        if (attached) return true
        attached = true
        var statusMessage: String? = null
        try {
            equalizer = Equalizer(0, GLOBAL_SESSION_ID).also { eq ->
                if (!eq.hasControl()) {
                    statusMessage = "Equalizer is held by another audio session"
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Equalizer unavailable", t)
            equalizer = null
            statusMessage = "This output does not expose an equalizer"
        }
        bassBoost = runCatching { BassBoost(0, GLOBAL_SESSION_ID) }.getOrElse { null }
        virtualizer = runCatching { Virtualizer(0, GLOBAL_SESSION_ID) }.getOrElse { null }

        val eq = equalizer
        if (eq == null) {
            _state.value = EffectsState(
                engineAvailable = false,
                bassSupported = false,
                virtualizerSupported = virtualizer?.hasControl() == true,
                statusMessage = statusMessage ?: "Audio effects engine unavailable",
            )
            return false
        }

        val bandCount = eq.numberOfBands.toInt()
        val bands = buildList {
            for (index in 0 until bandCount) {
                val band = index.toShort()
                val freqMilliHz = runCatching { eq.getCenterFreq(band) }.getOrDefault(0)
                add(Band(index = band, centerHz = freqMilliHz / 1000, levelUnit = 0f))
            }
        }
        val range = runCatching { eq.bandLevelRange }.getOrNull()
        val rangeDb = if (range != null && range.size == 2) {
            (range[0] / 100f) to (range[1] / 100f)
        } else {
            -15f to 15f
        }
        val rangeSpan = (rangeDb.second - rangeDb.first).coerceAtLeast(1f)
        val values = buildList {
            for (index in 0 until bandCount) {
                val level = runCatching { eq.getBandLevel(index.toShort()).toFloat() }.getOrDefault(0f)
                add(((level / 100f) - rangeDb.first) / rangeSpan)
            }
        }

        _state.value = EffectsState(
            engineAvailable = true,
            enabled = runCatching { eq.enabled }.getOrDefault(false),
            bands = bands,
            levelValues = values,
            levelRangeDb = rangeDb,
            bassSupported = bassBoost?.hasControl() == true,
            bassValue = readStrength(bassBoost),
            virtualizerSupported = virtualizer?.hasControl() == true,
            virtualizerValue = readStrength(virtualizer),
            statusMessage = statusMessage,
        )
        return true
    }

    fun setEnabled(enabled: Boolean) = mutate { state ->
        equalizer?.let { eq -> if (eq.hasControl()) runCatching { eq.enabled = enabled } }
        bassBoost?.let { bb ->
            if (bb.hasControl()) runCatching { bb.enabled = enabled && state.bassValue > 0.001f }
        }
        virtualizer?.let { vk ->
            if (vk.hasControl()) runCatching { vk.enabled = enabled && state.virtualizerValue > 0.001f }
        }
        state.copy(enabled = enabled)
    }

    /** [fraction] is 0..1 across the band's allowed range. */
    fun setBand(fraction: Float, bandIndex: Short) = mutate { state ->
        val eq = equalizer
        if (eq != null && eq.hasControl()) {
            val range = runCatching { eq.bandLevelRange }.getOrNull()
            val minMb = range?.getOrNull(0)?.toInt() ?: -1500
            val maxMb = range?.getOrNull(1)?.toInt() ?: 1500
            val target = (minMb + fraction.coerceIn(0f, 1f) * (maxMb - minMb)).roundToInt().toShort()
            runCatching { eq.setBandLevel(bandIndex, target) }
        }
        val values = state.levelValues.toMutableList()
        val pos = bandIndex.toInt()
        if (pos in values.indices) values[pos] = fraction.coerceIn(0f, 1f)
        state.copy(levelValues = values)
    }

    fun setBass(fraction: Float) = mutate { state ->
        bassBoost?.let { bb ->
            if (bb.hasControl()) {
                runCatching { bb.setStrength((fraction.coerceIn(0f, 1f) * 1000f).roundToInt().toShort()) }
                runCatching { bb.enabled = state.enabled && fraction > 0.001f }
            }
        }
        state.copy(bassValue = fraction.coerceIn(0f, 1f))
    }

    fun setVirtualizer(fraction: Float) = mutate { state ->
        virtualizer?.let { vk ->
            if (vk.hasControl()) {
                runCatching { vk.setStrength((fraction.coerceIn(0f, 1f) * 1000f).roundToInt().toShort()) }
                runCatching { vk.enabled = state.enabled && fraction > 0.001f }
            }
        }
        state.copy(virtualizerValue = fraction.coerceIn(0f, 1f))
    }

    /** Flattens every band back to 0 dB and drops the extras. */
    fun reset() = mutate { state ->
        equalizer?.let { eq ->
            if (eq.hasControl()) {
                val mid = ((state.levelRangeDb.first + state.levelRangeDb.second) / 2f * 100f).roundToInt().toShort()
                val bandCount = eq.numberOfBands.toInt()
                for (index in 0 until bandCount) {
                    runCatching { eq.setBandLevel(index.toShort(), mid) }
                }
            }
        }
        val flat = (0f - state.levelRangeDb.first) /
            (state.levelRangeDb.second - state.levelRangeDb.first).coerceAtLeast(1f)
        bassBoost?.let { bb -> if (bb.hasControl()) runCatching { bb.setStrength(0) } }
        virtualizer?.let { vk -> if (vk.hasControl()) runCatching { vk.setStrength(0) } }
        state.copy(
            levelValues = List(state.levelValues.size) { flat.coerceIn(0f, 1f) },
            bassValue = 0f,
            virtualizerValue = 0f,
        )
    }

    fun release() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        equalizer = null
        bassBoost = null
        virtualizer = null
        attached = false
    }

    private fun mutate(block: (EffectsState) -> EffectsState) {
        scope.launch {
            val updated = block(_state.value)
            // keep the UI >= 16 ms apart at most; effect writes are cheap but serialised
            val elapsed = SystemClock.uptimeMillis() - lastMutationAt
            if (elapsed in 1 until 12) kotlinx.coroutines.delay(12 - elapsed)
            lastMutationAt = SystemClock.uptimeMillis()
            _state.value = updated
        }
    }

    private var lastMutationAt = 0L

    private fun readStrength(effect: Any?): Float = when (effect) {
        is BassBoost -> runCatching { effect.roundedStrength / 1000f }.getOrDefault(0f)
        is Virtualizer -> runCatching { effect.roundedStrength / 1000f }.getOrDefault(0f)
        else -> 0f
    }

    private companion object {
        const val TAG = "AudioEffects"
        const val GLOBAL_SESSION_ID = 0
    }
}
