package com.noteedge.audiopanel.ui.glass

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noteedge.audiopanel.core.model.VolumeMath
import com.noteedge.audiopanel.core.system.Haptics
import com.noteedge.audiopanel.ui.interaction.SpringMath
import com.noteedge.audiopanel.ui.interaction.rememberPhysicalFeedback
import com.noteedge.audiopanel.ui.theme.PanelPalette
import com.noteedge.audiopanel.util.Formatters
import kotlin.math.abs
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

private const val LONG_PRESS_MS = 420L
/** How much the fine-tuning mode slows the finger down after a long press. */
private const val FINE_GAIN = 0.35f

/**
 * The panel's main control.
 *
 * There is no click listener anywhere in this file. The thumb is positioned from the
 * raw pointer stream every frame, so the finger *is* the control:
 *
 *  - touch down        -> the body compresses and the glass brightens
 *  - drag              -> thumb tracks the finger exactly, energy feeds the backdrop
 *  - long press        -> "grip" mode: the control swells and the gain drops to 35%
 *                         so a held finger can dial in a precise level
 *  - repeated taps     -> cumulative micro-motion, escalating haptics
 *  - fast release      -> the knob is thrown a little past the detent and springs back
 */
@Composable
fun GlassSlider(
    fraction: Float,
    onFractionChange: (Float) -> Unit,
    onCommit: (Float) -> Unit = {},
    modifier: Modifier = Modifier,
    accent: Color = PanelPalette.Accent,
    steps: Int = 0,
    enabled: Boolean = true,
    label: String? = null,
    leading: (@Composable () -> Unit)? = null,
    valueText: (Float) -> String = { Formatters.percent(it) },
) {
    val tuning = LocalGlassTuning.current
    val haptics = LocalHaptics.current
    val physical = rememberPhysicalFeedback()
    val energy = LocalPanelEnergy.current
    val scope = rememberCoroutineScope()

    // The live value is a plain state: the finger writes to it directly, and only the
    // settle after release goes through an animation. No animation object ever needs to
    // be touched from inside the pointer loop, which keeps the gesture scope pure.
    var live by remember { mutableFloatStateOf(fraction.coerceIn(0f, 1f)) }
    var dragging by remember { mutableStateOf(false) }
    var settleJob by remember { mutableStateOf<Job?>(null) }

    val currentOnChange by rememberUpdatedState(onFractionChange)
    val currentOnCommit by rememberUpdatedState(onCommit)
    val currentValueText by rememberUpdatedState(valueText)

    // Re-sync when the platform value changes behind our back (hardware keys, other apps).
    LaunchedEffect(fraction, dragging) {
        if (!dragging) {
            val target = fraction.coerceIn(0f, 1f)
            if (abs(live - target) > 0.002f) {
                settleJob?.cancel()
                animate(
                    initialValue = live,
                    targetValue = target,
                    animationSpec = spring(
                        stiffness = SpringMath.settleStiffness(tuning.springFeel),
                        dampingRatio = SpringMath.settleDamping(tuning.springFeel),
                    ),
                ) { animated, _ -> live = animated }
            }
        }
    }

    val readout by remember {
        derivedStateOf { currentValueText(live) }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        if (label != null || leading != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth().height(22.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (leading != null) {
                        Box(Modifier.size(22.dp), contentAlignment = Alignment.Center) { leading() }
                        Spacer(Modifier.width(8.dp))
                    }
                    if (label != null) {
                        Text(
                            text = label,
                            color = PanelPalette.TextSecondary,
                            fontSize = 13.sp,
                            maxLines = 1,
                        )
                    }
                }
                Text(
                    text = readout,
                    color = PanelPalette.TextPrimary,
                    fontSize = 13.sp,
                    maxLines = 1,
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
                .graphicsLayer {
                    scaleX = physical.scale
                    scaleY = physical.scale
                }
                .pointerInput(enabled, steps, tuning.springFeel) {
                    if (!enabled) return@pointerInput
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val trackWidth = size.width.toFloat().coerceAtLeast(1f)
                        val trackOrigin = 0f

                        settleJob?.cancel()
                        dragging = true
                        physical.onDown(down.uptimeMillis)
                        energy?.pulse(0.22f)

                        val tracker = VelocityTracker()
                        tracker.addPosition(down.uptimeMillis, down.position)

                        var lastX = down.position.x
                        var lastTime = down.uptimeMillis
                        var travel = 0f
                        var holding = false
                        var holdBaseValue = live
                        var holdBaseX = 0f
                        var lastDetent = VolumeMath.detentIndex(live, steps)

                        // Follow the finger from the very first frame of the touch.
                        val initialTarget = ((down.position.x - trackOrigin) / trackWidth).coerceIn(0f, 1f)
                        live = initialTarget
                        currentOnChange(initialTarget)

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break

                            val held = change.uptimeMillis - down.uptimeMillis
                            if (!holding && held >= LONG_PRESS_MS &&
                                abs(change.position.x - down.position.x) < trackWidth * 0.05f
                            ) {
                                holding = true
                                holdBaseValue = live
                                holdBaseX = change.position.x
                                physical.onLongPress()
                            }

                            if (change.positionChanged()) {
                                tracker.addPosition(change.uptimeMillis, change.position)
                                val dx = change.position.x - lastX
                                val dtMillis = (change.uptimeMillis - lastTime).coerceAtLeast(1L)
                                val velocity = dx / (dtMillis / 1000f)
                                travel += abs(dx)

                                physical.onMove(velocity, trackWidth)
                                energy?.pulse((abs(velocity) / trackWidth).coerceIn(0f, 1f))

                                val target = if (holding) {
                                    (holdBaseValue + (change.position.x - holdBaseX) / trackWidth * FINE_GAIN)
                                        .coerceIn(0f, 1f)
                                } else {
                                    ((change.position.x - trackOrigin) / trackWidth).coerceIn(0f, 1f)
                                }
                                live = target
                                currentOnChange(target)

                                if (steps > 1) {
                                    val detent = VolumeMath.detentIndex(target, steps)
                                    if (detent != lastDetent) {
                                        lastDetent = detent
                                        haptics?.play(Haptics.Feel.Tick)
                                    }
                                } else if (target <= 0.002f || target >= 0.998f) {
                                    // bottoming out feels like hitting a stop
                                    haptics?.play(Haptics.Feel.Firm)
                                }

                                change.consume()
                                lastX = change.position.x
                                lastTime = change.uptimeMillis
                            }

                            if (change.changedToUpIgnoreConsumed()) {
                                val velocity = tracker.calculateVelocity().x
                                val snapped = VolumeMath.snap(live, steps)
                                val wasTap = travel < trackWidth * 0.02f

                                dragging = false
                                if (holding) physical.onLongPressEnd()
                                physical.onRelease(velocity, trackWidth, wasTap)
                                energy?.settle()

                                val overshoot = SpringMath.inertiaFraction(velocity, trackWidth, maxTravel = 0.09f)
                                settleJob = scope.launch {
                                    if (abs(overshoot) > 0.003f) {
                                        animate(
                                            initialValue = live,
                                            targetValue = (snapped + overshoot).coerceIn(0f, 1f),
                                            initialVelocity = velocity / trackWidth,
                                            animationSpec = spring(
                                                stiffness = SpringMath.flingStiffness(tuning.springFeel),
                                                dampingRatio = SpringMath.flingDamping(tuning.springFeel),
                                            ),
                                        ) { animated, _ -> live = animated }
                                    }
                                    animate(
                                        initialValue = live,
                                        targetValue = snapped,
                                        animationSpec = spring(
                                            stiffness = SpringMath.settleStiffness(tuning.springFeel),
                                            dampingRatio = SpringMath.settleDamping(tuning.springFeel),
                                        ),
                                    ) { animated, _ -> live = animated }
                                    currentOnChange(snapped)
                                    currentOnCommit(snapped)
                                }
                                break
                            }
                        }
                    }
                }
                .drawWithCache {
                    val trackHeight = 15.dp.toPx()
                    val thumbRadius = 11.dp.toPx()
                    val hairline = 1.dp.toPx()
                    val corner = CornerRadius(trackHeight / 2f, trackHeight / 2f)
                    val trackColor = Color.White.copy(alpha = 0.09f)
                    val trackEdge = Color.White.copy(alpha = 0.07f)
                    val fillBrush = Brush.horizontalGradient(
                        colors = listOf(accent.copy(alpha = 0.85f), accent),
                    )
                    val headGlow = Brush.radialGradient(
                        colors = listOf(accent.copy(alpha = 0.60f), Color.Transparent),
                    )
                    val thumbBrush = Brush.linearGradient(
                        colors = listOf(Color.White, Color.White.copy(alpha = 0.78f)),
                    )
                    val thumbEdge = Color.White.copy(alpha = 0.85f)

                    onDrawBehind {
                        val fraction = live.coerceIn(0f, 1f)
                        val press = physical.press
                        val hold = physical.hold
                        val glow = physical.glow
                        val stretch = physical.stretch
                        val micro = physical.micro

                        val trackTop = (size.height - trackHeight) / 2f
                        val centerY = size.height / 2f

                        // recessed channel
                        drawRoundRect(
                            color = trackColor,
                            topLeft = Offset(0f, trackTop),
                            size = Size(size.width, trackHeight),
                            cornerRadius = corner,
                        )
                        drawRoundRect(
                            color = trackEdge,
                            topLeft = Offset(hairline / 2f, trackTop),
                            size = Size(size.width - hairline, trackHeight),
                            cornerRadius = corner,
                            style = Stroke(hairline),
                        )

                        // filled level
                        val fillWidth = (size.width * fraction).coerceAtLeast(trackHeight)
                        drawRoundRect(
                            brush = fillBrush,
                            topLeft = Offset(0f, trackTop),
                            size = Size(fillWidth, trackHeight),
                            cornerRadius = corner,
                            alpha = 0.92f,
                        )

                        // "liquid" head - the light the level carries with it
                        drawCircle(
                            brush = headGlow,
                            radius = trackHeight * (1.35f + 0.55f * press),
                            center = Offset(fillWidth, centerY),
                        )

                        // detents
                        if (steps in 2..32) {
                            for (index in 1 until steps - 1) {
                                val x = size.width * index / (steps - 1)
                                drawLine(
                                    color = Color.White.copy(alpha = if (x / size.width <= fraction) 0.28f else 0.12f),
                                    start = Offset(x, trackTop + trackHeight * 0.26f),
                                    end = Offset(x, trackTop + trackHeight * 0.74f),
                                    strokeWidth = hairline,
                                )
                            }
                        }

                        // thumb - offset by the accumulated micro-motion and squashed by drag energy
                        val thumbX = (size.width * fraction) + micro * size.width
                        val pivot = Offset(thumbX, centerY)
                        val radius = thumbRadius * physical.knobScale
                        scale(
                            scaleX = 1f - 0.18f * stretch,
                            scaleY = 1f + 0.13f * stretch,
                            pivot = pivot,
                        ) {
                            drawCircle(
                                color = Color.Black.copy(alpha = 0.28f),
                                radius = radius * 1.05f,
                                center = Offset(thumbX, centerY + 2.dp.toPx()),
                            )
                            drawCircle(brush = thumbBrush, radius = radius, center = pivot)
                            drawCircle(
                                color = accent.copy(alpha = 0.35f + 0.45f * glow),
                                radius = radius * 0.66f,
                                center = pivot,
                            )
                            drawCircle(
                                color = thumbEdge,
                                radius = radius,
                                center = pivot,
                                style = Stroke(hairline * 1.3f),
                            )
                        }

                        // grip ring - only while the control is held for precision
                        if (hold > 0.01f) {
                            drawCircle(
                                color = accent.copy(alpha = 0.30f * hold),
                                radius = radius * (1.45f + 0.35f * hold),
                                center = pivot,
                                style = Stroke(hairline * 1.6f),
                            )
                        }
                    }
                },
        )
    }
}
