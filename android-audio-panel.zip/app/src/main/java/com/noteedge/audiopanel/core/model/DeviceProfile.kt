package com.noteedge.audiopanel.core.model

/** Snapshot of the host device, used for diagnostics and the tuning hints. */
data class DeviceProfile(
    val manufacturer: String,
    val brand: String,
    val model: String,
    val device: String,
    val androidRelease: String,
    val sdkInt: Int,
    val buildFingerprintTag: String,
    val skin: String?,
    val isTargetDevice: Boolean,
    val refreshRate: Float,
    val maxRefreshRate: Float,
    val supportsMoreThan60Hz: Boolean,
    val renderEffectBlur: Boolean,
    val crossWindowBlur: Boolean,
) {
    val displayName: String get() = listOf(manufacturer, model)
        .filter { it.isNotBlank() }
        .joinToString(" ")
        .trim()
}
