package com.noteedge.audiopanel.util

import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/** Small formatting helpers shared by the panel and the diagnostics card. */
object Formatters {

    fun percent(value: Float): String = "${(value.coerceIn(0f, 1f) * 100f).roundToInt()}%"

    fun percentFromIndex(index: Int, min: Int, max: Int): String {
        val span = (max - min).coerceAtLeast(1)
        return "${(((index - min).toFloat() / span).coerceIn(0f, 1f) * 100f).roundToInt()}%"
    }

    fun hz(value: Float): String =
        if (value <= 0f) "--" else if (value >= 100f) "${value.roundToInt()} Hz"
        else String.format(Locale.US, "%.1f Hz", value)

    fun decibels(value: Float): String {
        val rounded = (value * 10f).roundToInt() / 10f
        val sign = if (rounded > 0f) "+" else ""
        return "$sign$rounded dB"
    }

    fun hertzFromMilliHz(centerHz: Int): String = when {
        centerHz >= 1000 -> String.format(Locale.US, "%.1fk", centerHz / 1000f)
        else -> "$centerHz"
    }

    fun signed(value: Float, suffix: String = ""): String {
        val rounded = (value * 100f).roundToInt() / 100f
        val sign = if (rounded > 0f) "+" else ""
        val rendered = if (abs(rounded - rounded.toInt()) < 0.01f) rounded.toInt().toString()
        else rounded.toString()
        return "$sign$rendered$suffix"
    }
}
