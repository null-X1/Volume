package com.noteedge.audiopanel.ui.panel

import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DragIndicator
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noteedge.audiopanel.R
import com.noteedge.audiopanel.core.model.AudioStreamKind
import com.noteedge.audiopanel.core.model.StreamVolume
import com.noteedge.audiopanel.ui.components.GlassDivider
import com.noteedge.audiopanel.ui.components.StatusPill
import com.noteedge.audiopanel.ui.glass.GlassButton
import com.noteedge.audiopanel.ui.glass.GlassIconButton
import com.noteedge.audiopanel.ui.glass.GlassSlider
import com.noteedge.audiopanel.ui.glass.GlassSurface
import com.noteedge.audiopanel.ui.theme.PanelPalette

/**
 * The floating panel itself.
 *
 * Collapsed it is one slider plus a mute toggle - the two things people reach for while
 * watching something. Expanded it becomes the full six-stream mixer. The header carries
 * the window drag gesture, so moving the panel feels like moving the object you grabbed.
 */
@Composable
fun CompactPanel(
    streams: Map<AudioStreamKind, StreamVolume>,
    expanded: Boolean,
    routeLabel: String?,
    onExpandedChange: (Boolean) -> Unit,
    onVolumeChange: (AudioStreamKind, Float) -> Unit,
    onVolumeCommit: (AudioStreamKind, Float) -> Unit,
    onToggleMute: (AudioStreamKind) -> Unit,
    onMuteAll: () -> Unit,
    onDrag: (Float, Float) -> Unit,
    onDragEnd: () -> Unit,
    onOpenPanel: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    GlassSurface(
        modifier = modifier.width(298.dp),
        contentPadding = PaddingValues(14.dp),
    ) {
        Column(Modifier.width(270.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragEnd = { onDragEnd() },
                                onDragCancel = { onDragEnd() },
                            ) { change, dragAmount ->
                                change.consume()
                                onDrag(dragAmount.x, dragAmount.y)
                            }
                        },
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.DragIndicator,
                            contentDescription = "Move panel",
                            tint = PanelPalette.TextTertiary,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                color = PanelPalette.TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                text = routeLabel ?: "Floating panel",
                                color = PanelPalette.TextTertiary,
                                fontSize = 10.sp,
                            )
                        }
                    }
                }
                GlassIconButton(
                    onClick = { onExpandedChange(!expanded) },
                    buttonSize = 32.dp,
                ) {
                    Icon(
                        imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                        contentDescription = if (expanded) "Collapse" else "Expand",
                        tint = PanelPalette.TextSecondary,
                        modifier = Modifier.size(16.dp),
                    )
                }
                Spacer(Modifier.width(6.dp))
                GlassIconButton(
                    onClick = onClose,
                    buttonSize = 32.dp,
                    accent = PanelPalette.Danger,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = stringResource(R.string.overlay_stop),
                        tint = PanelPalette.Danger,
                        modifier = Modifier.size(15.dp),
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            GlassDivider()
            Spacer(Modifier.height(10.dp))

            val visible = if (expanded) AudioStreamKind.displayOrder else listOf(AudioStreamKind.MEDIA)

            visible.forEachIndexed { index, kind ->
                val volume = streams[kind] ?: return@forEachIndexed
                if (index > 0) Spacer(Modifier.height(4.dp))
                val accent = kind.accentColor()
                GlassSlider(
                    fraction = volume.fraction,
                    onFractionChange = { onVolumeChange(kind, it) },
                    onCommit = { onVolumeCommit(kind, it) },
                    accent = accent,
                    label = stringResource(kind.labelRes),
                    leading = {
                        GlassIconButton(
                            onClick = { onToggleMute(kind) },
                            accent = accent,
                            buttonSize = 26.dp,
                        ) {
                            Icon(
                                imageVector = if (volume.isMuted) Icons.AutoMirrored.Rounded.VolumeOff else kind.glyph(),
                                contentDescription = stringResource(R.string.action_mute_all),
                                tint = if (volume.isMuted) PanelPalette.Danger else accent,
                                modifier = Modifier.size(14.dp),
                            )
                        }
                    },
                )
            }

            if (expanded) {
                Spacer(Modifier.height(12.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    GlassButton(
                        label = stringResource(R.string.action_mute_all),
                        icon = Icons.AutoMirrored.Rounded.VolumeOff,
                        onClick = onMuteAll,
                        modifier = Modifier.weight(1f),
                    )
                    GlassIconButton(onClick = onOpenPanel, buttonSize = 34.dp) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.VolumeUp,
                            contentDescription = "Open full panel",
                            tint = PanelPalette.Accent,
                            modifier = Modifier.size(16.dp),
                        )
                    }
                }
            } else {
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusPill(text = "Tap to expand", color = PanelPalette.TextTertiary)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "Drag the header to move",
                        color = PanelPalette.TextTertiary,
                        fontSize = 10.sp,
                    )
                }
            }
        }
    }
}
