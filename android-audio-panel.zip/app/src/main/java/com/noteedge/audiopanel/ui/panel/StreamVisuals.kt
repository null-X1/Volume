package com.noteedge.audiopanel.ui.panel

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PhoneInTalk
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.noteedge.audiopanel.core.model.AudioStreamKind
import com.noteedge.audiopanel.ui.theme.PanelPalette

/** Colour + glyph per stream, so a slider is identifiable at a glance. */
internal fun AudioStreamKind.accentColor(): Color = when (this) {
    AudioStreamKind.MEDIA -> PanelPalette.media
    AudioStreamKind.RING -> PanelPalette.ringAccent
    AudioStreamKind.NOTIFICATION -> PanelPalette.notificationAccent
    AudioStreamKind.ALARM -> PanelPalette.alarmAccent
    AudioStreamKind.CALL -> PanelPalette.callAccent
    AudioStreamKind.SYSTEM -> PanelPalette.systemAccent
}

internal fun AudioStreamKind.glyph(): ImageVector = when (this) {
    AudioStreamKind.MEDIA -> Icons.AutoMirrored.Rounded.VolumeUp
    AudioStreamKind.RING -> Icons.Rounded.NotificationsActive
    AudioStreamKind.NOTIFICATION -> Icons.Rounded.Notifications
    AudioStreamKind.ALARM -> Icons.Rounded.Alarm
    AudioStreamKind.CALL -> Icons.Rounded.PhoneInTalk
    AudioStreamKind.SYSTEM -> Icons.Rounded.Bolt
}
