package com.noteedge.audiopanel.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.noteedge.audiopanel.core.model.GlassTuning
import com.noteedge.audiopanel.core.model.OverlaySettings
import com.noteedge.audiopanel.core.system.BlurSupport
import com.noteedge.audiopanel.core.system.RefreshRateController

/**
 * Owns the floating window: creation, drag updates, blur intensity and teardown.
 *
 * The window is a plain [TYPE_APPLICATION_OVERLAY] window, so it needs the user-granted
 * "display over other apps" permission and nothing else. Blur behind the window is asked
 * for through the public `FLAG_BLUR_BEHIND` / `blurBehindRadius` API on Android 12+, and
 * silently skipped where the ROM (including some XOS builds) does not enable it.
 */
class OverlayWindowController(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = context.resources.displayMetrics.density

    private var host: OverlayHost? = null
    private var view: ComposeView? = null
    private var params: WindowManager.LayoutParams? = null

    var isShowing: Boolean = false
        private set

    /** Where the panel currently sits, in pixels. */
    val position: Pair<Int, Int>
        get() = params?.let { it.x to it.y } ?: (24 to 260)

    fun show(
        stored: OverlaySettings,
        tuning: GlassTuning,
        content: @Composable () -> Unit,
    ): Boolean {
        if (isShowing) return true

        val overlayHost = OverlayHost().also { it.attach() }
        val composeView = ComposeView(context)

        // Compose resolves these three owners through the view tree of its host view.
        composeView.setViewTreeLifecycleOwner(overlayHost)
        composeView.setViewTreeViewModelStoreOwner(overlayHost)
        composeView.setViewTreeSavedStateRegistryOwner(overlayHost)

        composeView.setContent(content)

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags(tuning),
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = stored.x ?: dp(24)
            y = stored.y ?: dp(264)
        }

        applyBlur(layoutParams, tuning)
        applyRefreshMode(layoutParams, tuning)

        return try {
            windowManager.addView(composeView, layoutParams)
            host = overlayHost
            view = composeView
            params = layoutParams
            isShowing = true
            true
        } catch (error: RuntimeException) {
            // XOS can refuse the window when the permission was revoked mid-flight.
            overlayHost.destroy()
            false
        }
    }

    /** Moves the window by a finger delta, keeping it on screen. */
    fun moveBy(deltaX: Float, deltaY: Float) {
        val current = params ?: return
        val composeView = view ?: return
        val metrics = context.resources.displayMetrics
        val maxX = (metrics.widthPixels - dp(72)).coerceAtLeast(0)
        val maxY = (metrics.heightPixels - dp(72)).coerceAtLeast(0)
        current.x = (current.x + deltaX.toInt()).coerceIn(0, maxX)
        current.y = (current.y + deltaY.toInt()).coerceIn(0, maxY)
        runCatching { windowManager.updateViewLayout(composeView, current) }
    }

    fun applyTuning(tuning: GlassTuning) {
        val current = params ?: return
        val composeView = view ?: return
        val blurChanged = applyBlur(current, tuning)
        val refreshChanged = applyRefreshMode(current, tuning)
        if (blurChanged || refreshChanged) {
            runCatching { windowManager.updateViewLayout(composeView, current) }
        }
    }

    fun hide() {
        val composeView = view
        if (composeView != null) {
            runCatching { windowManager.removeView(composeView) }
        }
        view = null
        params = null
        host?.destroy()
        host = null
        isShowing = false
    }

    // ---- internals ---------------------------------------------------------

    private fun baseFlags(tuning: GlassTuning): Int {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (wantsWindowBlur(tuning)) flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
        return flags
    }

    private fun wantsWindowBlur(tuning: GlassTuning): Boolean =
        tuning.windowBlur &&
            tuning.blurEnabled &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            BlurSupport.crossWindowBlurEnabled(context)

    /** Returns true when the window needs to be re-applied. */
    private fun applyBlur(layoutParams: WindowManager.LayoutParams, tuning: GlassTuning): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false
        val wants = wantsWindowBlur(tuning)
        val flags = if (wants) {
            layoutParams.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
        } else {
            layoutParams.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND.inv()
        }
        val changed = flags != layoutParams.flags
        layoutParams.flags = flags
        val radius = if (wants) dp(tuning.blurRadius.toInt().coerceIn(1, 60)) else 0
        if (layoutParams.blurBehindRadius != radius) {
            layoutParams.blurBehindRadius = radius
            return true
        }
        return changed
    }

    private fun applyRefreshMode(layoutParams: WindowManager.LayoutParams, tuning: GlassTuning): Boolean {
        val modeId = if (tuning.highRefreshRate) RefreshRateController.highestRefreshModeId(context) else -1
        if (modeId <= 0) return false
        if (layoutParams.preferredDisplayModeId == modeId) return false
        val applied = runCatching {
            layoutParams.preferredDisplayModeId = modeId
            true
        }.getOrDefault(false)
        return applied
    }

    private fun dp(value: Int): Int = (value * density).toInt()
}
