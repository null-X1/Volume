package com.noteedge.audiopanel.ui.panel

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.SurroundSound
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noteedge.audiopanel.R
import com.noteedge.audiopanel.core.audio.AudioEffectsController
import com.noteedge.audiopanel.ui.components.GlassDivider
import com.noteedge.audiopanel.ui.components.SectionCard
import com.noteedge.audiopanel.ui.components.StatusPill
import com.noteedge.audiopanel.ui.glass.GlassButton
import com.noteedge.audiopanel.ui.glass.GlassSlider
import com.noteedge.audiopanel.ui.glass.GlassSwitch
import com.noteedge.audiopanel.ui.glass.GlassVerticalSlider
import com.noteedge.audiopanel.ui.theme.PanelPalette
import com.noteedge.audiopanel.util.Formatters

/**
 * Equalizer, bass boost and stereo widening, all through the public
 * android.media.audiofx API. Availability is reported honestly instead of faked:
 * a Bluetooth sink or a player holding its own session will show as unavailable.
 */
@Composable
internal fun EffectsSection(
    state: AudioEffectsController.EffectsState,
    onEnabledChange: (Boolean) -> Unit,
    onBand: (Float, Short) -> Unit,
    onBass: (Float) -> Unit,
    onVirtualizer: (Float) -> Unit,
    onReset: () -> Unit,
) {
    SectionCard(
        title = stringResource(R.string.section_effects),
        subtitle = "Global output effects, applied by the platform DSP",
        icon = Icons.Rounded.GraphicEq,
        accent = PanelPalette.Violet,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (state.engineAvailable) "Engine ready" else stringResource(R.string.eq_not_available),
                    color = if (state.engineAvailable) PanelPalette.TextPrimary else PanelPalette.Warm,
                    fontSize = 13.sp,
                )
                Spacer(Modifier.width(8.dp))
                when {
                    !state.engineAvailable -> StatusPill(
                        text = stringResource(R.string.label_unavailable),
                        color = PanelPalette.Warm,
                    )

                    state.enabled -> StatusPill(text = "Active", color = PanelPalette.Success)
                    else -> StatusPill(text = stringResource(R.string.label_off), color = PanelPalette.TextTertiary)
                }
            }
            GlassSwitch(
                checked = state.enabled && state.engineAvailable,
                onCheckedChange = onEnabledChange,
                enabled = state.engineAvailable,
                accent = PanelPalette.Violet,
            )
        }

        if (state.statusMessage != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = state.statusMessage,
                color = PanelPalette.TextTertiary,
                fontSize = 11.sp,
                lineHeight = 14.sp,
            )
        }

        if (state.engineAvailable && state.bands.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text(
                text = "${state.bands.size} bands, ${Formatters.decibels(state.levelRangeDb.first)} .. " +
                    Formatters.decibels(state.levelRangeDb.second),
                color = PanelPalette.TextTertiary,
                fontSize = 11.sp,
            )
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth().height(148.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                state.bands.forEachIndexed { index, band ->
                    GlassVerticalSlider(
                        fraction = state.levelValues.getOrElse(index) { 0.5f },
                        onFractionChange = { onBand(it, band.index) },
                        onCommit = { onBand(it, band.index) },
                        label = Formatters.hertzFromMilliHz(band.centerHz),
                        accent = PanelPalette.Violet,
                        enabled = state.enabled,
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            GlassDivider()
            Spacer(Modifier.height(12.dp))

            GlassSlider(
                fraction = state.bassValue,
                onFractionChange = onBass,
                onCommit = onBass,
                label = stringResource(R.string.eq_bass_boost),
                accent = PanelPalette.Alarm,
                enabled = state.bassSupported && state.enabled,
            )

            Spacer(Modifier.height(6.dp))

            GlassSlider(
                fraction = state.virtualizerValue,
                onFractionChange = onVirtualizer,
                onCommit = onVirtualizer,
                label = stringResource(R.string.eq_virtualizer),
                accent = PanelPalette.Accent,
                leading = {
                    Box(Modifier.width(22.dp), contentAlignment = Alignment.Center) {
                        androidx.compose.material3.Icon(
                            imageVector = Icons.Rounded.SurroundSound,
                            contentDescription = null,
                            tint = PanelPalette.Accent,
                        )
                    }
                },
                enabled = state.virtualizerSupported && state.enabled,
            )

            Spacer(Modifier.height(14.dp))
            GlassButton(
                label = stringResource(R.string.eq_flat),
                icon = Icons.Rounded.RestartAlt,
                onClick = onReset,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
