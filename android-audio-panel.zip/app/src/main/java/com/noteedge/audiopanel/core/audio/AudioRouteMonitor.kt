package com.noteedge.audiopanel.core.audio

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Tracks the current output route so the panel can explain why a slider behaves the
 * way it does (for example: a Bluetooth sink with absolute volume manages levels itself).
 */
class AudioRouteMonitor(context: Context) {

    data class RouteInfo(
        val label: String,
        val type: Int,
        val isBluetooth: Boolean,
        val isWireless: Boolean,
        val isBuiltIn: Boolean,
    )

    private val audioManager = context.applicationContext
        .getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _route = MutableStateFlow<RouteInfo?>(null)
    val route: StateFlow<RouteInfo?> = _route.asStateFlow()

    private val callback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) = refresh()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) = refresh()
    }

    private var registered = false

    fun start() {
        if (registered) return
        registered = true
        runCatching {
            audioManager.registerAudioDeviceCallback(callback, Handler(Looper.getMainLooper()))
        }
        refresh()
    }

    fun stop() {
        if (!registered) return
        registered = false
        runCatching { audioManager.unregisterAudioDeviceCallback(callback) }
    }

    fun refresh() {
        _route.value = runCatching {
            val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            outputs.firstOrNull()?.let(::describe)
        }.getOrNull()
    }

    private fun describe(device: AudioDeviceInfo): RouteInfo {
        val type = device.type
        val label = device.productName?.toString()?.takeIf { it.isNotBlank() } ?: labelFor(type)
        val bluetooth = type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
            type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
            type == AudioDeviceInfo.TYPE_BLE_SPEAKER ||
            type == AudioDeviceInfo.TYPE_BLE_BROADCAST
        return RouteInfo(
            label = label,
            type = type,
            isBluetooth = bluetooth,
            isWireless = bluetooth || type == AudioDeviceInfo.TYPE_REMOTE_SUBMIX ||
                type == AudioDeviceInfo.TYPE_HDMI ||
                type == AudioDeviceInfo.TYPE_HDMI_ARC ||
                type == AudioDeviceInfo.TYPE_HDMI_EARC,
            isBuiltIn = type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER ||
                type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE,
        )
    }

    private fun labelFor(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Built-in speaker"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Earpiece"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Wired headphones"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired headset"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth audio"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth headset"
        AudioDeviceInfo.TYPE_BLE_HEADSET -> "Bluetooth LE headset"
        AudioDeviceInfo.TYPE_BLE_SPEAKER -> "Bluetooth LE speaker"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "USB headset"
        AudioDeviceInfo.TYPE_USB_DEVICE -> "USB audio"
        AudioDeviceInfo.TYPE_HDMI -> "HDMI"
        else -> "Output device"
    }
}
