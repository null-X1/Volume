package com.noteedge.audiopanel.core.model

import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Pure volume maths, kept free of Android types so it can be unit tested on the JVM.
 */
object VolumeMath {

    /** Index -> 0..1 fraction. Streams that start at 1 are re-based so 0% means "off". */
    fun fraction(index: Int, minIndex: Int, maxIndex: Int): Float {
        val span = (maxIndex - minIndex).coerceAtLeast(1)
        return ((index - minIndex).toFloat() / span).coerceIn(0f, 1f)
    }

    /** 0..1 fraction -> a valid stream index. */
    fun indexFor(fraction: Float, minIndex: Int, maxIndex: Int): Int {
        val span = (maxIndex - minIndex).coerceAtLeast(1)
        return (minIndex + (fraction.coerceIn(0f, 1f) * span).roundToInt()).coerceIn(minIndex, maxIndex)
    }

    /** Snaps a fraction onto an evenly spaced detent grid. */
    fun snap(fraction: Float, steps: Int): Float {
        if (steps <= 1) return fraction.coerceIn(0f, 1f)
        val scaled = fraction.coerceIn(0f, 1f) * (steps - 1)
        return (scaled.roundToInt().toFloat() / (steps - 1)).coerceIn(0f, 1f)
    }

    /** Detent index of a fraction, used to fire one haptic tick per step crossed. */
    fun detentIndex(fraction: Float, steps: Int): Int {
        if (steps <= 1) return 0
        return (fraction.coerceIn(0f, 1f) * (steps - 1)).roundToInt()
    }

    fun percent(fraction: Float): Int = (fraction.coerceIn(0f, 1f) * 100f).roundToInt()

    fun isAudible(fraction: Float, epsilon: Float = 0.005f): Boolean = fraction > epsilon

    fun approximatelyEqual(a: Float, b: Float, tolerance: Float = 0.004f): Boolean = abs(a - b) <= tolerance
}
