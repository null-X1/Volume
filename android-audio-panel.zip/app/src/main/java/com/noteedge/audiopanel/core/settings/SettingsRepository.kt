package com.noteedge.audiopanel.core.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.noteedge.audiopanel.core.model.GlassTuning
import com.noteedge.audiopanel.core.model.OverlaySettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

private val Context.audioPanelStore: DataStore<Preferences> by preferencesDataStore(name = "audio_panel")

/**
 * Persists everything the user dials in: glass appearance, feel, and panel placement.
 *
 * Writes are debounced because the appearance sliders fire continuously while the
 * finger is down - the in-memory [StateFlow] stays frame-accurate, while the disk only
 * sees the settled value. That keeps the app battery-neutral in daily use.
 */
class SettingsRepository(
    context: Context,
    private val scope: CoroutineScope,
) {

    private val appContext = context.applicationContext

    private val _tuning = MutableStateFlow(GlassTuning.Default)
    val tuning: StateFlow<GlassTuning> = _tuning.asStateFlow()

    private val _overlay = MutableStateFlow(OverlaySettings())
    val overlay: StateFlow<OverlaySettings> = _overlay.asStateFlow()

    private var persistJob: Job? = null

    init {
        scope.launch { hydrate() }
    }

    private suspend fun hydrate() {
        runCatching {
            val prefs = appContext.audioPanelStore.data.first()
            _tuning.value = prefs.toTuning().sanitized()
            _overlay.value = prefs.toOverlay()
        }
    }

    fun updateTuning(transform: (GlassTuning) -> GlassTuning) {
        _tuning.value = transform(_tuning.value).sanitized()
        schedulePersist()
    }

    fun updateOverlay(transform: (OverlaySettings) -> OverlaySettings) {
        _overlay.value = transform(_overlay.value)
        schedulePersist()
    }

    fun resetTuning() {
        _tuning.value = GlassTuning.Default
        schedulePersist()
    }

    private fun schedulePersist() {
        persistJob?.cancel()
        persistJob = scope.launch {
            delay(PERSIST_DEBOUNCE_MS)
            persist()
        }
    }

    private suspend fun persist() {
        val tuning = _tuning.value
        val overlay = _overlay.value
        runCatching {
            appContext.audioPanelStore.edit { prefs ->
                prefs[Keys.BLUR_ENABLED] = tuning.blurEnabled
                prefs[Keys.BLUR_RADIUS] = tuning.blurRadius
                prefs[Keys.OPACITY] = tuning.opacity
                prefs[Keys.TINT_HUE] = tuning.tintHue
                prefs[Keys.TINT_STRENGTH] = tuning.tintStrength
                prefs[Keys.SATURATION] = tuning.saturation
                prefs[Keys.CORNER] = tuning.cornerRadius
                prefs[Keys.DEPTH] = tuning.depth
                prefs[Keys.HIGHLIGHT] = tuning.highlight
                prefs[Keys.GRAIN] = tuning.grain
                prefs[Keys.SPRING_FEEL] = tuning.springFeel
                prefs[Keys.HAPTICS_ENABLED] = tuning.hapticsEnabled
                prefs[Keys.HAPTIC_STRENGTH] = tuning.hapticStrength
                prefs[Keys.HIGH_REFRESH] = tuning.highRefreshRate
                prefs[Keys.WINDOW_BLUR] = tuning.windowBlur
                prefs[Keys.SNAP_SIDE] = tuning.snapSide

                prefs[Keys.OVERLAY_ENABLED] = overlay.enabled
                prefs[Keys.OVERLAY_EXPANDED] = overlay.expanded
                prefs[Keys.OVERLAY_SCALE] = overlay.scale
                overlay.x?.let { prefs[Keys.OVERLAY_X] = it }
                overlay.y?.let { prefs[Keys.OVERLAY_Y] = it }
            }
        }
    }

    object Keys {
        val BLUR_ENABLED = booleanPreferencesKey("glass_blur_enabled")
        val BLUR_RADIUS = floatPreferencesKey("glass_blur_radius")
        val OPACITY = floatPreferencesKey("glass_opacity")
        val TINT_HUE = floatPreferencesKey("glass_tint_hue")
        val TINT_STRENGTH = floatPreferencesKey("glass_tint_strength")
        val SATURATION = floatPreferencesKey("glass_saturation")
        val CORNER = floatPreferencesKey("glass_corner")
        val DEPTH = floatPreferencesKey("glass_depth")
        val HIGHLIGHT = floatPreferencesKey("glass_highlight")
        val GRAIN = floatPreferencesKey("glass_grain")
        val SPRING_FEEL = floatPreferencesKey("feel_spring")
        val HAPTICS_ENABLED = booleanPreferencesKey("feel_haptics_enabled")
        val HAPTIC_STRENGTH = floatPreferencesKey("feel_haptics_strength")
        val HIGH_REFRESH = booleanPreferencesKey("display_high_refresh")
        val WINDOW_BLUR = booleanPreferencesKey("overlay_window_blur")
        val SNAP_SIDE = intPreferencesKey("overlay_snap_side")

        val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
        val OVERLAY_EXPANDED = booleanPreferencesKey("overlay_expanded")
        val OVERLAY_SCALE = floatPreferencesKey("overlay_scale")
        val OVERLAY_X = intPreferencesKey("overlay_x")
        val OVERLAY_Y = intPreferencesKey("overlay_y")
    }

    private companion object {
        const val PERSIST_DEBOUNCE_MS = 240L
    }
}

internal fun Preferences.toTuning(): GlassTuning = GlassTuning(
    blurEnabled = this[SettingsRepository.Keys.BLUR_ENABLED] ?: GlassTuning.Default.blurEnabled,
    blurRadius = this[SettingsRepository.Keys.BLUR_RADIUS] ?: GlassTuning.Default.blurRadius,
    opacity = this[SettingsRepository.Keys.OPACITY] ?: GlassTuning.Default.opacity,
    tintHue = this[SettingsRepository.Keys.TINT_HUE] ?: GlassTuning.Default.tintHue,
    tintStrength = this[SettingsRepository.Keys.TINT_STRENGTH] ?: GlassTuning.Default.tintStrength,
    saturation = this[SettingsRepository.Keys.SATURATION] ?: GlassTuning.Default.saturation,
    cornerRadius = this[SettingsRepository.Keys.CORNER] ?: GlassTuning.Default.cornerRadius,
    depth = this[SettingsRepository.Keys.DEPTH] ?: GlassTuning.Default.depth,
    highlight = this[SettingsRepository.Keys.HIGHLIGHT] ?: GlassTuning.Default.highlight,
    grain = this[SettingsRepository.Keys.GRAIN] ?: GlassTuning.Default.grain,
    springFeel = this[SettingsRepository.Keys.SPRING_FEEL] ?: GlassTuning.Default.springFeel,
    hapticsEnabled = this[SettingsRepository.Keys.HAPTICS_ENABLED] ?: GlassTuning.Default.hapticsEnabled,
    hapticStrength = this[SettingsRepository.Keys.HAPTIC_STRENGTH] ?: GlassTuning.Default.hapticStrength,
    highRefreshRate = this[SettingsRepository.Keys.HIGH_REFRESH] ?: GlassTuning.Default.highRefreshRate,
    windowBlur = this[SettingsRepository.Keys.WINDOW_BLUR] ?: GlassTuning.Default.windowBlur,
    snapSide = this[SettingsRepository.Keys.SNAP_SIDE] ?: GlassTuning.Default.snapSide,
)

internal fun Preferences.toOverlay(): OverlaySettings = OverlaySettings(
    enabled = this[SettingsRepository.Keys.OVERLAY_ENABLED] ?: false,
    expanded = this[SettingsRepository.Keys.OVERLAY_EXPANDED] ?: false,
    scale = this[SettingsRepository.Keys.OVERLAY_SCALE] ?: 1f,
    x = this[SettingsRepository.Keys.OVERLAY_X],
    y = this[SettingsRepository.Keys.OVERLAY_Y],
)

/** Sanitises user input so a stored value can never break rendering. */
internal fun GlassTuning.sanitized(): GlassTuning = copy(
    blurRadius = blurRadius.coerceIn(GlassTuning.MIN_BLUR, GlassTuning.MAX_BLUR),
    opacity = opacity.coerceIn(GlassTuning.MIN_OPACITY, GlassTuning.MAX_OPACITY),
    tintHue = tintHue.coerceIn(0f, 1f),
    tintStrength = tintStrength.coerceIn(0f, 1f),
    saturation = saturation.coerceIn(0f, 1.4f),
    cornerRadius = cornerRadius.coerceIn(GlassTuning.MIN_CORNER, GlassTuning.MAX_CORNER),
    depth = depth.coerceIn(GlassTuning.MIN_DEPTH, GlassTuning.MAX_DEPTH),
    highlight = highlight.coerceIn(0f, 1f),
    grain = grain.coerceIn(0f, 0.12f),
    springFeel = springFeel.coerceIn(0f, 1f),
    hapticStrength = hapticStrength.coerceIn(0f, 1f),
    snapSide = if (snapSide < 0) -1 else 1,
)
