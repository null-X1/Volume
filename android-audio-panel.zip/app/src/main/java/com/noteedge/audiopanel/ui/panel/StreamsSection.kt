package com.noteedge.audiopanel.ui.panel

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noteedge.audiopanel.R
import com.noteedge.audiopanel.core.model.AudioStreamKind
import com.noteedge.audiopanel.core.model.StreamVolume
import com.noteedge.audiopanel.ui.components.GlassDivider
import com.noteedge.audiopanel.ui.components.SectionCard
import com.noteedge.audiopanel.ui.glass.GlassButton
import com.noteedge.audiopanel.ui.glass.GlassIconButton
import com.noteedge.audiopanel.ui.glass.GlassSlider
import com.noteedge.audiopanel.ui.theme.PanelPalette

/**
 * One slider per AudioManager stream. The leading glyph doubles as the mute toggle,
 * which keeps the row compact while still being a 28 dp target.
 */
@Composable
internal fun StreamsSection(
    streams: Map<AudioStreamKind, StreamVolume>,
    onDrag: (AudioStreamKind, Float) -> Unit,
    onCommit: (AudioStreamKind, Float) -> Unit,
    onToggleMute: (AudioStreamKind) -> Unit,
    onMuteAll: () -> Unit,
    onRestoreAll: () -> Unit,
) {
    SectionCard(
        title = stringResource(R.string.section_streams),
        subtitle = "Every stream the audio framework exposes, live",
        icon = Icons.Rounded.Tune,
    ) {
        AudioStreamKind.displayOrder.forEachIndexed { index, kind ->
            val volume = streams[kind] ?: return@forEachIndexed
            if (index > 0) Spacer(Modifier.height(6.dp))
            val accent = kind.accentColor()
            GlassSlider(
                fraction = volume.fraction,
                onFractionChange = { onDrag(kind, it) },
                onCommit = { onCommit(kind, it) },
                accent = accent,
                label = stringResource(kind.labelRes),
                leading = {
                    GlassIconButton(
                        onClick = { onToggleMute(kind) },
                        accent = accent,
                        buttonSize = 28.dp,
                    ) {
                        Icon(
                            imageVector = if (volume.isMuted) Icons.AutoMirrored.Rounded.VolumeOff else kind.glyph(),
                            contentDescription = stringResource(R.string.action_mute_all),
                            tint = if (volume.isMuted) PanelPalette.Danger else accent,
                            modifier = Modifier.size(15.dp),
                        )
                    }
                },
            )
        }

        Spacer(Modifier.height(14.dp))
        GlassDivider()
        Spacer(Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlassButton(
                label = stringResource(R.string.action_mute_all),
                icon = Icons.AutoMirrored.Rounded.VolumeOff,
                onClick = onMuteAll,
                modifier = Modifier.weight(1f),
            )
            GlassButton(
                label = stringResource(R.string.action_unmute_all),
                icon = Icons.Rounded.RestartAlt,
                onClick = onRestoreAll,
                modifier = Modifier.weight(1f),
            )
        }

        Spacer(Modifier.height(10.dp))
        Text(
            text = "Alarm is excluded from mute-all so you never lose a wake-up.",
            color = PanelPalette.TextTertiary,
            fontSize = 11.sp,
            lineHeight = 14.sp,
        )
    }
}
