package com.noteedge.audiopanel.ui.interaction

import kotlin.math.abs

/**
 * Pure spring / inertia maths.
 *
 * The whole interaction model of this app comes from here: a single "feel" value
 * (0 = calm and damped, 1 = light and springy) is mapped onto stiffness and damping,
 * and release velocity is converted into a small inertial travel so a fast flick
 * throws the control a fraction further before it settles.
 *
 * Kept free of Compose and Android types so it can be unit tested on the JVM.
 */
object SpringMath {

    const val MIN_STIFFNESS = 280f
    const val MAX_STIFFNESS = 1150f
    const val CALM_DAMPING = 0.98f
    const val LIVELY_DAMPING = 0.52f

    /** Spring constant used while a control is settling back. */
    fun settleStiffness(feel: Float): Float = lerp(MIN_STIFFNESS, MAX_STIFFNESS, clamp01(feel))

    /** Damping ratio while a control is settling back. */
    fun settleDamping(feel: Float): Float = lerp(CALM_DAMPING, LIVELY_DAMPING, clamp01(feel))

    /** Compression springs are always a touch tighter so presses feel immediate. */
    fun pressStiffness(feel: Float): Float = lerp(700f, 1400f, clamp01(feel))

    fun pressDamping(feel: Float): Float = lerp(0.92f, 0.68f, clamp01(feel))

    /** Quick flick used for the inertial overshoot after a fast swipe. */
    fun flingStiffness(feel: Float): Float = lerp(900f, 1800f, clamp01(feel))

    fun flingDamping(feel: Float): Float = lerp(0.80f, 0.50f, clamp01(feel))

    /**
     * How far a released control travels past its resting point, expressed as a
     * fraction of its track (positive = further in the direction of travel).
     */
    fun inertiaFraction(
        velocityPxPerSecond: Float,
        trackWidthPx: Float,
        maxTravel: Float = 0.07f,
    ): Float {
        if (trackWidthPx <= 1f) return 0f
        val normalized = velocityPxPerSecond / trackWidthPx      // screens per second
        val raw = normalized * 0.035f
        return raw.coerceIn(-maxTravel, maxTravel)
    }

    /** Duration used for micro decays after repeated taps. */
    fun microDecayMillis(streak: Int): Int = (180 + streak * 12).coerceAtMost(320)

    /**
     * Cumulative micro-motion applied by repeated taps: each extra tap in a quick
     * streak adds a little more travel, capped so it never becomes a wobble.
     */
    fun microTravelForTapStreak(streak: Int, perTap: Float = 0.014f, cap: Float = 0.06f): Float =
        (streak.coerceAtLeast(0) * perTap).coerceAtMost(cap)

    /** Extra haptic energy for repeated taps, so the third tap feels different from the first. */
    fun tapBoostForStreak(streak: Int): Float = (streak.coerceIn(0, 5) * 0.09f)

    fun clamp01(value: Float): Float = if (value < 0f) 0f else if (value > 1f) 1f else value

    fun lerp(start: Float, stop: Float, fraction: Float): Float = start + (stop - start) * fraction

    private fun abs(value: Float): Float = if (value < 0f) -value else value
}
