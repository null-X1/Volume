package com.noteedge.audiopanel.ui.glass

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noteedge.audiopanel.ui.interaction.SpringMath
import com.noteedge.audiopanel.ui.interaction.rememberPhysicalFeedback
import com.noteedge.audiopanel.ui.theme.PanelPalette
import kotlin.math.abs
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Vertical fader used by the equalizer.
 *
 * Same physical vocabulary as [GlassSlider], rotated: the cap tracks the finger, a long
 * press drops into fine tuning, and letting go lets the spring carry the cap to rest.
 */
@Composable
fun GlassVerticalSlider(
    fraction: Float,
    onFractionChange: (Float) -> Unit,
    onCommit: (Float) -> Unit = {},
    modifier: Modifier = Modifier,
    accent: Color = PanelPalette.Accent,
    label: String? = null,
    enabled: Boolean = true,
) {
    val tuning = LocalGlassTuning.current
    val physical = rememberPhysicalFeedback()
    val scope = rememberCoroutineScope()
    val currentOnChange by rememberUpdatedState(onFractionChange)
    val currentOnCommit by rememberUpdatedState(onCommit)

    var live by remember { mutableFloatStateOf(fraction.coerceIn(0f, 1f)) }
    var dragging by remember { mutableStateOf(false) }
    var settleJob by remember { mutableStateOf<Job?>(null) }

    LaunchedEffect(fraction, dragging) {
        if (!dragging) {
            val target = fraction.coerceIn(0f, 1f)
            if (abs(live - target) > 0.002f) {
                settleJob?.cancel()
                animate(
                    initialValue = live,
                    targetValue = target,
                    animationSpec = spring(
                        stiffness = SpringMath.settleStiffness(tuning.springFeel),
                        dampingRatio = SpringMath.settleDamping(tuning.springFeel),
                    ),
                ) { animated, _ -> live = animated }
            }
        }
    }

    Box(modifier = modifier.width(34.dp).fillMaxHeight(), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(34.dp)
                .graphicsLayer {
                    scaleX = physical.scale
                    scaleY = physical.scale
                }
                .pointerInput(enabled, tuning.springFeel) {
                    if (!enabled) return@pointerInput
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val trackHeight = size.height.toFloat().coerceAtLeast(1f)
                        settleJob?.cancel()
                        dragging = true
                        physical.onDown(down.uptimeMillis)

                        val tracker = VelocityTracker()
                        tracker.addPosition(down.uptimeMillis, down.position)

                        var lastY = down.position.y
                        var lastTime = down.uptimeMillis
                        var holding = false
                        var holdBase = live
                        var holdBaseY = down.position.y

                        fun fractionFor(y: Float): Float = (1f - (y / trackHeight)).coerceIn(0f, 1f)

                        live = fractionFor(down.position.y)
                        currentOnChange(live)

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break

                            if (!holding && change.uptimeMillis - down.uptimeMillis >= 420L &&
                                abs(change.position.y - down.position.y) < trackHeight * 0.05f
                            ) {
                                holding = true
                                holdBase = live
                                holdBaseY = change.position.y
                                physical.onLongPress()
                            }

                            if (change.positionChanged()) {
                                tracker.addPosition(change.uptimeMillis, change.position)
                                val dy = change.position.y - lastY
                                val dtMillis = (change.uptimeMillis - lastTime).coerceAtLeast(1L)
                                physical.onMove(dy / (dtMillis / 1000f), trackHeight)

                                val target = if (holding) {
                                    (holdBase - (change.position.y - holdBaseY) / trackHeight * 0.35f)
                                        .coerceIn(0f, 1f)
                                } else {
                                    fractionFor(change.position.y)
                                }
                                live = target
                                currentOnChange(target)

                                change.consume()
                                lastY = change.position.y
                                lastTime = change.uptimeMillis
                            }

                            if (change.changedToUpIgnoreConsumed()) {
                                val velocity = -tracker.calculateVelocity().y
                                dragging = false
                                if (holding) physical.onLongPressEnd()
                                physical.onRelease(velocity, trackHeight, wasTap = false)
                                settleJob = scope.launch {
                                    val resting = live
                                    animate(
                                        initialValue = resting,
                                        targetValue = resting,
                                        initialVelocity = velocity / trackHeight,
                                        animationSpec = spring(
                                            stiffness = SpringMath.settleStiffness(tuning.springFeel),
                                            dampingRatio = SpringMath.settleDamping(tuning.springFeel),
                                        ),
                                    ) { animated, _ -> live = animated }
                                    currentOnCommit(live)
                                }
                                break
                            }
                        }
                        dragging = false
                    }
                }
                .drawWithCache {
                    val railWidth = 8.dp.toPx()
                    val capHeight = 12.dp.toPx()
                    val hairline = 1.dp.toPx()
                    val railCorner = CornerRadius(railWidth / 2f, railWidth / 2f)
                    val capCorner = CornerRadius(capHeight / 2f, capHeight / 2f)
                    val railBrush = Brush.verticalGradient(
                        colors = listOf(Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.12f)),
                    )
                    val fillBrush = Brush.verticalGradient(
                        colors = listOf(accent, accent.copy(alpha = 0.55f)),
                    )
                    val capBrush = Brush.verticalGradient(
                        colors = listOf(Color.White, Color.White.copy(alpha = 0.80f)),
                    )

                    onDrawBehind {
                        val level = live.coerceIn(0f, 1f)
                        val railLeft = (size.width - railWidth) / 2f
                        val fillHeight = size.height * level

                        drawRoundRect(
                            brush = railBrush,
                            topLeft = Offset(railLeft, 0f),
                            size = Size(railWidth, size.height),
                            cornerRadius = railCorner,
                        )

                        if (fillHeight > 1f) {
                            drawRoundRect(
                                brush = fillBrush,
                                topLeft = Offset(railLeft, size.height - fillHeight),
                                size = Size(railWidth, fillHeight),
                                cornerRadius = railCorner,
                                alpha = 0.92f,
                            )
                        }

                        // cap
                        val capY = (size.height - fillHeight) - capHeight / 2f + physical.micro * size.height
                        val capCenter = Offset(size.width / 2f, capY + capHeight / 2f)
                        val radius = capHeight * (0.85f + 0.25f * physical.press)
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.30f),
                            radius = radius,
                            center = Offset(capCenter.x, capCenter.y + 1.5.dp.toPx()),
                        )
                        drawCircle(brush = capBrush, radius = radius, center = capCenter)
                        drawCircle(
                            color = accent.copy(alpha = 0.55f + 0.4f * physical.glow),
                            radius = radius * 0.55f,
                            center = capCenter,
                        )
                        drawCircle(
                            color = Color.White.copy(alpha = 0.8f),
                            radius = radius,
                            center = capCenter,
                            style = Stroke(hairline),
                        )
                    }
                },
        )

        if (label != null) {
            Text(
                text = label,
                color = PanelPalette.TextTertiary,
                fontSize = 10.sp,
                maxLines = 1,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 2.dp),
            )
        }
    }
}
