package com.noteedge.audiopanel.di

import android.content.Context
import com.noteedge.audiopanel.core.audio.AudioEffectsController
import com.noteedge.audiopanel.core.audio.AudioRouteMonitor
import com.noteedge.audiopanel.core.audio.AudioSystem
import com.noteedge.audiopanel.core.audio.VolumeRepository
import com.noteedge.audiopanel.core.settings.SettingsRepository
import com.noteedge.audiopanel.core.system.DeviceProfileProvider
import com.noteedge.audiopanel.core.system.Haptics
import com.noteedge.audiopanel.core.system.PermissionGateway
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Hand-rolled dependency container.
 *
 * The app is small enough that a DI framework would only add build time and reflection
 * surface; a single container created by the [android.app.Application] keeps the
 * graph explicit and testable, and gives services a single place to look up their
 * collaborators.
 */
class AppContainer(context: Context) {

    private val appContext = context.applicationContext

    val applicationScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val audioSystem: AudioSystem = AudioSystem(appContext)
    val volumeRepository: VolumeRepository = VolumeRepository(audioSystem, applicationScope)
    val effects: AudioEffectsController = AudioEffectsController(appContext, applicationScope)
    val routeMonitor: AudioRouteMonitor = AudioRouteMonitor(appContext)
    val settings: SettingsRepository = SettingsRepository(appContext, applicationScope)
    val haptics: Haptics = Haptics(appContext)
    val deviceProfile: DeviceProfileProvider = DeviceProfileProvider(appContext)
    val permissions: PermissionGateway = PermissionGateway(appContext)

    fun startAmbientServices() {
        volumeRepository.start(appContext.contentResolver)
        routeMonitor.start()
    }

    fun stopAmbientServices() {
        routeMonitor.stop()
        volumeRepository.stop(appContext.contentResolver)
    }
}
