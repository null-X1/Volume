package com.noteedge.audiopanel.core.model

/**
 * Every knob that shapes how the glass panel looks and feels.
 *
 * The defaults are tuned for the Infinix NOTE Edge panel: a deep, soft, iPhone-grade
 * translucency with a matte-blue tint that reads well over XOS 16 wallpapers and
 * over the transparent XOS notification shade.
 */
data class GlassTuning(
    val blurEnabled: Boolean = true,
    /** Backdrop blur radius in dp. */
    val blurRadius: Float = 26f,
    /** Fill alpha of the glass slab (0.10 .. 0.80). */
    val opacity: Float = 0.42f,
    /** Hue of the tint, 0f..1f. */
    val tintHue: Float = 0.56f,
    /** How strongly the tint pushes the panel's color (0..1). */
    val tintStrength: Float = 0.30f,
    val saturation: Float = 0.62f,
    /** Corner radius in dp. */
    val cornerRadius: Float = 30f,
    /** Shadow depth in dp. */
    val depth: Float = 20f,
    /** Strength of the rim light along the top edge (0..1). */
    val highlight: Float = 0.60f,
    /** Amount of procedural grain applied to the slab (0..0.12). */
    val grain: Float = 0.05f,
    /** 0 = overdamped and calm, 1 = springy and lively. */
    val springFeel: Float = 0.58f,
    val hapticsEnabled: Boolean = true,
    val hapticStrength: Float = 0.75f,
    /** Ask the display for its highest refresh rate (120 Hz on the NOTE Edge). */
    val highRefreshRate: Boolean = true,
    /** Real system-level blur for the floating window (Android 12+ only). */
    val windowBlur: Boolean = true,
    /** Preferred corner for the floating panel: -1 left, +1 right. */
    val snapSide: Int = 1,
) {
    companion object {
        val Default = GlassTuning()

        /** Smallest / largest settings that still look sane. */
        const val MIN_BLUR = 0f
        const val MAX_BLUR = 60f
        const val MIN_OPACITY = 0.10f
        const val MAX_OPACITY = 0.85f
        const val MIN_CORNER = 8f
        const val MAX_CORNER = 48f
        const val MIN_DEPTH = 0f
        const val MAX_DEPTH = 40f
    }
}
