package com.noteedge.audiopanel.core.model

/** Immutable snapshot of one stream's volume state. */
data class StreamVolume(
    val kind: AudioStreamKind,
    val index: Int,
    val minIndex: Int,
    val maxIndex: Int,
) {
    val fraction: Float get() = VolumeMath.fraction(index, minIndex, maxIndex)

    val percent: Int get() = VolumeMath.percent(fraction)

    val isMuted: Boolean get() = index <= minIndex

    val isAtMax: Boolean get() = index >= maxIndex
}
