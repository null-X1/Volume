package com.noteedge.audiopanel.ui.glass

import android.graphics.Bitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.util.Random

/**
 * A single procedurally generated grain tile, created once and reused by every glass
 * surface and by the ambient backdrop.
 *
 * Real glass scatters a little light; without this the panel reads as flat plastic.
 * The tile is deterministic (fixed seed) so it never shimmers between launches.
 */
internal object NoiseTexture {

    private const val SIZE = 96
    private var cached: ImageBitmap? = null

    fun image(): ImageBitmap {
        cached?.let { return it }
        val random = Random(0x5EED_1CE5L)
        val pixels = IntArray(SIZE * SIZE)
        for (index in pixels.indices) {
            val value = 150 + random.nextInt(105)          // 150..254 grey
            val alpha = 18 + random.nextInt(26)            // subtle by construction
            pixels[index] = (alpha shl 24) or (value shl 16) or (value shl 8) or value
        }
        val bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        bitmap.setPixels(pixels, 0, SIZE, 0, 0, SIZE, SIZE)
        return bitmap.asImageBitmap().also { cached = it }
    }
}
