package com.noteedge.audiopanel.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.noteedge.audiopanel.MainActivity
import com.noteedge.audiopanel.R
import com.noteedge.audiopanel.core.model.AudioStreamKind
import com.noteedge.audiopanel.di.AppContainer
import com.noteedge.audiopanel.ui.panel.CompactPanel
import com.noteedge.audiopanel.ui.panel.GlassPanelRoot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Hosts the floating glass panel.
 *
 * Lifecycle notes for XOS 16:
 *  - The user starts it explicitly (never a boot receiver, never a background start), which
 *    is what both Android 16 and XOS expect for a `specialUse` foreground service.
 *  - `stopWithTask=false` keeps the panel alive while the user swipes the activity away,
 *    and the ongoing notification is the visible, cancellable handle for stopping it.
 *  - If the overlay permission is missing the service shuts itself down instead of
 *    spinning, so the app can never leak a foreground service the user cannot see.
 */
class OverlayPanelService : Service() {

    private val container: AppContainer by lazy { (application as com.noteedge.audiopanel.AudioPanelApplication).container }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var windowController: OverlayWindowController? = null
    private var tuningJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForegroundSafely()
        windowController = OverlayWindowController(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_TOGGLE_EXPANDED -> {
                container.settings.updateOverlay { it.copy(expanded = !it.expanded) }
                return START_STICKY
            }
        }

        if (!container.permissions.canDrawOverlays()) {
            OverlayState.setRunning(false)
            stopSelf()
            return START_NOT_STICKY
        }

        showPanel()
        return START_STICKY
    }

    override fun onDestroy() {
        tuningJob?.cancel()
        scope.cancel()
        windowController?.hide()
        windowController = null
        OverlayState.setRunning(false)
        super.onDestroy()
    }

    // ---- panel -------------------------------------------------------------

    private fun showPanel() {
        val controller = windowController ?: return
        if (controller.isShowing) {
            OverlayState.setRunning(true)
            return
        }

        val overlaySettings = container.settings.overlay.value
        val shown = controller.show(
            stored = overlaySettings,
            tuning = container.settings.tuning.value,
        ) {
            val tuning by container.settings.tuning.collectAsState()
            val streams by container.volumeRepository.streams.collectAsState()
            val overlay by container.settings.overlay.collectAsState()
            val route by container.routeMonitor.route.collectAsState()

            GlassPanelRoot(
                tuning = tuning,
                haptics = container.haptics,
                scenic = false,
            ) {
                CompactPanel(
                    streams = streams,
                    expanded = overlay.expanded,
                    routeLabel = route?.label,
                    onExpandedChange = { expanded ->
                        container.settings.updateOverlay { it.copy(expanded = expanded) }
                        container.haptics.play(com.noteedge.audiopanel.core.system.Haptics.Feel.Tick)
                    },
                    onVolumeChange = { kind, fraction -> container.volumeRepository.setFraction(kind, fraction) },
                    onVolumeCommit = { kind, fraction ->
                        container.volumeRepository.commit(kind, fraction)
                        container.haptics.play(com.noteedge.audiopanel.core.system.Haptics.Feel.Tick)
                    },
                    onToggleMute = { kind ->
                        container.volumeRepository.toggleMute(kind)
                        container.haptics.play(com.noteedge.audiopanel.core.system.Haptics.Feel.Soft)
                    },
                    onMuteAll = {
                        container.volumeRepository.muteAll()
                        container.haptics.play(com.noteedge.audiopanel.core.system.Haptics.Feel.Firm)
                    },
                    onDrag = { deltaX, deltaY -> controller.moveBy(deltaX, deltaY) },
                    onDragEnd = {
                        val (x, y) = controller.position
                        container.settings.updateOverlay { it.copy(x = x, y = y) }
                    },
                    onOpenPanel = { openActivity() },
                    onClose = { stopSelf() },
                )
            }
        }

        OverlayState.setRunning(shown)
        if (!shown) {
            stopSelf()
            return
        }

        tuningJob = scope.launch {
            container.settings.tuning.collect { tuning -> controller.applyTuning(tuning) }
        }
    }

    private fun openActivity() {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        runCatching { startActivity(intent) }
    }

    // ---- foreground notification ------------------------------------------

    private fun startForegroundSafely() {
        val notification = buildNotification()
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        runCatching { ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type) }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            REQUEST_OPEN,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stopIntent = PendingIntent.getService(
            this,
            REQUEST_STOP,
            Intent(this, OverlayPanelService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_panel)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setSilent(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, getString(R.string.notif_action_stop), stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = getString(R.string.notif_channel_desc)
            setShowBadge(false)
            enableVibration(false)
            enableLights(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        manager.createNotificationChannel(channel)
    }

    companion object {
        const val ACTION_STOP = "com.noteedge.audiopanel.action.STOP"
        const val ACTION_TOGGLE_EXPANDED = "com.noteedge.audiopanel.action.EXPAND"

        private const val CHANNEL_ID = "audio_panel_overlay"
        private const val NOTIFICATION_ID = 4242
        private const val REQUEST_OPEN = 10
        private const val REQUEST_STOP = 11

        /** Intent that starts (or restarts) the floating panel. */
        fun startIntent(context: Context): Intent =
            Intent(context, OverlayPanelService::class.java).setAction(ACTION_START)

        const val ACTION_START = "com.noteedge.audiopanel.action.START"
    }
}
