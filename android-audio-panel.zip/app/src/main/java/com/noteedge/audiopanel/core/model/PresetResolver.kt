package com.noteedge.audiopanel.core.model

import android.media.AudioManager

/**
 * Maps a [AudioPreset] onto concrete per-stream fractions and, when it makes sense,
 * a ringer mode. Pure logic - unit tested on the JVM.
 */
object PresetResolver {

    data class Mix(
        val targets: Map<AudioStreamKind, Float>,
        val ringerMode: Int? = null,
    )

    fun mixOf(preset: AudioPreset): Mix = when (preset) {
        AudioPreset.BALANCED -> Mix(
            targets = mapOf(
                AudioStreamKind.MEDIA to 0.60f,
                AudioStreamKind.RING to 0.70f,
                AudioStreamKind.NOTIFICATION to 0.70f,
                AudioStreamKind.ALARM to 0.85f,
                AudioStreamKind.CALL to 0.70f,
                AudioStreamKind.SYSTEM to 0.50f,
            ),
            ringerMode = AudioManager.RINGER_MODE_NORMAL,
        )

        AudioPreset.LOUD -> Mix(
            targets = mapOf(
                AudioStreamKind.MEDIA to 0.95f,
                AudioStreamKind.RING to 1.00f,
                AudioStreamKind.NOTIFICATION to 1.00f,
                AudioStreamKind.ALARM to 1.00f,
                AudioStreamKind.CALL to 1.00f,
                AudioStreamKind.SYSTEM to 0.80f,
            ),
            ringerMode = AudioManager.RINGER_MODE_NORMAL,
        )

        AudioPreset.FOCUS -> Mix(
            targets = mapOf(
                AudioStreamKind.MEDIA to 0.45f,
                AudioStreamKind.RING to 0.35f,
                AudioStreamKind.NOTIFICATION to 0.25f,
                AudioStreamKind.ALARM to 0.75f,
                AudioStreamKind.CALL to 0.65f,
                AudioStreamKind.SYSTEM to 0.30f,
            ),
            ringerMode = AudioManager.RINGER_MODE_NORMAL,
        )

        AudioPreset.SILENT -> Mix(
            targets = mapOf(
                AudioStreamKind.MEDIA to 0.35f,
                AudioStreamKind.RING to 0.00f,
                AudioStreamKind.NOTIFICATION to 0.00f,
                AudioStreamKind.ALARM to 0.65f,
                AudioStreamKind.CALL to 0.70f,
                AudioStreamKind.SYSTEM to 0.15f,
            ),
            ringerMode = AudioManager.RINGER_MODE_VIBRATE,
        )

        AudioPreset.NIGHT -> Mix(
            targets = mapOf(
                AudioStreamKind.MEDIA to 0.18f,
                AudioStreamKind.RING to 0.30f,
                AudioStreamKind.NOTIFICATION to 0.15f,
                AudioStreamKind.ALARM to 0.90f,
                AudioStreamKind.CALL to 0.60f,
                AudioStreamKind.SYSTEM to 0.10f,
            ),
            ringerMode = AudioManager.RINGER_MODE_NORMAL,
        )
    }

    /**
     * Which preset the current mix most closely matches, or null when the user has
     * drifted away from every preset. Pure logic, unit tested.
     */
    fun match(
        current: Map<AudioStreamKind, Float>,
        tolerance: Float = 0.06f,
    ): AudioPreset? {
        if (current.isEmpty()) return null
        var best: AudioPreset? = null
        var bestDistance = Float.MAX_VALUE
        AudioPreset.entries.forEach { preset ->
            val targets = mixOf(preset).targets
            var total = 0f
            var counted = 0
            targets.forEach { (kind, target) ->
                val value = current[kind] ?: return@forEach
                total += kotlin.math.abs(value - target)
                counted++
            }
            if (counted == 0) return@forEach
            val average = total / counted
            if (average <= tolerance && average < bestDistance) {
                bestDistance = average
                best = preset
            }
        }
        return best
    }
}
