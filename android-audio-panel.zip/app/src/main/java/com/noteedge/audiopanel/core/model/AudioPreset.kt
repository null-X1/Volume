package com.noteedge.audiopanel.core.model

import androidx.annotation.StringRes
import com.noteedge.audiopanel.R

/** Ready-made mixes the user can apply with one tap. */
enum class AudioPreset(@StringRes val labelRes: Int) {
    BALANCED(R.string.preset_balanced),
    LOUD(R.string.preset_loud),
    FOCUS(R.string.preset_focus),
    SILENT(R.string.preset_silent),
    NIGHT(R.string.preset_night),
}
