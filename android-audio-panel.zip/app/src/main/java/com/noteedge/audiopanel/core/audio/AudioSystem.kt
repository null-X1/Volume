package com.noteedge.audiopanel.core.audio

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.util.Log
import com.noteedge.audiopanel.core.model.AudioStreamKind
import com.noteedge.audiopanel.core.model.StreamVolume
import com.noteedge.audiopanel.core.model.VolumeMath

/**
 * Thin, defensive wrapper around [AudioManager].
 *
 * Every call is guarded: XOS can refuse a volume change while a call is in progress
 * or when a policy owner holds the stream, and a crash there would be unacceptable
 * for an always-on control panel.
 */
class AudioSystem(context: Context) {

    private val audioManager: AudioManager =
        context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun snapshot(kind: AudioStreamKind): StreamVolume? {
        val stream = kind.streamType
        return try {
            val max = audioManager.getStreamMaxVolume(stream)
            val min = minIndexOf(stream, max)
            val current = audioManager.getStreamVolume(stream)
            StreamVolume(kind, current.coerceIn(min, max), min, max)
        } catch (t: Throwable) {
            Log.w(TAG, "Unable to read ${kind.name}", t)
            null
        }
    }

    fun snapshotAll(kinds: List<AudioStreamKind>): Map<AudioStreamKind, StreamVolume> =
        kinds.mapNotNull { kind -> snapshot(kind)?.let { kind to it } }.toMap()

    /** Sets a stream from a 0..1 fraction. Returns true when the platform accepted it. */
    fun setFraction(kind: AudioStreamKind, fraction: Float, showSystemUi: Boolean = false): Boolean {
        val stream = kind.streamType
        return try {
            val max = audioManager.getStreamMaxVolume(stream)
            val min = minIndexOf(stream, max)
            val target = VolumeMath.indexFor(fraction, min, max)
            val flags = if (showSystemUi) AudioManager.FLAG_SHOW_UI else 0
            audioManager.setStreamVolume(stream, target, flags)
            true
        } catch (t: Throwable) {
            Log.w(TAG, "Unable to set ${kind.name} to $fraction", t)
            false
        }
    }

    /** Steps a stream by whole index units; used by the hardware-style flicks. */
    fun nudge(kind: AudioStreamKind, delta: Int): Boolean {
        if (delta == 0) return true
        val stream = kind.streamType
        val direction = if (delta > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        return try {
            repeat(kotlin.math.abs(delta)) {
                audioManager.adjustStreamVolume(stream, direction, 0)
            }
            true
        } catch (t: Throwable) {
            Log.w(TAG, "Unable to nudge ${kind.name}", t)
            false
        }
    }

    fun ringerMode(): Int = try {
        audioManager.ringerMode
    } catch (t: Throwable) {
        AudioManager.RINGER_MODE_NORMAL
    }

    /** Returns true when the platform actually changed the ringer mode. */
    fun setRingerMode(mode: Int): Boolean = try {
        audioManager.ringerMode = mode
        audioManager.ringerMode == mode
    } catch (t: Throwable) {
        Log.w(TAG, "Unable to set ringer mode", t)
        false
    }

    fun isMusicActive(): Boolean = try {
        audioManager.isMusicActive
    } catch (t: Throwable) {
        false
    }

    fun sessionId(): Int = try {
        audioManager.generateAudioSessionId()
    } catch (t: Throwable) {
        AudioManager.AUDIO_SESSION_ID_GENERATE
    }

    val manager: AudioManager get() = audioManager

    private fun minIndexOf(stream: Int, max: Int): Int {
        // getStreamMinVolume arrived in API 28; everything is re-based to 0 below that
        // so the UI always has an honest "off" position.
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                audioManager.getStreamMinVolume(stream).coerceAtMost(max)
            } catch (t: Throwable) {
                0
            }
        } else {
            0
        }
    }

    private companion object {
        const val TAG = "AudioSystem"
    }
}
