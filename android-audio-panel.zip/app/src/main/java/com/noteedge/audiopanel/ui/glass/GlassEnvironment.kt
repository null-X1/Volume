package com.noteedge.audiopanel.ui.glass

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.IntSize
import com.noteedge.audiopanel.core.model.GlassTuning
import com.noteedge.audiopanel.core.system.BlurSupport
import com.noteedge.audiopanel.core.system.Haptics
import com.noteedge.audiopanel.ui.theme.PanelPalette

/** Current glass appearance settings. */
val LocalGlassTuning = staticCompositionLocalOf { GlassTuning.Default }

/** Haptics engine; null in previews and in windows that should stay silent. */
val LocalHaptics = staticCompositionLocalOf<Haptics?> { null }

/** Size of the root surface that [LocalBackdrop] draws into. */
val LocalBackdropFrame = staticCompositionLocalOf { IntSize.Zero }

/**
 * The scene *behind* the glass.
 *
 * Every [GlassSurface] re-draws this same scene inside its own bounds and blurs it,
 * which is how in-app backdrop blur is achieved on Android 12+ without any private
 * API: the scene is simply rendered twice, once plain and once behind the glass.
 */
val LocalBackdrop = compositionLocalOf<(@Composable (Modifier) -> Unit)?> { null }

/** True when the platform can actually blur (Android 12+ RenderEffect). */
val LocalBackdropBlurSupported = staticCompositionLocalOf { false }

/**
 * Shared "living light" accumulator.
 *
 * Controls push their current energy into this while they are being touched, and the
 * ambient scene drifts with it. Nothing here animates on a timer - if nobody touches
 * the panel, no frame is drawn for the background at all.
 */
@androidx.compose.runtime.Stable
class PanelEnergy {
    private val state = androidx.compose.runtime.mutableFloatStateOf(0f)

    val value: Float get() = state.floatValue

    fun pulse(intensity: Float) {
        val clamped = intensity.coerceIn(0f, 1f)
        if (clamped > state.floatValue) state.floatValue = clamped
    }

    fun settle() {
        state.floatValue = 0f
    }
}

val LocalPanelEnergy = staticCompositionLocalOf<PanelEnergy?> { null }

/**
 * Hosts the ambient scene and publishes the backdrop + frame to every glass surface
 * below it.
 */
@Composable
fun GlassBackdropHost(
    modifier: Modifier = Modifier,
    energy: () -> Float = { 0f },
    backdrop: @Composable (Modifier) -> Unit = { backdropModifier ->
        AmbientBackdrop(modifier = backdropModifier, energy = energy)
    },
    content: @Composable BoxScope.() -> Unit,
) {
    var frameSize by remember { mutableStateOf(IntSize.Zero) }
    val blurSupported = BlurSupport.renderEffectBlurSupported

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        PanelPalette.Background,
                        PanelPalette.BackgroundLift,
                        PanelPalette.Background,
                    ),
                ),
            )
            .onGloballyPositioned { frameSize = it.size },
    ) {
        // The plain scene, drawn once for the whole screen.
        backdrop(Modifier.matchParentSize())

        CompositionLocalProvider(
            LocalBackdropFrame provides frameSize,
            LocalBackdrop provides backdrop,
            LocalBackdropBlurSupported provides blurSupported,
        ) {
            content()
        }
    }
}
