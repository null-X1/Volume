package com.noteedge.audiopanel.ui.panel

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.noteedge.audiopanel.R
import com.noteedge.audiopanel.core.model.AudioStreamKind
import com.noteedge.audiopanel.ui.components.GlassDivider
import com.noteedge.audiopanel.ui.components.SectionCard
import com.noteedge.audiopanel.ui.components.StatusPill
import com.noteedge.audiopanel.ui.glass.GlassIconButton
import com.noteedge.audiopanel.ui.glass.GlassSwitch
import com.noteedge.audiopanel.ui.theme.PanelPalette
import com.noteedge.audiopanel.util.Formatters

/**
 * The full panel shown inside the app. Every value here is live: the sliders are the
 * same gesture-driven glass controls the floating overlay uses.
 */
@Composable
fun PanelScreen(
    viewModel: PanelViewModel,
    modifier: Modifier = Modifier,
) {
    val streams by viewModel.streams.collectAsStateWithLifecycle()
    val tuning by viewModel.tuning.collectAsStateWithLifecycle()
    val overlaySettings by viewModel.overlaySettings.collectAsStateWithLifecycle()
    val effectsState by viewModel.effectsState.collectAsStateWithLifecycle()
    val route by viewModel.route.collectAsStateWithLifecycle()
    val device by viewModel.device.collectAsStateWithLifecycle()
    val permissions by viewModel.permissionSnapshot.collectAsStateWithLifecycle()
    val overlayRunning by viewModel.overlayRunning.collectAsStateWithLifecycle()
    val lastPreset by viewModel.lastPreset.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val matchedPreset = remember(streams) { viewModel.matchPreset() }

    LaunchedEffect(Unit) {
        viewModel.messages.collect { message -> snackbarHostState.showSnackbar(message) }
    }

    LaunchedEffect(permissions.overlay, overlayRunning) {
        // The system can revoke the overlay grant while the panel is floating.
        if (overlayRunning && !permissions.overlay) viewModel.setOverlayRunning(false)
    }

    Box(modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .windowInsetsPadding(WindowInsets.systemBars)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            PanelHeader(
                deviceName = device.displayName,
                model = device.model,
                androidRelease = device.androidRelease,
                sdkInt = device.sdkInt,
                routeLabel = route?.label ?: stringResource(R.string.value_unknown),
                maxRefreshRate = device.maxRefreshRate,
                overlayEnabled = overlaySettings.enabled,
                overlayRunning = overlayRunning,
                overlayAllowed = permissions.overlay,
                onToggleOverlay = { enabled ->
                    if (permissions.overlay) {
                        viewModel.setOverlayRunning(enabled)
                    } else {
                        runCatching { context.startActivity(viewModel.overlaySettingsIntent()) }
                    }
                },
                onOpenAppSettings = {
                    runCatching { context.startActivity(viewModel.appSettingsIntent()) }
                },
            )

            if (streams.isNotEmpty()) {
                StreamsSection(
                    streams = streams,
                    onDrag = viewModel::onStreamDrag,
                    onCommit = viewModel::onStreamCommit,
                    onToggleMute = viewModel::toggleMute,
                    onMuteAll = viewModel::muteAll,
                    onRestoreAll = viewModel::restoreAll,
                )
            }

            PresetsSection(
                matched = matchedPreset,
                lastApplied = lastPreset,
                onApply = viewModel::applyPreset,
            )

            EffectsSection(
                state = effectsState,
                onEnabledChange = viewModel::setEffectsEnabled,
                onBand = viewModel::setBand,
                onBass = viewModel::setBass,
                onVirtualizer = viewModel::setVirtualizer,
                onReset = viewModel::resetEffects,
            )

            AppearanceSection(
                tuning = tuning,
                blurSupported = device.renderEffectBlur,
                crossWindowBlur = device.crossWindowBlur,
                onTuning = viewModel::updateTuning,
                onReset = viewModel::resetTuning,
            )

            FeelSection(
                tuning = tuning,
                highRefreshSupported = device.supportsMoreThan60Hz,
                onTuning = viewModel::updateTuning,
            )

            SystemSection(
                device = device,
                route = route,
                tuning = tuning,
                permissions = permissions,
                overlayRunning = overlayRunning,
                onToggleOverlay = { enabled -> viewModel.setOverlayRunning(enabled) },
                onOpenOverlaySettings = {
                    runCatching { context.startActivity(viewModel.overlaySettingsIntent()) }
                },
                onOpenBattery = {
                    runCatching { context.startActivity(viewModel.batteryIntent()) }
                },
                onOpenDnd = {
                    runCatching { context.startActivity(viewModel.dndIntent()) }
                },
                onOpenAppSettings = {
                    runCatching { context.startActivity(viewModel.appSettingsIntent()) }
                },
                onRefresh = viewModel::refresh,
            )

            Text(
                text = "Built for ${device.manufacturer} ${device.model} - MediaTek Dimensity class. " +
                    "Public Android APIs only: AudioManager, WindowManager, MediaEffect and Compose.",
                color = PanelPalette.TextTertiary,
                fontSize = 11.sp,
                lineHeight = 15.sp,
                modifier = Modifier.fillMaxWidth().padding(bottom = 18.dp),
            )
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
        )
    }
}

@Composable
private fun PanelHeader(
    deviceName: String,
    model: String,
    androidRelease: String,
    sdkInt: Int,
    routeLabel: String,
    maxRefreshRate: Float,
    overlayEnabled: Boolean,
    overlayRunning: Boolean,
    overlayAllowed: Boolean,
    onToggleOverlay: (Boolean) -> Unit,
    onOpenAppSettings: () -> Unit,
) {
    SectionCard(
        title = stringResource(R.string.app_name),
        subtitle = stringResource(R.string.app_tagline),
        icon = Icons.AutoMirrored.Rounded.VolumeUp,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = deviceName,
                    color = PanelPalette.TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    text = "$model - Android $androidRelease (API $sdkInt)",
                    color = PanelPalette.TextSecondary,
                    fontSize = 12.sp,
                )
            }
            GlassIconButton(
                onClick = onOpenAppSettings,
                buttonSize = 38.dp,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Settings,
                    contentDescription = "App info",
                    tint = PanelPalette.TextSecondary,
                    modifier = Modifier.size(17.dp),
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        GlassDivider()
        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            StatusPill(text = routeLabel, color = PanelPalette.Accent)
            StatusPill(text = Formatters.hz(maxRefreshRate) + " panel", color = PanelPalette.Violet)
            StatusPill(text = "${streamsSummaryLabel()} streams", color = PanelPalette.TextTertiary)
        }

        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.Layers,
                    contentDescription = null,
                    tint = if (overlayRunning) PanelPalette.Success else PanelPalette.TextTertiary,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(
                        text = stringResource(R.string.section_overlay),
                        color = PanelPalette.TextPrimary,
                        fontSize = 13.sp,
                    )
                    Text(
                        text = when {
                            overlayRunning -> stringResource(R.string.overlay_running)
                            overlayEnabled -> stringResource(R.string.overlay_start)
                            else -> stringResource(R.string.overlay_stopped)
                        },
                        color = PanelPalette.TextTertiary,
                        fontSize = 11.sp,
                    )
                }
            }
            GlassSwitch(
                checked = overlayRunning,
                onCheckedChange = onToggleOverlay,
                accent = if (overlayAllowed) PanelPalette.Accent else PanelPalette.Warm,
            )
        }
    }
}

private fun streamsSummaryLabel(): Int = AudioStreamKind.displayOrder.size
