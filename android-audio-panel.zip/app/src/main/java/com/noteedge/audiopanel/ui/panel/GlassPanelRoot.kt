package com.noteedge.audiopanel.ui.panel

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.IntSize
import com.noteedge.audiopanel.core.model.GlassTuning
import com.noteedge.audiopanel.core.system.BlurSupport
import com.noteedge.audiopanel.core.system.Haptics
import com.noteedge.audiopanel.ui.glass.GlassBackdropHost
import com.noteedge.audiopanel.ui.glass.LocalBackdrop
import com.noteedge.audiopanel.ui.glass.LocalBackdropBlurSupported
import com.noteedge.audiopanel.ui.glass.LocalBackdropFrame
import com.noteedge.audiopanel.ui.glass.LocalGlassTuning
import com.noteedge.audiopanel.ui.glass.LocalHaptics
import com.noteedge.audiopanel.ui.glass.LocalPanelEnergy
import com.noteedge.audiopanel.ui.glass.PanelEnergy

/**
 * Wires the glass environment for one host of the panel.
 *
 * @param scenic `true` for the in-app screen, which renders the ambient scene behind the
 *   glass. `false` for the floating overlay: there the real screen behind the window *is*
 *   the backdrop, so no scene is drawn and blur comes from the window compositor.
 */
@Composable
fun GlassPanelRoot(
    tuning: GlassTuning,
    haptics: Haptics?,
    modifier: Modifier = Modifier,
    scenic: Boolean = true,
    content: @Composable () -> Unit,
) {
    val energy = remember { PanelEnergy() }

    if (scenic) {
        GlassBackdropHost(modifier = modifier.fillMaxSize(), energy = { energy.value }) {
            CompositionLocalProvider(
                LocalGlassTuning provides tuning,
                LocalHaptics provides haptics,
                LocalPanelEnergy provides energy,
            ) {
                content()
            }
        }
    } else {
        var frame by remember { mutableStateOf(IntSize.Zero) }
        Box(
            modifier = modifier.onGloballyPositioned { coordinates -> frame = coordinates.size },
        ) {
            CompositionLocalProvider(
                LocalGlassTuning provides tuning,
                LocalHaptics provides haptics,
                LocalPanelEnergy provides energy,
                LocalBackdropFrame provides frame,
                LocalBackdrop provides null,
                LocalBackdropBlurSupported provides BlurSupport.renderEffectBlurSupported,
            ) {
                content()
            }
        }
    }
}
