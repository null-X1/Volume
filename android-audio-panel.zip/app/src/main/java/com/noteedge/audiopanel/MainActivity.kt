package com.noteedge.audiopanel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.noteedge.audiopanel.core.system.RefreshRateController
import com.noteedge.audiopanel.ui.panel.GlassPanelRoot
import com.noteedge.audiopanel.ui.panel.PanelScreen
import com.noteedge.audiopanel.ui.panel.PanelViewModel
import com.noteedge.audiopanel.ui.theme.AudioPanelTheme

/**
 * The in-app panel. The same controls also run inside the floating overlay window
 * (see [com.noteedge.audiopanel.overlay.OverlayPanelService]); this activity is the place
 * where permissions, tuning and the full set of streams are reachable.
 */
class MainActivity : ComponentActivity() {

    private val container by lazy { (application as AudioPanelApplication).container }

    private val viewModel: PanelViewModel by viewModels {
        PanelViewModel.factory(container, applicationContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AudioPanelTheme {
                val tuning by viewModel.tuning.collectAsStateWithLifecycle()
                GlassPanelRoot(
                    tuning = tuning,
                    haptics = viewModel.haptics,
                    modifier = Modifier.fillMaxSize(),
                ) {
                    PanelScreen(viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refresh()
        // Ask for the highest refresh mode the display offers while the panel is visible.
        RefreshRateController.apply(window, viewModel.tuning.value.highRefreshRate)
    }

    override fun onPause() {
        super.onPause()
        RefreshRateController.apply(window, false)
    }
}
