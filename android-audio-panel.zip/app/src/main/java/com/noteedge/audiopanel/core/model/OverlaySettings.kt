package com.noteedge.audiopanel.core.model

/** Where the floating panel sits and how it is presented. */
data class OverlaySettings(
    val enabled: Boolean = false,
    /** Horizontal position in pixels; null means "not placed yet". */
    val x: Int? = null,
    val y: Int? = null,
    /** Expanded shows effects + presets, collapsed shows three streams. */
    val expanded: Boolean = false,
    /** 0.8 .. 1.15 */
    val scale: Float = 1f,
)
