package com.noteedge.audiopanel.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Palette and type for the glass panel.
 *
 * The design language is "cold glass over a dark room": a deep indigo background,
 * a cool cyan primary, and a warm amber secondary used only for alarms and alerts,
 * so that colour always means something.
 */
object PanelPalette {
    val Background = Color(0xFF06080E)
    val BackgroundLift = Color(0xFF0B1020)
    val BackgroundDeep = Color(0xFF150F33)
    val Surface = Color(0xFF0D1220)
    val TextPrimary = Color(0xFFEAF1FB)
    val TextSecondary = Color(0xFF9FB0C8)
    val TextTertiary = Color(0xFF6B7C96)
    val Accent = Color(0xFF7FD4FF)
    val AccentDeep = Color(0xFF4C7DFF)
    val Warm = Color(0xFFFFC27A)
    val Alarm = Color(0xFFFF8A5C)
    val Violet = Color(0xFF9C7CFF)
    val Success = Color(0xFF7BE3B0)
    val Danger = Color(0xFFFF7A7A)

    /** Per-stream accents; every slider is identifiable by colour alone. */
    val media = Accent
    val ringAccent = Violet
    val notificationAccent = Color(0xFF8AB4FF)
    val alarmAccent = Alarm
    val callAccent = Success
    val systemAccent = Color(0xFFB9C7DB)
}

private val scheme = darkColorScheme(
    primary = PanelPalette.Accent,
    onPrimary = Color(0xFF04121F),
    primaryContainer = PanelPalette.AccentDeep,
    secondary = PanelPalette.Warm,
    tertiary = PanelPalette.Violet,
    background = PanelPalette.Background,
    onBackground = PanelPalette.TextPrimary,
    surface = PanelPalette.Surface,
    onSurface = PanelPalette.TextPrimary,
    surfaceVariant = Color(0xFF141B2C),
    onSurfaceVariant = PanelPalette.TextSecondary,
    outline = Color(0xFF2A3550),
    error = PanelPalette.Danger,
)

private val panelTypography = Typography().let { base ->
    base.copy(
        displaySmall = base.displaySmall.copy(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Light,
            letterSpacing = (-0.5).sp,
        ),
        headlineSmall = base.headlineSmall.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium),
        titleLarge = base.titleLarge.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold),
        titleMedium = base.titleMedium.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold),
        bodyLarge = base.bodyLarge.copy(fontFamily = FontFamily.SansSerif),
        bodyMedium = base.bodyMedium.copy(fontFamily = FontFamily.SansSerif),
        bodySmall = base.bodySmall.copy(fontFamily = FontFamily.SansSerif),
        labelLarge = base.labelLarge.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium),
        labelMedium = base.labelMedium.copy(fontFamily = FontFamily.SansSerif, letterSpacing = 0.4.sp),
        labelSmall = base.labelSmall.copy(fontFamily = FontFamily.SansSerif, letterSpacing = 0.6.sp),
    )
}

@Composable
fun AudioPanelTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = scheme,
        typography = panelTypography,
        content = content,
    )
}

/** True when the device reports a wide (tablet / unfolded) layout. */
val LocalWideLayout = staticCompositionLocalOf { false }

@Composable
fun ProvideWideLayout(wide: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalWideLayout provides wide, content = content)
}
