package com.noteedge.audiopanel.core.system

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlin.math.roundToInt

/**
 * Touch feedback for the glass UI.
 *
 * The panel is built around direct manipulation, so the haptics are graded the way a
 * physical control would be: a light tick as a detent is crossed, a firmer knock when a
 * slider bottoms out, and an escalating tick for repeated taps.
 */
class Haptics(context: Context) {

    enum class Feel(val durationMs: Long, val amplitude: Int) {
        Tick(7L, 80),
        Soft(13L, 130),
        Firm(19L, 180),
        Heavy(27L, 230),
    }

    private val vibrator: Vibrator? = resolveVibrator(context)

    var enabled: Boolean = true
    /** 0..1 user setting; scales every amplitude. */
    var intensity: Float = 0.75f

    fun play(feel: Feel, boost: Float = 0f) {
        if (!enabled) return
        val device = vibrator ?: return
        if (!device.hasVibrator()) return
        val scale = (intensity + boost).coerceIn(0.12f, 1.5f)
        val amplitude = (feel.amplitude * scale).roundToInt().coerceIn(12, 255)
        val effect: VibrationEffect = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && device.hasAmplitudeControl() ->
                VibrationEffect.createOneShot(feel.durationMs, amplitude)

            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ->
                VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)

            else ->
                VibrationEffect.createOneShot(feel.durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
        }
        runCatching { device.vibrate(effect) }
    }

    fun stop() {
        runCatching { vibrator?.cancel() }
    }

    private companion object {
        fun resolveVibrator(context: Context): Vibrator? {
            val app = context.applicationContext
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (app.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        }
    }
}
