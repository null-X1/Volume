package com.noteedge.audiopanel.ui.panel

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Waves
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noteedge.audiopanel.R
import com.noteedge.audiopanel.core.model.AudioPreset
import com.noteedge.audiopanel.ui.components.SectionCard
import com.noteedge.audiopanel.ui.glass.GlassChip
import com.noteedge.audiopanel.ui.theme.PanelPalette

private fun presetGlyph(preset: AudioPreset): ImageVector = when (preset) {
    AudioPreset.BALANCED -> Icons.Rounded.Tune
    AudioPreset.LOUD -> Icons.AutoMirrored.Rounded.VolumeUp
    AudioPreset.FOCUS -> Icons.Rounded.Waves
    AudioPreset.SILENT -> Icons.AutoMirrored.Rounded.VolumeOff
    AudioPreset.NIGHT -> Icons.Rounded.AutoAwesome
}

@Composable
internal fun PresetsSection(
    matched: AudioPreset?,
    lastApplied: AudioPreset?,
    onApply: (AudioPreset) -> Unit,
) {
    SectionCard(
        title = stringResource(R.string.section_presets),
        subtitle = "One tap, every stream moves together",
        icon = Icons.Rounded.AutoAwesome,
        accent = PanelPalette.Warm,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            AudioPreset.entries.forEach { preset ->
                GlassChip(
                    label = stringResource(preset.labelRes),
                    selected = matched == preset || (matched == null && lastApplied == preset),
                    icon = presetGlyph(preset),
                    onClick = { onApply(preset) },
                    accent = if (preset == AudioPreset.SILENT) PanelPalette.Warm else PanelPalette.Accent,
                )
            }
        }
        Text(
            text = if (matched != null) {
                "Current mix matches ${stringResource(matched.labelRes)}"
            } else {
                "Custom mix - pick a preset to snap everything back"
            },
            color = PanelPalette.TextTertiary,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 12.dp),
        )
    }
}
