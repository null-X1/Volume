package com.noteedge.audiopanel.core.system

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display
import android.view.Window

/**
 * Asks the display for its fastest mode.
 *
 * The NOTE Edge panel runs at up to 120 Hz. Compose animations are already frame-rate
 * agnostic, so all that is needed is to let the window prefer the high-refresh mode
 * while the glass panel is on screen - and to give it back when it is not, so idle
 * battery behaviour is untouched.
 */
object RefreshRateController {

    fun highestRefreshModeId(context: Context): Int {
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = displayManager?.getDisplay(Display.DEFAULT_DISPLAY) ?: return 0
        return runCatching {
            display.supportedModes.maxByOrNull { it.refreshRate }?.modeId ?: 0
        }.getOrDefault(0)
    }

    fun highestRefreshRate(context: Context): Float {
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = displayManager?.getDisplay(Display.DEFAULT_DISPLAY) ?: return 0f
        return runCatching {
            display.supportedModes.maxOfOrNull { it.refreshRate } ?: display.mode.refreshRate
        }.getOrDefault(0f)
    }

    /** Applies or reverts the preference on the given window. */
    fun apply(window: Window, enabled: Boolean) {
        runCatching {
            val attributes = window.attributes
            if (enabled) {
                val modeId = highestRefreshModeId(window.context)
                if (modeId > 0) attributes.preferredDisplayModeId = modeId
                attributes.preferredRefreshRate = highestRefreshRate(window.context)
            } else {
                attributes.preferredDisplayModeId = 0
                attributes.preferredRefreshRate = 0f
            }
            window.attributes = attributes
        }
    }
}
